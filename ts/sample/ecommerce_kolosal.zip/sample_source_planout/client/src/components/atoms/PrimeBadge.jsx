/**
 * PrimeBadge atom — the "★ prime" subscription indicator.
 *
 * Props:
 *   size : 'sm' | 'md'  (default: 'sm')
 */
export default function PrimeBadge({ size = 'sm' }) {
  return (
    <span style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      background: 'var(--color-prime)',
      color: 'white',
      borderRadius: 'var(--radius-sm)',
      padding: size === 'sm' ? '2px 6px' : '4px 10px',
      fontSize: size === 'sm' ? 'var(--font-size-xs)' : 'var(--font-size-sm)',
      fontWeight: 'var(--font-weight-bold)',
      letterSpacing: '0.05em',
    }}>
      ★ prime
    </span>
  );
}
