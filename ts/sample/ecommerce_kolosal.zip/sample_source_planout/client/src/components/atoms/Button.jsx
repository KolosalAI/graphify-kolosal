/**
 * Button atom — Kolosal Library btn-{size} btn-{variant} pattern.
 *
 * Props:
 *   variant : 'primary' | 'secondary' | 'outline' | 'danger' | 'ghost'
 *   size    : 'xs' | 'sm' | 'md' | 'lg'
 *   full    : boolean — stretch to full width
 *   as      : element type or component (default: 'button')
 */
export default function Button({
  variant = 'primary',
  size = 'md',
  full = false,
  as: Tag = 'button',
  className = '',
  children,
  ...props
}) {
  const classes = [
    `btn-${size}`,
    `btn-${variant}`,
    full ? 'btn-full' : '',
    className,
  ].filter(Boolean).join(' ');

  return (
    <Tag className={classes} {...props}>
      {children}
    </Tag>
  );
}
