/**
 * Spinner atom — an animated loading indicator.
 *
 * Props:
 *   size : CSS size string (default: '24px')
 *   label: Accessible text (default: 'Loading…')
 */
export default function Spinner({ size = '24px', label = 'Loading…' }) {
  return (
    <span
      role="status"
      aria-label={label}
      className="loading-spinner"
      style={{ width: size, height: size }}
    />
  );
}
