/**
 * Input atom — Kolosal Library input-text-{size} pattern.
 * All native <input> props are forwarded.
 *
 * Props:
 *   size : 'xs' | 'sm' | 'md' | 'lg'
 */
export default function Input({ size = 'md', className = '', ...props }) {
  return (
    <input
      className={[`input-text-${size}`, className].filter(Boolean).join(' ')}
      {...props}
    />
  );
}
