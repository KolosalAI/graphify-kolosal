/**
 * Select atom — a styled <select> element.
 * All native <select> props are forwarded.
 */
export default function Select({ className = '', children, ...props }) {
  return (
    <select className={className} {...props}>
      {children}
    </select>
  );
}
