/**
 * StarRating atom — displays a read-only star rating (★★★★☆).
 *
 * Props:
 *   rating : number (0–5)
 *   count  : optional review count shown in parentheses
 *   size   : CSS font-size string (default: '1rem')
 */
export default function StarRating({ rating, count, size = '1rem' }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', fontSize: '0.75rem' }}>
      <span style={{ color: 'var(--color-warning)', letterSpacing: '-2px', fontSize: size }}>
        {[1, 2, 3, 4, 5].map(i => (
          <span key={i} style={{ opacity: i <= Math.round(rating) ? 1 : 0.2 }}>★</span>
        ))}
      </span>
      {count !== undefined && (
        <span style={{ color: 'var(--color-text-light)' }}>({count})</span>
      )}
    </div>
  );
}
