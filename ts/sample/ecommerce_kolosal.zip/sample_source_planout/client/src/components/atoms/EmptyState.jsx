import Button from './Button';

/**
 * EmptyState atom — a centred placeholder for empty lists/pages.
 *
 * Props:
 *   title       : string
 *   description : string (optional)
 *   action      : { label, onClick } (optional) — renders a primary Button
 */
export default function EmptyState({ title, description, action }) {
  return (
    <div className="empty-state">
      <h2>{title}</h2>
      {description && <p style={{ marginBottom: action ? '1rem' : 0 }}>{description}</p>}
      {action && (
        <Button variant="primary" onClick={action.onClick}>
          {action.label}
        </Button>
      )}
    </div>
  );
}
