/**
 * Textarea atom — a styled <textarea> element.
 * All native <textarea> props are forwarded.
 */
export default function Textarea({ className = '', ...props }) {
  return <textarea className={className} {...props} />;
}
