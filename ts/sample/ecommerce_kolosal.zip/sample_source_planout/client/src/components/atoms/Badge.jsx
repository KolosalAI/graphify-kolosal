/**
 * Badge atom — Kolosal Library badge-sm + badge-{variant} pattern.
 *
 * Props:
 *   variant : 'primary' | 'information' | 'danger' | 'success' | 'warning' | 'gray'
 *   size    : 'sm' | 'lg'
 */
export default function Badge({ variant = 'primary', size = 'sm', className = '', style, children, ...props }) {
  const colorClass = variant === 'primary' ? 'badge-primary' : `badge-${variant}`;
  const sizeClass  = size === 'lg' ? 'badge-lg' : 'badge-sm';

  return (
    <span
      className={[sizeClass, colorClass, className].filter(Boolean).join(' ')}
      style={style}
      {...props}
    >
      {children}
    </span>
  );
}
