/**
 * Components barrel export
 * Import from any level directly, or use this single entry point:
 *
 *   import { Button, ProductCard, PageLayout } from '../components';
 *
 * Atomic design hierarchy:
 *   atoms/      — smallest stateless building blocks
 *   molecules/  — composed from atoms, no data fetching
 *   organisms/  — complex, may fetch data or hold state
 *   templates/  — layout wrappers
 */

export * from './atoms';
export * from './molecules';
export * from './organisms';
export * from './templates';
