import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';

export default function BannerCarousel() {
  const [banners, setBanners] = useState([]);
  const [current, setCurrent] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/banners').then(r => r.json()).then(setBanners).catch(console.error);
  }, []);

  const next = useCallback(() => setCurrent(c => (c + 1) % banners.length), [banners.length]);
  const prev = () => setCurrent(c => (c - 1 + banners.length) % banners.length);

  useEffect(() => {
    if (banners.length < 2) return;
    const timer = setInterval(next, 4500);
    return () => clearInterval(timer);
  }, [banners.length, next]);

  if (!banners.length) return null;

  const banner = banners[current];

  return (
    <div className="banner-carousel">
      <div
        className="banner-slide"
        onClick={() => banner.link && navigate(banner.link)}
        role={banner.link ? 'button' : undefined}
        style={{
          backgroundImage: `url(${banner.image_url})`,
          cursor: banner.link ? 'pointer' : 'default',
        }}
      >
        <div
          className="banner-overlay"
          style={{ background: `linear-gradient(135deg, ${banner.bg_color}ee 0%, ${banner.bg_color}99 60%, transparent 100%)` }}
        >
          <div className="banner-content">
            <h2>{banner.title}</h2>
            <p>{banner.subtitle}</p>
            {banner.link && (
              <button
                className="banner-cta"
                onClick={e => { e.stopPropagation(); navigate(banner.link); }}
              >
                Shop Now →
              </button>
            )}
          </div>
        </div>
      </div>

      {banners.length > 1 && (
        <>
          <button className="banner-arrow banner-arrow-left" aria-label="Previous banner" onClick={e => { e.stopPropagation(); prev(); }}>‹</button>
          <button className="banner-arrow banner-arrow-right" aria-label="Next banner" onClick={e => { e.stopPropagation(); next(); }}>›</button>
          <div className="banner-dots" role="tablist">
            {banners.map((_, i) => (
              <button
                key={i}
                role="tab"
                aria-selected={i === current}
                aria-label={`Banner ${i + 1}`}
                className={`banner-dot${i === current ? ' active' : ''}`}
                onClick={() => setCurrent(i)}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
