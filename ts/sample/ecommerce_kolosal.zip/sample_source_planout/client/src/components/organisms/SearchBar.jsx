import { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';

function IconSearch() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="11" cy="11" r="8" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}

export default function SearchBar({ defaultValue = '' }) {
  const [query, setQuery]           = useState(defaultValue);
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen]             = useState(false);
  const [searchParams]              = useSearchParams();
  const navigate                    = useNavigate();
  const debounceRef                 = useRef(null);
  const wrapperRef                  = useRef(null);

  useEffect(() => {
    setQuery(searchParams.get('search') || '');
  }, [searchParams]);

  useEffect(() => {
    const handler = (e) => {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    clearTimeout(debounceRef.current);
    if (val.length < 2) { setSuggestions([]); setOpen(false); return; }
    debounceRef.current = setTimeout(async () => {
      try {
        const res  = await fetch(`/api/products/suggestions?q=${encodeURIComponent(val)}`);
        const data = await res.json();
        setSuggestions(data);
        setOpen(data.length > 0);
      } catch {}
    }, 250);
  };

  const selectSuggestion = (product) => {
    setOpen(false);
    setQuery('');
    navigate(`/product/${product.slug}`);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setOpen(false);
    const params = new URLSearchParams();
    if (query.trim()) params.set('q', query.trim());
    navigate(`/search?${params}`);
  };

  return (
    <div ref={wrapperRef} className="search-bar-wrap">
      <form onSubmit={handleSubmit} className="search-form">
        <input
          className="input-text-md search-input"
          type="text"
          placeholder="Search products..."
          value={query}
          onChange={handleChange}
          onFocus={() => suggestions.length > 0 && setOpen(true)}
        />
        <button type="submit" className="search-submit" aria-label="Search">
          <IconSearch />
        </button>
      </form>

      {open && (
        <div className="search-suggestions">
          {suggestions.map(product => (
            <div
              key={product.id}
              className="suggestion-item"
              onClick={() => selectSuggestion(product)}
            >
              <img src={product.image_url} alt="" onError={e => { e.currentTarget.src = 'https://placehold.co/40x40/F1F3F4/9C9FA1?text=?'; e.currentTarget.onerror = null; }} />
              <div className="suggestion-info">
                <span className="suggestion-name">{product.name}</span>
                <span className="suggestion-price">${product.price.toFixed(2)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
