import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { StarRating } from '../atoms';

export default function AlsoBought({ productId, title = 'Customers also bought' }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    if (!productId) return;
    fetch(`/api/recommendations/also-bought/${productId}`)
      .then(r => r.json())
      .then(setProducts)
      .catch(() => {});
  }, [productId]);

  if (products.length === 0) return null;

  return (
    <section style={{ marginTop: 'var(--space-8)' }}>
      <h3 style={{ fontSize: 'var(--font-size-lg)', fontWeight: 'var(--font-weight-bold)', marginBottom: 'var(--space-4)' }}>
        {title}
      </h3>
      <div style={{ display: 'flex', gap: 'var(--space-4)', overflowX: 'auto', paddingBottom: 8 }}>
        {products.map(p => (
          <Link key={p.id} to={`/product/${p.slug}`} style={{ textDecoration: 'none', flexShrink: 0 }}>
            <div className="card" style={{ width: 160, overflow: 'hidden', boxShadow: 'var(--shadow)' }}>
              <img
                src={p.image_url || 'https://placehold.co/160x120'}
                alt={p.name}
                style={{ width: '100%', height: 120, objectFit: 'cover' }}
              />
              <div style={{ padding: 'var(--space-2)' }}>
                <p style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text)', fontWeight: 'var(--font-weight-semibold)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 4 }}>
                  {p.name}
                </p>
                <p style={{ fontSize: 'var(--font-size-base)', fontWeight: 'var(--font-weight-bold)', color: 'var(--color-primary)' }}>
                  ${p.price.toFixed(2)}
                </p>
                {p.avg_rating > 0 && <StarRating rating={p.avg_rating} count={p.review_count} />}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
