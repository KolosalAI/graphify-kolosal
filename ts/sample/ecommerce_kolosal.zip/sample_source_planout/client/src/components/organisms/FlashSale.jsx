import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { Button } from '../atoms';
import { CountdownTimer } from '../molecules';

function FlashItem({ item }) {
  const { addItem } = useCart();
  const discount = Math.round((1 - item.sale_price / item.original_price) * 100);
  const soldPct   = item.quantity_limit ? Math.round((item.sold / item.quantity_limit) * 100) : 0;

  const product = {
    id:            item.product_id,
    name:          item.name,
    slug:          item.slug,
    image_url:     item.image_url,
    price:         item.sale_price,
    stock:         (item.quantity_limit ?? 999) - item.sold,
    category_name: item.category_name,
    avg_rating:    item.avg_rating,
    review_count:  item.review_count,
  };

  return (
    <div className="flash-item">
      <div className="flash-badge">-{discount}%</div>
      <Link to={`/product/${item.slug}`}>
        <img src={item.image_url} alt={item.name} loading="lazy" onError={e => { e.currentTarget.src = 'https://placehold.co/400x300/F1F3F4/9C9FA1?text=No+Image'; e.currentTarget.onerror = null; }} />
      </Link>
      <div className="flash-item-info">
        <Link to={`/product/${item.slug}`} className="flash-item-name">{item.name}</Link>
        <div className="flash-prices">
          <span className="flash-sale-price">${item.sale_price.toFixed(2)}</span>
          <span className="flash-original-price">${item.original_price.toFixed(2)}</span>
        </div>
        {item.quantity_limit && (
          <div className="flash-stock">
            <div className="flash-stock-bar">
              <div className="flash-stock-fill" style={{ width: `${soldPct}%` }} />
            </div>
            <span className="flash-stock-label">
              {soldPct >= 90 ? 'Almost gone!' : soldPct >= 60 ? `${item.quantity_limit - item.sold} left` : `${item.sold} sold`}
            </span>
          </div>
        )}
        <Button
          variant="primary"
          size="sm"
          full
          className="flash-add-btn"
          onClick={() => addItem(product)}
          disabled={product.stock <= 0}
        >
          {product.stock > 0 ? 'Add to Cart' : 'Sold Out'}
        </Button>
      </div>
    </div>
  );
}

export default function FlashSale() {
  const [sale, setSale]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [expired, setExpired] = useState(false);

  useEffect(() => {
    fetch('/api/flash-sales/active')
      .then(r => r.json())
      .then(setSale)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !sale || !sale.items || expired) return null;

  return (
    <section className="flash-sale-section">
      <div className="flash-sale-header">
        <div className="flash-sale-title">
          <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
          </svg>
          <h2>{sale.title}</h2>
        </div>
        <div className="flash-countdown">
          <span className="countdown-label">Ends in</span>
          <CountdownTimer endsAt={sale.ends_at} onExpire={() => setExpired(true)} />
          <span className="countdown-sublabels">
            <span>HRS</span><span>MIN</span><span>SEC</span>
          </span>
        </div>
      </div>
      <div className="flash-items-row">
        {sale.items.map(item => <FlashItem key={item.id} item={item} />)}
      </div>
    </section>
  );
}
