import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { Button } from '../atoms';
import { StarRating } from '../atoms';
import { ProductBadge, PriceDisplay } from '../molecules';

export default function ProductCard({ product }) {
  const { addItem } = useCart();

  return (
    <div className="product-card">
      <div style={{ position: 'relative' }}>
        <Link to={`/product/${product.slug}`}>
          <img src={product.image_url} alt={product.name} loading="lazy" onError={e => { e.currentTarget.src = 'https://placehold.co/400x300/F1F3F4/9C9FA1?text=No+Image'; e.currentTarget.onerror = null; }} />
        </Link>
        {product.badge && <ProductBadge label={product.badge} />}
      </div>
      <div className="info">
        <div className="category">{product.category_name}</div>
        <h3><Link to={`/product/${product.slug}`}>{product.name}</Link></h3>
        {product.review_count > 0 && (
          <StarRating rating={product.avg_rating} count={product.review_count} />
        )}
        <div className="actions">
          <PriceDisplay price={product.price} />
          <Button
            variant="primary"
            size="sm"
            onClick={() => addItem(product)}
            disabled={product.stock === 0}
          >
            {product.stock > 0 ? 'Add to Cart' : 'Out of Stock'}
          </Button>
        </div>
      </div>
    </div>
  );
}
