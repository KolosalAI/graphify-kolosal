import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import SearchBar from './SearchBar';

function IconBag() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z" />
      <line x1="3" y1="6" x2="21" y2="6" />
      <path d="M16 10a4 4 0 01-8 0" />
    </svg>
  );
}

function IconCart() {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="9" cy="21" r="1" />
      <circle cx="20" cy="21" r="1" />
      <path d="M1 1h4l2.68 13.39a2 2 0 002 1.61h9.72a2 2 0 002-1.61L23 6H6" />
    </svg>
  );
}

export default function Header() {
  const { cartCount } = useCart();

  return (
    <header className="header">
      <div className="header-inner">
        <Link to="/" className="logo">
          <IconBag />
          ShopKolosal
        </Link>

        <SearchBar />

        <nav>
          <Link to="/search">Browse</Link>

          <Link to="/cart" className="header-cart-link">
            <span className="cart-icon">
              <IconCart />
              {cartCount > 0 && (
                <span className="cart-badge">{cartCount}</span>
              )}
            </span>
          </Link>
        </nav>
      </div>
    </header>
  );
}
