import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Button, StarRating } from '../atoms';
import { FormField, StarRatingInput } from '../molecules';
import { Textarea } from '../atoms';
import Input from '../atoms/Input';

const STARS = [5, 4, 3, 2, 1];

export default function ProductReviews({ productId }) {
  const { user, authFetch } = useAuth();
  const [data, setData]         = useState({ stats: null, reviews: [], userReview: null });
  const [form, setForm]         = useState({ rating: 0, title: '', body: '' });
  const [editing, setEditing]   = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError]       = useState('');

  const load = () => {
    fetch(`/api/reviews/${productId}`).then(r => r.json()).then(setData).catch(console.error);
  };

  useEffect(() => { load(); }, [productId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.rating) return setError('Please select a star rating.');
    setError('');
    setSubmitting(true);
    try {
      const res = await authFetch(`/api/reviews/${productId}`, {
        method: editing ? 'PUT' : 'POST',
        body: form,
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error); }
      setForm({ rating: 0, title: '', body: '' });
      setEditing(false);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const startEdit = () => {
    setForm({ rating: data.userReview.rating, title: data.userReview.title || '', body: data.userReview.body || '' });
    setEditing(true);
  };

  const deleteReview = async () => {
    await authFetch(`/api/reviews/${productId}`, { method: 'DELETE' });
    load();
  };

  const { stats, reviews, userReview } = data;

  const ReviewForm = ({ heading, submitLabel }) => (
    <div className="card" style={{ padding: 'var(--space-6)', marginBottom: 'var(--space-8)' }}>
      <h3 style={{ marginBottom: 'var(--space-4)', fontSize: 'var(--font-size-md)' }}>{heading}</h3>
      <form onSubmit={handleSubmit}>
        <FormField label="Your Rating">
          <StarRatingInput value={form.rating} onChange={r => setForm(f => ({ ...f, rating: r }))} />
        </FormField>
        <FormField label="Title (optional)">
          <Input
            value={form.title}
            onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
            placeholder="Summarize your experience"
          />
        </FormField>
        <FormField label="Review (optional)">
          <Textarea
            value={form.body}
            onChange={e => setForm(f => ({ ...f, body: e.target.value }))}
            rows={3}
            placeholder="Tell others what you think..."
          />
        </FormField>
        {error && <p style={{ color: 'var(--color-danger)', marginBottom: 'var(--space-3)', fontSize: 'var(--font-size-base)' }}>{error}</p>}
        <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
          <Button type="submit" variant="primary" disabled={submitting}>
            {submitting ? 'Saving…' : submitLabel}
          </Button>
          {editing && (
            <Button type="button" variant="primary" onClick={() => setEditing(false)}>Cancel</Button>
          )}
        </div>
      </form>
    </div>
  );

  return (
    <div style={{ marginTop: 'var(--space-12)', borderTop: '1px solid var(--color-border)', paddingTop: 'var(--space-8)' }}>
      <h2 style={{ marginBottom: 'var(--space-6)' }}>Customer Reviews</h2>

      {/* Stats summary */}
      {stats?.total > 0 && (
        <div className="card" style={{ display: 'flex', gap: 'var(--space-8)', alignItems: 'center', marginBottom: 'var(--space-8)', padding: 'var(--space-6)' }}>
          <div style={{ textAlign: 'center' }}>
            <div style={{ fontSize: '3rem', fontWeight: 'var(--font-weight-bold)', lineHeight: 1 }}>{stats.average}</div>
            <StarRating rating={stats.average} size="1.25rem" />
            <div style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-light)', marginTop: 'var(--space-1)' }}>
              {stats.total} review{stats.total !== 1 ? 's' : ''}
            </div>
          </div>
          <div style={{ flex: 1 }}>
            {STARS.map(star => {
              const count = stats[['zero','one','two','three','four','five'][star]];
              const pct   = stats.total > 0 ? (count / stats.total) * 100 : 0;
              return (
                <div key={star} className="review-rating-bar">
                  <span style={{ fontSize: 'var(--font-size-sm)', minWidth: 12 }}>{star}</span>
                  <span style={{ fontSize: '0.9rem', color: 'var(--color-warning)' }}>★</span>
                  <div className="review-bar-track">
                    <div className="review-bar-fill" style={{ width: `${pct}%` }} />
                  </div>
                  <span style={{ fontSize: 'var(--font-size-sm)', minWidth: 20, color: 'var(--color-text-light)' }}>{count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Write / edit review form */}
      {user && !userReview && !editing && (
        <ReviewForm heading="Write a Review" submitLabel="Submit Review" />
      )}
      {editing && <ReviewForm heading="Edit Your Review" submitLabel="Save Changes" />}

      {/* User's existing review */}
      {userReview && !editing && (
        <div style={{ background: '#fffbeb', border: '1px solid #fde68a', borderRadius: 'var(--radius)', padding: 'var(--space-4)', marginBottom: 'var(--space-6)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-2)' }}>
            <div>
              <StarRating rating={userReview.rating} />
              <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-light)', marginLeft: 'var(--space-2)' }}>Your review</span>
            </div>
            <div style={{ display: 'flex', gap: 'var(--space-2)' }}>
              <Button variant="primary" size="sm" onClick={startEdit}>Edit</Button>
              <Button variant="danger" size="sm" onClick={deleteReview}>Delete</Button>
            </div>
          </div>
          {userReview.title && <div style={{ fontWeight: 'var(--font-weight-semibold)', fontSize: 0.9 + 'rem' }}>{userReview.title}</div>}
          {userReview.body  && <p style={{ fontSize: 'var(--font-size-base)', margin: 'var(--space-1) 0 0', color: 'var(--color-text-light)' }}>{userReview.body}</p>}
        </div>
      )}

      {/* Reviews list */}
      {reviews.length === 0 ? (
        <p style={{ color: 'var(--color-text-light)', textAlign: 'center', padding: 'var(--space-6)' }}>
          No reviews yet. Be the first to review this product!
        </p>
      ) : reviews.map(review => (
        <div key={review.id} style={{ borderBottom: '1px solid var(--color-border)', padding: 'var(--space-5) 0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 'var(--space-2)' }}>
            <div>
              <StarRating rating={review.rating} />
              {review.title && (
                <span style={{ marginLeft: 'var(--space-2)', fontWeight: 'var(--font-weight-semibold)', fontSize: '0.9rem' }}>{review.title}</span>
              )}
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontWeight: 'var(--font-weight-semibold)', fontSize: 'var(--font-size-base)' }}>{review.user_name}</div>
              <div style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-light)' }}>
                {new Date(review.created_at).toLocaleDateString()}
              </div>
            </div>
          </div>
          {review.body && (
            <p style={{ color: 'var(--color-text-light)', fontSize: 'var(--font-size-base)', lineHeight: 'var(--line-height-loose)', margin: 0 }}>
              {review.body}
            </p>
          )}
        </div>
      ))}
    </div>
  );
}
