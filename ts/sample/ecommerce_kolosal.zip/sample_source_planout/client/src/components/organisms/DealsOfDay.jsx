import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { PriceDisplay } from '../molecules';

function IconLightning() {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
      <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
    </svg>
  );
}

export default function DealsOfDay() {
  const [deals, setDeals]       = useState([]);
  const [timeLeft, setTimeLeft] = useState({});

  useEffect(() => {
    fetch('/api/deals').then(r => r.json()).then(setDeals).catch(() => {});
  }, []);

  useEffect(() => {
    if (deals.length === 0) return;
    const tick = () => {
      const now = new Date();
      const times = {};
      for (const deal of deals) {
        const end  = new Date(deal.ends_at);
        const diff = Math.max(0, end - now);
        const h    = Math.floor(diff / 3_600_000);
        const m    = Math.floor((diff % 3_600_000) / 60_000);
        const s    = Math.floor((diff % 60_000) / 1_000);
        times[deal.id] = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      }
      setTimeLeft(times);
    };
    tick();
    const interval = setInterval(tick, 1000);
    return () => clearInterval(interval);
  }, [deals]);

  if (deals.length === 0) return null;

  return (
    <section className="deals-section">
      <div className="deals-header">
        <h2 className="section-title">
          <IconLightning />
          Deals of the Day
        </h2>
        <span className="badge-sm badge-danger">LIMITED TIME</span>
      </div>
      <div className="deals-grid">
        {deals.map(deal => (
          <Link key={deal.id} to={`/product/${deal.slug}`} className="deal-card-link">
            <div className="deal-card card">
              <div className="deal-image-wrap">
                <img src={deal.image_url} alt={deal.name} onError={e => { e.currentTarget.src = 'https://placehold.co/300x200/F1F3F4/9C9FA1?text=No+Image'; e.currentTarget.onerror = null; }} />
                <span className="deal-discount-badge">
                  -{Math.round((1 - deal.sale_price / deal.original_price) * 100)}%
                </span>
              </div>
              <div className="deal-info">
                <p className="deal-name">{deal.name}</p>
                <PriceDisplay price={deal.sale_price} originalPrice={deal.original_price} size="sm" />
                {timeLeft[deal.id] && (
                  <div className="deal-timer">
                    <span className="deal-timer-label">Ends in</span>
                    <span className="deal-timer-value">{timeLeft[deal.id]}</span>
                  </div>
                )}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
}
