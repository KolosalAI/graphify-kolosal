/**
 * ProductBadge molecule — an absolute-positioned label overlay
 * used on product image containers.
 *
 * Props:
 *   label   : string
 *   bg      : background color (default: '#64748b')
 *   color   : text color       (default: '#fff')
 *
 * The parent element must have `position: relative`.
 */
const PRESET_COLORS = {
  'Best Seller': { bg: '#f59e0b', color: '#fff' },
  'Hot Deal':    { bg: '#ef4444', color: '#fff' },
  'New':         { bg: '#10b981', color: '#fff' },
  'Sale':        { bg: '#8b5cf6', color: '#fff' },
};

export default function ProductBadge({ label, bg, color }) {
  const preset = PRESET_COLORS[label];
  const background = bg ?? preset?.bg ?? '#64748b';
  const textColor  = color ?? preset?.color ?? '#fff';

  return (
    <span
      className="product-badge"
      style={{ background: background, color: textColor }}
    >
      {label}
    </span>
  );
}
