/**
 * PriceDisplay molecule — shows a sale price with an optional
 * original (crossed-out) price and a discount percentage badge.
 *
 * Props:
 *   price         : number — current / sale price
 *   originalPrice : number (optional) — original price before discount
 *   saleColor     : CSS color string (default: uses primary color)
 *   size          : 'sm' | 'md' | 'lg' (default: 'md')
 */
const SIZES = {
  sm: { price: '0.95rem',  original: '0.75rem' },
  md: { price: '1.1rem',   original: '0.85rem' },
  lg: { price: '1.5rem',   original: '1rem'    },
};

export default function PriceDisplay({
  price,
  originalPrice,
  saleColor,
  size = 'md',
}) {
  const sz = SIZES[size] ?? SIZES.md;
  const hasDiscount = originalPrice && originalPrice > price;
  const discountPct = hasDiscount ? Math.round((1 - price / originalPrice) * 100) : null;

  return (
    <div style={{ display: 'flex', alignItems: 'baseline', gap: '0.35rem', flexWrap: 'wrap' }}>
      <span style={{
        fontWeight: 'var(--font-weight-bold)',
        fontSize: sz.price,
        color: saleColor ?? (hasDiscount ? 'var(--color-danger)' : 'var(--color-primary)'),
      }}>
        ${Number(price).toFixed(2)}
      </span>
      {hasDiscount && (
        <>
          <span style={{ textDecoration: 'line-through', color: 'var(--color-text-light)', fontSize: sz.original }}>
            ${Number(originalPrice).toFixed(2)}
          </span>
          <span style={{
            background: 'var(--color-danger)', color: '#fff',
            borderRadius: 'var(--radius-sm)', padding: '0.1rem 0.35rem',
            fontSize: 'var(--font-size-xs)', fontWeight: 'var(--font-weight-bold)',
          }}>
            -{discountPct}%
          </span>
        </>
      )}
    </div>
  );
}
