import { useState } from 'react';

/**
 * StarRatingInput molecule — an interactive star picker for review forms.
 *
 * Props:
 *   value    : number (0–5)
 *   onChange : (rating: number) => void
 *   size     : CSS font-size (default: '1.75rem')
 */
export default function StarRatingInput({ value, onChange, size = '1.75rem' }) {
  const [hover, setHover] = useState(null);

  return (
    <div
      role="radiogroup"
      aria-label="Star rating"
      style={{ display: 'flex', gap: '0.25rem', fontSize: size, cursor: 'pointer' }}
    >
      {[1, 2, 3, 4, 5].map(i => (
        <span
          key={i}
          role="radio"
          aria-checked={value === i}
          aria-label={`${i} star${i !== 1 ? 's' : ''}`}
          tabIndex={0}
          style={{
            color: i <= (hover ?? value) ? 'var(--color-warning)' : '#d1d5db',
            transition: 'color var(--transition-fast)',
            userSelect: 'none',
          }}
          onMouseEnter={() => setHover(i)}
          onMouseLeave={() => setHover(null)}
          onClick={() => onChange(i)}
          onKeyDown={e => (e.key === 'Enter' || e.key === ' ') && onChange(i)}
        >
          ★
        </span>
      ))}
    </div>
  );
}
