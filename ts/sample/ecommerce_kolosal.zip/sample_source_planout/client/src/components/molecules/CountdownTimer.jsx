import { useState, useEffect, useCallback } from 'react';

/**
 * CountdownTimer molecule — displays a live HH:MM:SS countdown.
 *
 * Props:
 *   endsAt     : ISO date string — when the countdown expires
 *   onExpire   : () => void (optional) — called once when time reaches zero
 *   className  : optional CSS class on the wrapper
 */
function pad(n) {
  return String(n).padStart(2, '0');
}

function calcRemaining(endsAt) {
  const diff = new Date(endsAt) - Date.now();
  if (diff <= 0) return { h: 0, m: 0, s: 0, done: true };
  return {
    h: Math.floor(diff / 3_600_000),
    m: Math.floor((diff % 3_600_000) / 60_000),
    s: Math.floor((diff % 60_000) / 1_000),
    done: false,
  };
}

export default function CountdownTimer({ endsAt, onExpire, className = '' }) {
  const calc = useCallback(() => calcRemaining(endsAt), [endsAt]);
  const [time, setTime] = useState(calc);

  useEffect(() => { setTime(calc()); }, [calc]);

  useEffect(() => {
    if (time.done) { onExpire?.(); return; }
    const t = setInterval(() => {
      const next = calc();
      setTime(next);
      if (next.done) onExpire?.();
    }, 1000);
    return () => clearInterval(t);
  }, [calc, time.done, onExpire]);

  return (
    <div className={`countdown-timer ${className}`.trim()}>
      <span className="countdown-block">{pad(time.h)}</span>
      <span className="countdown-sep">:</span>
      <span className="countdown-block">{pad(time.m)}</span>
      <span className="countdown-sep">:</span>
      <span className="countdown-block">{pad(time.s)}</span>
    </div>
  );
}
