import Button from '../atoms/Button';

/**
 * QuantityControl molecule — decrement / value display / increment.
 *
 * Props:
 *   value    : number
 *   min      : number (default: 1)
 *   max      : number (default: Infinity)
 *   onChange : (newValue: number) => void
 */
export default function QuantityControl({ value, min = 1, max = Infinity, onChange }) {
  return (
    <div className="quantity-control">
      <Button
        variant="primary"
        size="sm"
        onClick={() => onChange(Math.max(min, value - 1))}
        disabled={value <= min}
        aria-label="Decrease quantity"
      >
        −
      </Button>
      <span aria-live="polite">{value}</span>
      <Button
        variant="primary"
        size="sm"
        onClick={() => onChange(Math.min(max, value + 1))}
        disabled={value >= max}
        aria-label="Increase quantity"
      >
        +
      </Button>
    </div>
  );
}
