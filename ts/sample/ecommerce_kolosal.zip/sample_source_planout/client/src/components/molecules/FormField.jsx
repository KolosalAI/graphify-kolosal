/**
 * FormField molecule — label + input element + optional error message.
 *
 * Props:
 *   label    : string
 *   error    : string (optional)
 *   children : the input element (Input, Select, Textarea, etc.)
 */
export default function FormField({ label, error, children }) {
  return (
    <div className="form-group">
      {label && <label>{label}</label>}
      {children}
      {error && <p className="form-error">{error}</p>}
    </div>
  );
}
