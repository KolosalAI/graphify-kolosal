/**
 * PageLayout template — wraps page content in the standard container.
 *
 * Props:
 *   className : additional CSS class on the container
 *   style     : additional inline styles
 *   children  : page content
 */
export default function PageLayout({ className = '', style, children }) {
  return (
    <div className={['container', className].filter(Boolean).join(' ')} style={style}>
      {children}
    </div>
  );
}
