import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useCart } from '@context';
import { ProductReviews, ProductCard, AlsoBought } from '@components';
import { productService } from '@services';

function Stars({ rating }) {
  return (
    <span style={{ color: '#f59e0b', letterSpacing: '-2px' }}>
      {[1,2,3,4,5].map(i => <span key={i} style={{ opacity: i <= Math.round(rating) ? 1 : 0.2 }}>★</span>)}
    </span>
  );
}

export default function ProductPage() {
  const { slug } = useParams();
  const { addItem } = useCart();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [added, setAdded] = useState(false);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedVariant, setSelectedVariant] = useState(null);

  useEffect(() => {
    setLoading(true);
    setSelectedImage(0);
    productService.getBySlug(slug)
      .then(setProduct)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [slug]);

  const handleAdd = () => {
    const effectivePrice = selectedVariant
      ? parseFloat((product.price + (selectedVariant.price_modifier || 0)).toFixed(2))
      : product.price;
    addItem({ ...product, price: effectivePrice }, quantity);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const displayPrice = selectedVariant
    ? (product.price + (selectedVariant.price_modifier || 0))
    : product?.price;

  const groupedVariants = product?.variants?.reduce((acc, v) => {
    if (!acc[v.group_name]) acc[v.group_name] = [];
    acc[v.group_name].push(v);
    return acc;
  }, {});

  if (loading) return <div className="loading">Loading...</div>;
  if (!product) return (
    <div className="container empty-state">
      <h2>Product not found</h2>
      <Link to="/">← Back to products</Link>
    </div>
  );

  const allImages = product.images?.length > 0
    ? product.images.map(i => i.image_url)
    : product.image_url ? [product.image_url] : [];

  return (
    <div className="container">
      <div style={{ padding: '1rem 0' }}><Link to="/">← Back to products</Link></div>

      <div className="product-detail">
        {/* Left: Image Gallery */}
        <div>
          <img
            src={allImages[selectedImage] || product.image_url}
            alt={product.name}
            style={{ width: '100%', borderRadius: 'var(--radius)', objectFit: 'cover', maxHeight: 500 }}
            onError={e => { e.currentTarget.src = `https://placehold.co/600x500/F1F3F4/9C9FA1?text=${encodeURIComponent(product.name)}`; e.currentTarget.onerror = null; }}
          />
          {allImages.length > 1 && (
            <div style={{ display: 'flex', gap: '0.5rem', marginTop: '0.75rem', flexWrap: 'wrap' }}>
              {allImages.map((img, i) => (
                <img key={i} src={img} alt="" onClick={() => setSelectedImage(i)}
                  onError={e => { e.currentTarget.src = 'https://placehold.co/72x72/F1F3F4/9C9FA1?text=?'; e.currentTarget.onerror = null; }}
                  style={{
                    width: 72, height: 72, objectFit: 'cover', borderRadius: 'var(--radius)',
                    cursor: 'pointer',
                    border: `2px solid ${i === selectedImage ? 'var(--primary)' : 'var(--border)'}`,
                    opacity: i === selectedImage ? 1 : 0.7,
                  }}
                />
              ))}
            </div>
          )}
        </div>

        {/* Right: Product Info */}
        <div className="details">
          <div className="category" style={{ color: 'var(--text-light)', fontSize: '0.875rem' }}>
            <Link to={`/?category=${product.category_slug}`}>{product.category_name}</Link>
          </div>

          <h1>{product.name}</h1>

          {product.brand && (
            <p style={{ fontSize: '0.875rem', color: 'var(--text-light)', marginBottom: '0.25rem' }}>
              by <Link to={`/?brand=${encodeURIComponent(product.brand)}`} style={{ color: 'var(--primary)' }}>{product.brand}</Link>
            </p>
          )}

          {product.review_count > 0 && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <Stars rating={product.avg_rating} />
              <a href="#reviews" style={{ fontSize: '0.875rem', color: 'var(--text-light)' }}>
                {product.avg_rating} ({product.review_count} review{product.review_count !== 1 ? 's' : ''})
              </a>
            </div>
          )}

          <div className="price" style={{ marginBottom: '0.5rem' }}>
            ${(displayPrice || product.price).toFixed(2)}
          </div>
          <p className="description">{product.description}</p>

          {/* Variants */}
          {groupedVariants && Object.keys(groupedVariants).length > 0 && (
            <div style={{ marginBottom: '1rem' }}>
              {Object.entries(groupedVariants).map(([name, variants]) => (
                <div key={name} style={{ marginBottom: '0.75rem' }}>
                  <p style={{ fontWeight: 600, fontSize: '0.875rem', marginBottom: '0.375rem' }}>{name}:</p>
                  <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                    {variants.map(v => (
                      <button
                        key={v.id}
                        onClick={() => setSelectedVariant(selectedVariant?.id === v.id ? null : v)}
                        className="btn-primary btn-sm"
                        disabled={v.stock === 0}
                        style={{ opacity: v.stock === 0 ? 0.4 : 1 }}
                      >
                        {v.value}{v.price_modifier ? ` (+$${v.price_modifier})` : ''}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className={`stock ${product.stock > 0 ? 'in-stock' : 'out-of-stock'}`}>
            {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
          </div>

          {product.stock > 0 && (
            <>
              <div className="quantity-control">
                <button className="btn-sm btn-primary" onClick={() => setQuantity(q => Math.max(1, q - 1))}>−</button>
                <span>{quantity}</span>
                <button className="btn-sm btn-primary" onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}>+</button>
              </div>
              <button className="btn btn-primary btn-full" onClick={handleAdd}>
                {added ? '✓ Added to Cart!' : 'Add to Cart'}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Specs */}
      {product.specs?.length > 0 && (
        <div style={{ marginTop: '2rem' }}>
          <h2 style={{ marginBottom: '0.75rem' }}>Product Details</h2>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.875rem' }}>
            <tbody>
              {product.specs.map(s => (
                <tr key={s.id} style={{ borderBottom: '1px solid var(--border)' }}>
                  <td style={{ padding: '0.5rem 0.75rem', fontWeight: 600, width: '35%', background: '#f8f9fa' }}>{s.key}</td>
                  <td style={{ padding: '0.5rem 0.75rem' }}>{s.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Also Bought */}
      <AlsoBought productId={product.id} />

      {/* Also Viewed */}
      {product.alsoViewed?.length > 0 && (
        <div style={{ marginTop: '2rem', borderTop: '1px solid var(--border)', paddingTop: '2rem' }}>
          <h2 style={{ marginBottom: '1rem' }}>Customers Who Viewed This Also Viewed</h2>
          <div style={{ display: 'flex', gap: '1rem', overflowX: 'auto', paddingBottom: '0.5rem' }}>
            {product.alsoViewed.map(p => (
              <Link key={p.id} to={`/product/${p.slug}`} style={{ textDecoration: 'none', flexShrink: 0, width: 150 }}>
                <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius)', overflow: 'hidden', background: '#fff' }}>
                  <img src={p.image_url} alt={p.name}
                    style={{ width: '100%', height: 110, objectFit: 'cover' }}
                    onError={e => { e.currentTarget.src = 'https://placehold.co/150x120/F1F3F4/9C9FA1?text=No+Image'; e.currentTarget.onerror = null; }} />
                  <div style={{ padding: '0.5rem' }}>
                    <div style={{ fontSize: '0.8rem', fontWeight: 600, marginBottom: '0.25rem', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#111' }}>{p.name}</div>
                    {p.avg_rating > 0 && <div style={{ fontSize: '0.75rem', color: '#f59e0b' }}>{'★'.repeat(Math.round(p.avg_rating))}</div>}
                    <div style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--primary)' }}>${Number(p.price).toFixed(2)}</div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Reviews */}
      <div id="reviews" style={{ marginTop: '2rem', borderTop: '1px solid var(--border)', paddingTop: '2rem' }}>
        {product.ratingDist?.length > 0 && (
          <div style={{ marginBottom: '1.5rem' }}>
            <h3 style={{ fontSize: '1.1rem', marginBottom: '0.75rem' }}>Customer Reviews</h3>
            <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start', flexWrap: 'wrap' }}>
              <div style={{ textAlign: 'center', minWidth: 90 }}>
                <div style={{ fontSize: '3rem', fontWeight: 800, color: '#111', lineHeight: 1 }}>{product.avg_rating}</div>
                <Stars rating={product.avg_rating} />
                <div style={{ fontSize: '0.75rem', color: 'var(--text-light)', marginTop: '0.25rem' }}>out of 5</div>
              </div>
              <div style={{ flex: 1, minWidth: 200 }}>
                {[5,4,3,2,1].map(star => {
                  const entry = product.ratingDist.find(r => r.rating === star);
                  const count = entry?.count || 0;
                  const pct = product.review_count > 0 ? (count / product.review_count) * 100 : 0;
                  return (
                    <div key={star} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.3rem' }}>
                      <span style={{ fontSize: '0.8rem', width: 40, color: 'var(--text-light)' }}>{star} star</span>
                      <div style={{ flex: 1, height: 12, background: '#e5e7eb', borderRadius: 6, overflow: 'hidden' }}>
                        <div style={{ width: `${pct}%`, height: '100%', background: pct > 0 ? '#f59e0b' : 'transparent', borderRadius: 6, transition: 'width 0.3s' }} />
                      </div>
                      <span style={{ fontSize: '0.75rem', width: 30, textAlign: 'right', color: 'var(--text-light)' }}>{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
        <ProductReviews productId={product.id} />
      </div>

      {/* Related Products */}
      {product.related?.length > 0 && (
        <div style={{ marginTop: '3rem', borderTop: '1px solid var(--border)', paddingTop: '2rem' }}>
          <h2 style={{ marginBottom: '1rem' }}>You Might Also Like</h2>
          <div className="product-grid">
            {product.related.map(p => <ProductCard key={p.id} product={p} />)}
          </div>
        </div>
      )}
    </div>
  );
}
