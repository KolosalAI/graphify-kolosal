import { useState } from 'react';
import { ProductCard, SearchBar, BannerCarousel, FlashSale,
         CategoryShowcase, DealsOfDay } from '@components';
import { useProducts, useCategories } from '@hooks';

export default function HomePage() {
  const [filters, setFilters] = useState({
    search: '', category: '', sort: 'name_asc',
    minPrice: '', maxPrice: '', inStock: false,
  });
  const [page, setPage] = useState(1);

  const { categories } = useCategories();
  const { products, pagination, loading } = useProducts({ ...filters, page, limit: 12 });
  const totalPages = pagination.totalPages || 1;

  const clearFilters = () => {
    setFilters({ search: '', category: '', sort: 'name_asc', minPrice: '', maxPrice: '', inStock: false });
    setPage(1);
  };

  const hasActiveFilters = filters.search || filters.category || filters.minPrice ||
    filters.maxPrice || filters.inStock || filters.sort !== 'name_asc';

  return (
    <div className="container">
      {/* Banner Carousel */}
      <BannerCarousel />

      {/* Category Showcase */}
      <CategoryShowcase />

      {/* Deals of the Day */}
      <DealsOfDay />

      {/* Flash Sale */}
      <FlashSale />

      {/* Search Bar */}
      <SearchBar
        value={filters.search}
        onSearch={(q) => { setFilters(f => ({ ...f, search: q })); setPage(1); }}
      />

      {/* Filters */}
      <div className="filters-bar">
        <select value={filters.category} onChange={e => { setFilters(f => ({ ...f, category: e.target.value })); setPage(1); }}>
          <option value="">All Categories</option>
          {categories.map(c => <option key={c.id} value={c.slug}>{c.name}</option>)}
        </select>

        <select value={filters.sort} onChange={e => { setFilters(f => ({ ...f, sort: e.target.value })); setPage(1); }}>
          <option value="name_asc">Name A–Z</option>
          <option value="name_desc">Name Z–A</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="rating_desc">Highest Rated</option>
          <option value="newest">Newest First</option>
        </select>

        <input type="number" placeholder="Min $" value={filters.minPrice} min="0"
          onChange={e => { setFilters(f => ({ ...f, minPrice: e.target.value })); setPage(1); }} />

        <input type="number" placeholder="Max $" value={filters.maxPrice} min="0"
          onChange={e => { setFilters(f => ({ ...f, maxPrice: e.target.value })); setPage(1); }} />

        <label className="filter-stock-label">
          <input type="checkbox" checked={filters.inStock}
            onChange={e => { setFilters(f => ({ ...f, inStock: e.target.checked })); setPage(1); }} />
          In Stock
        </label>

        {hasActiveFilters && (
          <button className="btn-sm btn-primary" onClick={clearFilters}>Clear</button>
        )}
      </div>

      {/* Product Grid */}
      {loading ? (
        <div className="loading">Loading products...</div>
      ) : products.length === 0 ? (
        <div className="empty-state">
          <h2>No products found</h2>
          <p>Try adjusting your filters.</p>
          <button className="btn-md btn-primary" onClick={clearFilters}>Clear Filters</button>
        </div>
      ) : (
        <div className="product-grid">
          {products.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="pagination">
          <button className="btn-sm btn-primary" onClick={() => setPage(p => p - 1)} disabled={page === 1}>← Prev</button>
          <span style={{ fontSize: 'var(--font-size-sm)', color: 'var(--color-text-700)' }}>Page {page} of {totalPages}</span>
          <button className="btn-sm btn-primary" onClick={() => setPage(p => p + 1)} disabled={page === totalPages}>Next →</button>
        </div>
      )}
    </div>
  );
}
