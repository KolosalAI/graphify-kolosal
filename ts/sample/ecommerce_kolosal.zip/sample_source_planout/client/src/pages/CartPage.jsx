import { Link } from 'react-router-dom';
import { useCart } from '@context';

export default function CartPage() {
  const { cart, removeItem, updateQuantity, totalPrice } = useCart();

  if (cart.length === 0) {
    return (
      <div className="container empty-state" style={{ paddingTop: '3rem' }}>
        <h2>Your cart is empty</h2>
        <p style={{ marginBottom: '1rem' }}>Add some products to get started!</p>
        <Link to="/"><button className="btn btn-primary">Browse Products</button></Link>
      </div>
    );
  }

  return (
    <div className="container cart-page">
      <h1>Shopping Cart</h1>

      {cart.map(item => (
        <div key={item.id} className="cart-item">
          <img src={item.image_url} alt={item.name} onError={e => { e.target.src = 'https://placehold.co/80x80?text=No+Image'; }} />
          <div className="item-info">
            <h3><Link to={`/product/${item.slug}`}>{item.name}</Link></h3>
            <div className="price">${item.price.toFixed(2)}</div>
          </div>
          <div className="item-actions">
            <div className="quantity-control">
              <button className="btn-sm btn-primary" onClick={() => updateQuantity(item.id, item.quantity - 1)}>−</button>
              <span>{item.quantity}</span>
              <button className="btn-sm btn-primary" onClick={() => updateQuantity(item.id, item.quantity + 1)}>+</button>
            </div>
            <div style={{ fontWeight: 700, minWidth: '5rem', textAlign: 'right' }}>
              ${(item.price * item.quantity).toFixed(2)}
            </div>
            <button className="btn-sm btn-danger" onClick={() => removeItem(item.id)}>✕</button>
          </div>
        </div>
      ))}

      <div className="cart-summary">
        <div className="total">
          <span>Total</span>
          <span>${totalPrice.toFixed(2)}</span>
        </div>
        <Link to="/checkout">
          <button className="btn btn-primary btn-full">Proceed to Checkout</button>
        </Link>
      </div>
    </div>
  );
}
