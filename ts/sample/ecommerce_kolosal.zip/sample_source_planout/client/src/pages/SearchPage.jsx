import { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useCart } from '@context';
import { useProducts, useCategories } from '@hooks';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { addItem } = useCart();
  const [addedId, setAddedId] = useState(null);

  const q = searchParams.get('q') || '';
  const categorySlug = searchParams.get('category') || '';
  const sort = searchParams.get('sort') || 'name_asc';
  const page = parseInt(searchParams.get('page') || '1');

  const { categories } = useCategories();
  const { products, pagination, loading } = useProducts({
    search: q,
    category: categorySlug,
    sort,
    page,
    limit: 16,
  });

  const update = (key, value) => {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value); else next.delete(key);
    next.set('page', '1');
    setSearchParams(next);
  };

  const handleAddToCart = (product) => {
    addItem(product);
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  const categoryName = categories.find(c => c.slug === categorySlug)?.name;
  const title = categoryName ? `${categoryName}` : q ? `Results for "${q}"` : 'All Products';

  return (
    <div className="container" style={{ padding: '1.5rem' }}>
      {/* Breadcrumb */}
      <div style={{ fontSize: '0.8rem', color: 'var(--text-light)', marginBottom: '1rem' }}>
        <Link to="/">Home</Link>
        {categoryName && <> › <Link to="/search">{categoryName}</Link></>}
        {q && <> › Search: "{q}"</>}
      </div>

      <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'flex-start' }}>
        {/* Sidebar filters */}
        <aside style={{ minWidth: 200, flexShrink: 0 }}>
          <div style={{ marginBottom: '1.5rem' }}>
            <h3 style={{ fontSize: '0.9rem', fontWeight: 700, marginBottom: '0.5rem', color: 'var(--text-light)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Category</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              <button
                onClick={() => update('category', '')}
                style={{ textAlign: 'left', padding: '4px 8px', borderRadius: 4, border: 'none', background: !categorySlug ? 'var(--primary)' : 'transparent', color: !categorySlug ? 'white' : 'inherit', cursor: 'pointer', fontSize: '0.875rem' }}
              >
                All Categories
              </button>
              {categories.map(c => (
                <button
                  key={c.id}
                  onClick={() => update('category', c.slug)}
                  style={{ textAlign: 'left', padding: '4px 8px', borderRadius: 4, border: 'none', background: c.slug === categorySlug ? 'var(--primary)' : 'transparent', color: c.slug === categorySlug ? 'white' : 'inherit', cursor: 'pointer', fontSize: '0.875rem' }}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>
          <div>
            <h3 style={{ fontSize: '0.9rem', fontWeight: 700, marginBottom: '0.5rem', color: 'var(--text-light)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Sort By</h3>
            <select
              value={sort}
              onChange={e => update('sort', e.target.value)}
              style={{ width: '100%', padding: '6px', borderRadius: 4, border: '1px solid var(--border)', fontSize: '0.875rem' }}
            >
              <option value="name_asc">Name A–Z</option>
              <option value="name_desc">Name Z–A</option>
              <option value="price_asc">Price: Low to High</option>
              <option value="price_desc">Price: High to Low</option>
              <option value="rating_desc">Highest Rated</option>
              <option value="newest">Newest</option>
            </select>
          </div>
        </aside>

        {/* Results */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
            <h1 style={{ fontSize: '1.3rem', margin: 0 }}>{title}</h1>
            {pagination.total != null && (
              <span style={{ fontSize: '0.875rem', color: 'var(--text-light)' }}>
                {pagination.total} result{pagination.total !== 1 ? 's' : ''}
              </span>
            )}
          </div>

          {loading ? (
            <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--text-light)' }}>Loading...</div>
          ) : products.length === 0 ? (
            <div style={{ padding: '3rem', textAlign: 'center' }}>
              <p style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>🔍 No products found</p>
              <p style={{ color: 'var(--text-light)' }}>Try a different search term or browse all categories.</p>
              <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={() => setSearchParams({})}>Clear filters</button>
            </div>
          ) : (
            <>
              <div className="product-grid">
                {products.map(product => (
                  <div key={product.id} className="product-card">
                    <Link to={`/product/${product.slug}`}>
                      <img src={product.image_url} alt={product.name} className="product-image" onError={e => { e.currentTarget.src = 'https://placehold.co/400x300/F1F3F4/9C9FA1?text=No+Image'; e.currentTarget.onerror = null; }} />
                    </Link>
                    <div className="info">
                      {product.badge && (
                        <span style={{ fontSize: '0.7rem', background: '#ff9900', color: 'white', padding: '2px 6px', borderRadius: 3, fontWeight: 700, marginBottom: 4, display: 'inline-block' }}>
                          {product.badge}
                        </span>
                      )}
                      <h3><Link to={`/product/${product.slug}`}>{product.name}</Link></h3>
                      {product.avg_rating > 0 && (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                          <span style={{ color: '#f59e0b', fontSize: '0.8rem' }}>
                            {'★'.repeat(Math.round(product.avg_rating))}{'☆'.repeat(5 - Math.round(product.avg_rating))}
                            <span style={{ color: 'var(--text-light)', marginLeft: 4 }}>({product.review_count})</span>
                          </span>
                        </div>
                      )}
                      <div className="actions">
                        <p className="price">${parseFloat(product.price).toFixed(2)}</p>
                        <button
                          className="btn-sm btn-primary"
                          onClick={() => handleAddToCart(product)}
                          disabled={product.stock === 0}
                        >
                          {product.stock === 0 ? 'Out of Stock' : addedId === product.id ? '✓ Added!' : 'Add to Cart'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {pagination.totalPages > 1 && (
                <div style={{ display: 'flex', justifyContent: 'center', gap: 8, marginTop: '2rem' }}>
                  {Array.from({ length: pagination.totalPages }, (_, i) => i + 1).map(p => (
                    <button
                      key={p}
                      onClick={() => { const n = new URLSearchParams(searchParams); n.set('page', p); setSearchParams(n); }}
                      className="btn-sm btn-primary"
                    >
                      {p}
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
