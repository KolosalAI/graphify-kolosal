import { useState, useEffect, useCallback } from 'react';
import { categoryService, productService } from '../services/index.js';

/**
 * Hook for fetching the categories list.
 * Result is stable — categories rarely change, so it fetches once.
 */
export function useCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    categoryService.list()
      .then(setCategories)
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return { categories, loading, error };
}

/**
 * Hook for listing products with filters, sorting, and pagination.
 *
 * @param {Object} params - { search, category, sort, minPrice, maxPrice, inStock, brand, minRating, page, limit }
 */
export function useProducts(params = {}) {
  const [products, setProducts] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 });
  const [priceRange, setPriceRange] = useState({ min: 0, max: 9999 });
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Normalize param keys to API param keys
  const fetchProducts = useCallback(() => {
    setLoading(true);
    setError(null);

    const apiParams = {};
    if (params.search)    apiParams.search    = params.search;
    if (params.category)  apiParams.category  = params.category;
    if (params.sort)      apiParams.sort      = params.sort;
    if (params.minPrice)  apiParams.min_price = params.minPrice;
    if (params.maxPrice)  apiParams.max_price = params.maxPrice;
    if (params.inStock)   apiParams.in_stock  = 'true';
    if (params.brand)     apiParams.brand     = params.brand;
    if (params.minRating) apiParams.min_rating = params.minRating;
    if (params.page)      apiParams.page      = params.page;
    if (params.limit)     apiParams.limit     = params.limit;

    productService.list(apiParams)
      .then(data => {
        setProducts(data.products || []);
        setPagination({
          page: data.pagination?.page || 1,
          totalPages: data.pagination?.totalPages || 1,
          total: data.pagination?.total || 0,
          limit: data.pagination?.limit || 12,
        });
        if (data.priceRange) setPriceRange(data.priceRange);
        if (data.brands)     setBrands(data.brands);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [
    params.search, params.category, params.sort, params.minPrice,
    params.maxPrice, params.inStock, params.brand, params.minRating,
    params.page, params.limit,
  ]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  return { products, pagination, priceRange, brands, loading, error, refetch: fetchProducts };
}

/**
 * Hook for fetching a single product by slug.
 */
export function useProduct(slug) {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!slug) return;
    setLoading(true);
    setError(null);
    productService.getBySlug(slug)
      .then(setProduct)
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, [slug]);

  return { product, loading, error };
}

/**
 * Hook for search suggestions (autocomplete).
 */
export function useProductSuggestions(query) {
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query || query.length < 2) { setSuggestions([]); return; }
    setLoading(true);
    productService.getSuggestions(query)
      .then(setSuggestions)
      .catch(() => setSuggestions([]))
      .finally(() => setLoading(false));
  }, [query]);

  return { suggestions, loading };
}
