export { useProducts, useProduct, useProductSuggestions, useCategories } from './useProducts.js';
