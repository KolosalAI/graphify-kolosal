import { apiClient } from './apiClient.js';

export const bannerService = {
  /** Get all active banners for the carousel */
  list() {
    return apiClient.get('/api/banners/admin');
  },

  /** Create a new banner (admin) */
  create(payload) {
    return apiClient.post('/api/banners', payload);
  },

  /** Update a banner (admin) */
  update(id, payload) {
    return apiClient.put(`/api/banners/${id}`, payload);
  },

  /** Delete a banner (admin) */
  delete(id) {
    return apiClient.delete(`/api/banners/${id}`);
  },

  /** Toggle a banner's active state (admin) */
  toggle(id) {
    return apiClient.patch(`/api/banners/${id}/toggle`, {});
  },
};

export const flashSaleService = {
  /** Get all flash sales (admin) */
  list() {
    return apiClient.get('/api/flash-sales');
  },

  /** Get a specific flash sale by ID with items */
  getById(id) {
    return apiClient.get(`/api/flash-sales/${id}`);
  },

  /** Create a new flash sale (admin) */
  create(payload) {
    return apiClient.post('/api/flash-sales', payload);
  },

  /** Update a flash sale (admin) */
  update(id, payload) {
    return apiClient.put(`/api/flash-sales/${id}`, payload);
  },

  /** Delete a flash sale (admin) */
  delete(id) {
    return apiClient.delete(`/api/flash-sales/${id}`);
  },

  /** Add an item to a flash sale (admin) */
  addItem(saleId, payload) {
    return apiClient.post(`/api/flash-sales/${saleId}/items`, payload);
  },

  /** Toggle a flash sale's active state (admin) */
  toggle(id) {
    return apiClient.patch(`/api/flash-sales/${id}/toggle`, {});
  },

  /** Update an item in a flash sale (admin) */
  updateItem(saleId, itemId, payload) {
    return apiClient.put(`/api/flash-sales/${saleId}/items/${itemId}`, payload);
  },

  /** Remove an item from a flash sale (admin) */
  removeItem(saleId, itemId) {
    return apiClient.delete(`/api/flash-sales/${saleId}/items/${itemId}`);
  },
};

export const dealService = {
  /** Get deals (admin view) */
  list() {
    return apiClient.get('/api/deals/admin');
  },

  /** Create a new deal (admin) */
  create(payload) {
    return apiClient.post('/api/deals', payload);
  },

  /** Update a deal (admin) */
  update(id, payload) {
    return apiClient.patch(`/api/deals/${id}`, payload);
  },

  /** Delete a deal (admin) */
  delete(id) {
    return apiClient.delete(`/api/deals/${id}`);
  },
};

export const recommendationService = {
  /** Get personalized recommendations for the authenticated user */
  getPersonalized() {
    return apiClient.get('/api/recommendations');
  },

  /** Get "also bought" recommendations for a product */
  getAlsoBought(productId) {
    return apiClient.get(`/api/recommendations/also-bought/${productId}`);
  },
};

export const invoiceService = {
  /** Get all invoices for the authenticated user */
  list() {
    return apiClient.get('/api/invoices');
  },

  /** Get a specific invoice */
  getById(id) {
    return apiClient.get(`/api/invoices/${id}`);
  },
};
