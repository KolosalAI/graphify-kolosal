import { apiClient } from './apiClient.js';

export const productService = {
  /**
   * List products with optional filters and pagination.
   * @param {Object} params - search, category, sort, min_price, max_price, in_stock, brand, min_rating, page, limit
   * @returns {Promise<{products, pagination, priceRange, brands}>}
   */
  list(params = {}) {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v !== '' && v !== null && v !== undefined && v !== false) qs.set(k, v);
    });
    return apiClient.get(`/api/products?${qs}`);
  },

  /**
   * Get a single product by its slug, including images, variants, specs, related, etc.
   */
  getBySlug(slug, sessionId = null) {
    const headers = sessionId ? { 'x-session-id': sessionId } : {};
    return apiClient.get(`/api/products/${slug}`, { headers });
  },

  /** Autocomplete/search suggestions */
  getSuggestions(query) {
    if (!query || query.length < 2) return Promise.resolve([]);
    return apiClient.get(`/api/products/suggestions?q=${encodeURIComponent(query)}`);
  },

  /** Set a price watch alert for a product */
  watchPrice(productId) {
    return apiClient.post(`/api/products/${productId}/watch`, {});
  },

  /** Create a new product (admin) */
  create(payload) {
    return apiClient.post('/api/admin/products', payload);
  },

  /** Update a product (admin) */
  update(id, payload) {
    return apiClient.put(`/api/products/${id}`, payload);
  },

  /** Delete a product (admin) */
  delete(id) {
    return apiClient.delete(`/api/products/${id}`);
  },
};

export const categoryService = {
  list() {
    return apiClient.get('/api/categories');
  },

  getBySlug(slug) {
    return apiClient.get(`/api/categories/${slug}`);
  },
};
