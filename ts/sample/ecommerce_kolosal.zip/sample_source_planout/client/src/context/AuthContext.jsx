import { createContext, useContext, useCallback } from 'react';

export const AuthContext = createContext();

// DEMO MODE — user is always logged in as Jane (admin).
const DEMO_USER = {
  id: 2,
  name: 'Jane Smith',
  email: 'jane@example.com',
  role: 'admin',
  subscription_plan: 'prime',
  loyalty_points_balance: 850,
  referral_code: 'JANE2024',
};

export function AuthProvider({ children }) {
  // No token needed — server accepts all requests as demo user.
  const authFetch = useCallback(async (url, options = {}) => {
    const headers = { ...options.headers };
    if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }
    return fetch(url, { ...options, headers });
  }, []);

  const login    = useCallback(async () => DEMO_USER, []);
  const register = useCallback(async () => DEMO_USER, []);
  const logout   = useCallback(() => {
    alert('Demo mode — login/logout is disabled.');
  }, []);

  return (
    <AuthContext.Provider value={{
      user: DEMO_USER,
      token: null,
      loading: false,
      login,
      register,
      logout,
      authFetch,
      isAdmin: true,
      isSeller: false,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
