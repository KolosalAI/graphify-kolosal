import { createContext, useContext, useReducer, useCallback, useEffect, useRef } from 'react';

const CartContext = createContext();

const STORAGE_KEY = 'shopkolosal_cart';

const loadFromStorage = () => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
};

const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_ITEM': {
      const existing = state.find(item => item.id === action.payload.id);
      if (existing) {
        return state.map(item =>
          item.id === action.payload.id
            ? { ...item, quantity: item.quantity + (action.payload.quantity || 1) }
            : item
        );
      }
      return [...state, { ...action.payload, quantity: action.payload.quantity || 1 }];
    }
    case 'REMOVE_ITEM':
      return state.filter(item => item.id !== action.payload);
    case 'UPDATE_QUANTITY':
      if (action.payload.quantity <= 0) {
        return state.filter(item => item.id !== action.payload.id);
      }
      return state.map(item =>
        item.id === action.payload.id
          ? { ...item, quantity: action.payload.quantity }
          : item
      );
    case 'CLEAR':
      return [];
    case 'LOAD':
      return action.payload;
    default:
      return state;
  }
};

export function CartProvider({ children }) {
  const [cart, dispatch] = useReducer(cartReducer, [], loadFromStorage);
  const syncTimeout = useRef(null);

  // Persist to localStorage on every cart change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
  }, [cart]);

  // Sync to server for logged-in users (debounced 1s)
  const syncToServer = useCallback((items) => {
    const token = localStorage.getItem('token');
    if (!token) return;
    clearTimeout(syncTimeout.current);
    syncTimeout.current = setTimeout(() => {
      fetch('/api/cart/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ items: items.map(i => ({ id: i.id, quantity: i.quantity })) }),
      }).catch(() => {});
    }, 1000);
  }, []);

  const addItem = useCallback((product, quantity = 1) => {
    dispatch({ type: 'ADD_ITEM', payload: { ...product, quantity } });
  }, []);

  const removeItem = useCallback((id) => {
    dispatch({ type: 'REMOVE_ITEM', payload: id });
  }, []);

  const updateQuantity = useCallback((id, quantity) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
  }, []);

  const clearCart = useCallback(() => {
    dispatch({ type: 'CLEAR' });
    const token = localStorage.getItem('token');
    if (token) {
      fetch('/api/cart', { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }).catch(() => {});
    }
  }, []);

  // Expose loadCartFromServer so AuthContext can call it after login
  const loadCartFromServer = useCallback(async (token) => {
    try {
      const res = await fetch('/api/cart', { headers: { Authorization: `Bearer ${token}` } });
      if (!res.ok) return;
      const serverItems = await res.json();
      if (!Array.isArray(serverItems) || serverItems.length === 0) return;
      // Merge: server items take precedence, but add any local-only items
      const localCart = loadFromStorage();
      const merged = [...serverItems];
      for (const local of localCart) {
        if (!merged.find(s => s.id === local.id)) merged.push(local);
      }
      dispatch({ type: 'LOAD', payload: merged });
    } catch {}
  }, []);

  // Sync on cart changes (after initial load)
  const isFirstRender = useRef(true);
  useEffect(() => {
    if (isFirstRender.current) { isFirstRender.current = false; return; }
    syncToServer(cart);
  }, [cart, syncToServer]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const totalItems = cartCount;
  const totalPrice = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <CartContext.Provider value={{ cart, addItem, removeItem, updateQuantity, clearCart, loadCartFromServer, totalItems, cartCount, totalPrice }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);

