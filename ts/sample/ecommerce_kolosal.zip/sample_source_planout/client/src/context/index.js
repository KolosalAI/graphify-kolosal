// client/src/context/index.js
export { AuthProvider, useAuth } from './AuthContext';
export { CartProvider, useCart } from './CartContext';
