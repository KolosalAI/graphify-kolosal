import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import DealsOfDay from '../../src/components/DealsOfDay';

const futureDate = new Date(Date.now() + 3600000).toISOString();

const mockDeals = [
  {
    id: 1,
    name: 'Wireless Headphones',
    slug: 'wireless-headphones',
    image_url: '/headphones.jpg',
    sale_price: 49.99,
    original_price: 99.99,
    ends_at: futureDate,
  },
  {
    id: 2,
    name: 'Smart Watch',
    slug: 'smart-watch',
    image_url: '/watch.jpg',
    sale_price: 149.99,
    original_price: 199.99,
    ends_at: futureDate,
  },
];

function renderDeals() {
  return render(<MemoryRouter><DealsOfDay /></MemoryRouter>);
}

describe('DealsOfDay', () => {
  it('renders nothing when deals are empty', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
    const { container } = renderDeals();
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith('/api/deals'));
    expect(container.firstChild).toBeNull();
  });

  it('renders the section heading when deals exist', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockDeals });
    renderDeals();
    await waitFor(() => expect(screen.getByText(/Deals of the Day/i)).toBeInTheDocument());
  });

  it('renders all deal product names', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockDeals });
    renderDeals();
    await waitFor(() => {
      expect(screen.getByText('Wireless Headphones')).toBeInTheDocument();
      expect(screen.getByText('Smart Watch')).toBeInTheDocument();
    });
  });

  it('shows sale price for each deal', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockDeals });
    renderDeals();
    await waitFor(() => {
      expect(screen.getByText('$49.99')).toBeInTheDocument();
      expect(screen.getByText('$149.99')).toBeInTheDocument();
    });
  });

  it('shows discount percentage badge', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockDeals });
    renderDeals();
    await waitFor(() => {
      // Both the card badge and PriceDisplay render the pct — use getAllByText
      expect(screen.getAllByText('-50%').length).toBeGreaterThan(0);
    });
  });

  it('shows countdown timer for active deals', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockDeals });
    renderDeals();
    await waitFor(() => {
      expect(screen.getAllByText(/Ends in:/i).length).toBeGreaterThan(0);
    });
  });
});
