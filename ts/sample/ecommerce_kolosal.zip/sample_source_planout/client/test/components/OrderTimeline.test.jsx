import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import OrderTimeline from '../../src/components/OrderTimeline';

describe('OrderTimeline', () => {
  it('renders all four timeline steps', () => {
    render(<OrderTimeline status="pending" />);
    expect(screen.getByText('Order Placed')).toBeInTheDocument();
    expect(screen.getByText('Confirmed')).toBeInTheDocument();
    expect(screen.getByText('Shipped')).toBeInTheDocument();
    expect(screen.getByText('Delivered')).toBeInTheDocument();
  });

  it('renders the current step label with bold font weight', () => {
    render(<OrderTimeline status="shipped" />);
    const shippedLabel = screen.getByText('Shipped');
    expect(shippedLabel).toHaveStyle({ fontWeight: 'var(--font-weight-bold)' });
  });

  it('shows cancelled state when status is cancelled', () => {
    render(<OrderTimeline status="cancelled" />);
    expect(screen.getByText(/Order Cancelled/i)).toBeInTheDocument();
    expect(screen.queryByText('Order Placed')).not.toBeInTheDocument();
  });

  it('shows returned state when status is returned', () => {
    render(<OrderTimeline status="returned" />);
    expect(screen.getByText(/Order Returned/i)).toBeInTheDocument();
  });

  it('shows estimated delivery when provided and not delivered', () => {
    render(<OrderTimeline status="shipped" estimatedDelivery="2030-12-25" />);
    expect(screen.getByText(/Estimated delivery/i)).toBeInTheDocument();
    expect(screen.getByText(/Wednesday, December 25/i)).toBeInTheDocument();
  });

  it('does not show estimated delivery when status is delivered', () => {
    render(<OrderTimeline status="delivered" estimatedDelivery="2030-12-25" />);
    expect(screen.queryByText(/Estimated delivery/i)).not.toBeInTheDocument();
  });
});
