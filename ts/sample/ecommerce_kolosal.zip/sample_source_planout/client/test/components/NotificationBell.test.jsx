import { describe, it, expect } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import NotificationBell from '../../src/components/NotificationBell';

const mockUser = { id: 1, name: 'Alice', email: 'alice@test.com', role: 'user' };

const mockNotifications = {
  notifications: [
    { id: 1, title: 'Order shipped', body: 'Your order is on the way', read: 0, created_at: new Date().toISOString() },
    { id: 2, title: 'Promo available', body: '20% off today!', read: 1, created_at: new Date().toISOString() },
  ],
  unreadCount: 1,
};

function renderBell() {
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>
          <NotificationBell />
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('NotificationBell', () => {
  it('renders nothing when user is not authenticated', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    const { container } = renderBell();
    // No token → AuthProvider doesn't call fetch; bell renders nothing
    await new Promise(r => setTimeout(r, 50));
    expect(container.firstChild).toBeNull();
  });

  it('renders bell button when user is authenticated', async () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => mockUser });
      if (url.includes('/api/notifications')) return Promise.resolve({ ok: true, json: async () => ({ notifications: [], unreadCount: 0 }) });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderBell();
    await waitFor(() => expect(screen.getByTitle('Notifications')).toBeInTheDocument());
  });

  it('shows unread count badge when there are unread notifications', async () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => mockUser });
      if (url.includes('/api/notifications')) return Promise.resolve({ ok: true, json: async () => mockNotifications });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderBell();
    await waitFor(() => expect(screen.getByText('1')).toBeInTheDocument());
  });

  it('does not show badge when unread count is 0', async () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => mockUser });
      if (url.includes('/api/notifications')) return Promise.resolve({ ok: true, json: async () => ({ notifications: [], unreadCount: 0 }) });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderBell();
    await waitFor(() => expect(screen.getByTitle('Notifications')).toBeInTheDocument());
    expect(screen.queryByText('0')).toBeNull();
  });

  it('shows notifications list when bell is clicked', async () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => mockUser });
      if (url.includes('/api/notifications')) return Promise.resolve({ ok: true, json: async () => mockNotifications });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderBell();
    const bell = await screen.findByTitle('Notifications');
    fireEvent.click(bell);
    await waitFor(() => expect(screen.getByText('Order shipped')).toBeInTheDocument());
  });
});
