import { describe, it, expect } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, useLocation } from 'react-router-dom';
import CategoryShowcase from '../../src/components/CategoryShowcase';

const mockCategories = [
  { id: 1, name: 'Electronics', slug: 'electronics', product_count: 42 },
  { id: 2, name: 'Clothing', slug: 'clothing', product_count: 18 },
  { id: 3, name: 'Books', slug: 'books', product_count: 7 },
];

function renderShowcase() {
  return render(<MemoryRouter><CategoryShowcase /></MemoryRouter>);
}

describe('CategoryShowcase', () => {
  it('renders nothing when categories are empty', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
    const { container } = renderShowcase();
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith('/api/categories'));
    expect(container.firstChild).toBeNull();
  });

  it('renders the section title when categories are provided', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockCategories });
    renderShowcase();
    await waitFor(() => expect(screen.getByText('Shop by Category')).toBeInTheDocument());
  });

  it('shows all category names', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockCategories });
    renderShowcase();
    await waitFor(() => {
      expect(screen.getByText('Electronics')).toBeInTheDocument();
      expect(screen.getByText('Clothing')).toBeInTheDocument();
      expect(screen.getByText('Books')).toBeInTheDocument();
    });
  });

  it('shows product count for each category', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockCategories });
    renderShowcase();
    await waitFor(() => expect(screen.getByText('42 items')).toBeInTheDocument());
  });

  it('renders known category icons', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockCategories });
    renderShowcase();
    await waitFor(() => {
      expect(screen.getByText('💻')).toBeInTheDocument();
      expect(screen.getByText('👗')).toBeInTheDocument();
      expect(screen.getByText('📚')).toBeInTheDocument();
    });
  });
});
