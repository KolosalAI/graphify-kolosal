import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import RecentlyViewed, { trackRecentlyViewed } from '../../src/components/RecentlyViewed';

const mockProducts = [
  { id: 1, name: 'Laptop Pro', slug: 'laptop-pro', price: 999.99, image_url: '/laptop.jpg', category_name: 'Electronics', stock: 5, avg_rating: 4.5, review_count: 10 },
  { id: 2, name: 'Wireless Mouse', slug: 'wireless-mouse', price: 29.99, image_url: '/mouse.jpg', category_name: 'Electronics', stock: 20, avg_rating: 4.0, review_count: 5 },
];

function renderRecentlyViewed(props = {}) {
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
    return Promise.resolve({ ok: true, json: async () => [] });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>
          <RecentlyViewed {...props} />
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('RecentlyViewed', () => {
  it('renders nothing when localStorage has no recently viewed items', () => {
    localStorage.getItem.mockReturnValue(null);
    const { container } = renderRecentlyViewed();
    expect(container.firstChild).toBeNull();
  });

  it('renders the section title when products exist in localStorage', async () => {
    localStorage.getItem.mockImplementation((key) => {
      if (key === 'recently_viewed') return JSON.stringify(mockProducts);
      return null;
    });
    renderRecentlyViewed();
    await waitFor(() => expect(screen.getByText('Recently Viewed')).toBeInTheDocument());
  });

  it('renders product cards for stored products', async () => {
    localStorage.getItem.mockImplementation((key) => {
      if (key === 'recently_viewed') return JSON.stringify(mockProducts);
      return null;
    });
    renderRecentlyViewed();
    await waitFor(() => {
      expect(screen.getByText('Laptop Pro')).toBeInTheDocument();
      expect(screen.getByText('Wireless Mouse')).toBeInTheDocument();
    });
  });

  it('excludes the product matching excludeId', async () => {
    localStorage.getItem.mockImplementation((key) => {
      if (key === 'recently_viewed') return JSON.stringify(mockProducts);
      return null;
    });
    renderRecentlyViewed({ excludeId: 1 });
    await waitFor(() => expect(screen.getByText('Wireless Mouse')).toBeInTheDocument());
    expect(screen.queryByText('Laptop Pro')).not.toBeInTheDocument();
  });

  it('trackRecentlyViewed adds a product to localStorage', () => {
    const store = {};
    localStorage.getItem.mockImplementation(key => store[key] ?? null);
    localStorage.setItem.mockImplementation((key, val) => { store[key] = val; });

    const product = mockProducts[0];
    trackRecentlyViewed(product);

    const saved = JSON.parse(store['recently_viewed']);
    expect(saved[0].id).toBe(product.id);
  });
});
