import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import ProductCard from '../../src/components/ProductCard';

const mockProduct = {
  id: 1,
  name: 'Super Widget',
  slug: 'super-widget',
  price: 29.99,
  image_url: 'https://example.com/img.jpg',
  category_name: 'Electronics',
  stock: 10,
  avg_rating: 4.5,
  review_count: 20,
  badge: 'Best Seller',
};

const outOfStockProduct = { ...mockProduct, id: 2, stock: 0, badge: null, review_count: 0 };

function renderCard(product = mockProduct) {
  return render(
    <MemoryRouter>
      <CartProvider>
        <ProductCard product={product} />
      </CartProvider>
    </MemoryRouter>
  );
}

describe('ProductCard component', () => {
  it('renders product name', () => {
    renderCard();
    expect(screen.getByText('Super Widget')).toBeInTheDocument();
  });

  it('renders product price formatted to 2 decimals', () => {
    renderCard();
    expect(screen.getByText('$29.99')).toBeInTheDocument();
  });

  it('renders category name', () => {
    renderCard();
    expect(screen.getByText('Electronics')).toBeInTheDocument();
  });

  it('renders product image with alt text', () => {
    renderCard();
    const img = screen.getByAltText('Super Widget');
    expect(img).toBeInTheDocument();
    expect(img.src).toBe('https://example.com/img.jpg');
  });

  it('renders badge when present', () => {
    renderCard();
    expect(screen.getByText('Best Seller')).toBeInTheDocument();
  });

  it('does not render badge when absent', () => {
    renderCard(outOfStockProduct);
    expect(screen.queryByText('Best Seller')).not.toBeInTheDocument();
  });

  it('shows "Add to Cart" button when in stock', () => {
    renderCard();
    expect(screen.getByRole('button', { name: /Add to Cart/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Add to Cart/i })).not.toBeDisabled();
  });

  it('shows "Out of Stock" button when stock is 0', () => {
    renderCard(outOfStockProduct);
    expect(screen.getByRole('button', { name: /Out of Stock/i })).toBeDisabled();
  });

  it('renders star rating when review_count > 0', () => {
    renderCard();
    expect(screen.getByText('(20)')).toBeInTheDocument();
  });

  it('does not render star rating when review_count is 0', () => {
    renderCard(outOfStockProduct);
    expect(screen.queryByText('(0)')).not.toBeInTheDocument();
  });

  it('links to the product page', () => {
    renderCard();
    const links = screen.getAllByRole('link');
    const productLink = links.find(l => l.getAttribute('href') === '/product/super-widget');
    expect(productLink).toBeInTheDocument();
  });
});
