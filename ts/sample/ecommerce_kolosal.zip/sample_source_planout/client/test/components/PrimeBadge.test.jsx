import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import PrimeBadge from '../../src/components/PrimeBadge';

describe('PrimeBadge', () => {
  it('renders the badge with star and prime text', () => {
    render(<PrimeBadge />);
    expect(screen.getByText(/★ prime/i)).toBeInTheDocument();
  });

  it('applies small font size by default (size="sm")', () => {
    render(<PrimeBadge />);
    const badge = screen.getByText(/★ prime/i);
    expect(badge).toHaveStyle({ fontSize: 'var(--font-size-xs)' });
  });

  it('applies larger font size when size="lg"', () => {
    render(<PrimeBadge size="lg" />);
    const badge = screen.getByText(/★ prime/i);
    expect(badge).toHaveStyle({ fontSize: 'var(--font-size-sm)' });
  });

  it('has the correct blue background color', () => {
    render(<PrimeBadge />);
    const badge = screen.getByText(/★ prime/i);
    expect(badge).toHaveStyle({ background: 'var(--color-prime)' });
  });
});
