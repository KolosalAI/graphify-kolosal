import { describe, it, expect } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import ProductQA from '../../src/components/ProductQA';

const mockQuestions = [
  {
    id: 1,
    question: 'Is this waterproof?',
    answer: 'Yes, it is IPX7 rated.',
    answerer_name: 'Seller',
    asker_name: 'Bob',
    helpful_count: 5,
    created_at: new Date().toISOString(),
  },
  {
    id: 2,
    question: 'Does it come with a warranty?',
    answer: null,
    answerer_name: null,
    asker_name: 'Carol',
    helpful_count: 0,
    created_at: new Date().toISOString(),
  },
];

function renderQA({ user = null, questions = [] } = {}) {
  if (user) {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => user });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
  } else {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
  }

  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>
          <ProductQA productId={42} questions={questions} />
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('ProductQA', () => {
  it('shows empty state message when no questions provided', async () => {
    renderQA({ questions: [] });
    // No token → fetch is not called; component renders immediately from props
    expect(screen.getByText(/No questions yet/i)).toBeInTheDocument();
  });

  it('renders the Q&A count in the heading', () => {
    renderQA({ questions: mockQuestions });
    expect(screen.getByText(/Questions & Answers \(2\)/i)).toBeInTheDocument();
  });

  it('renders question text', () => {
    renderQA({ questions: mockQuestions });
    expect(screen.getByText('Is this waterproof?')).toBeInTheDocument();
    expect(screen.getByText('Does it come with a warranty?')).toBeInTheDocument();
  });

  it('renders answer when present', () => {
    renderQA({ questions: mockQuestions });
    expect(screen.getByText('Yes, it is IPX7 rated.')).toBeInTheDocument();
  });

  it('shows "Ask a Question" button when user is authenticated', async () => {
    renderQA({ user: { id: 1, name: 'Alice', role: 'user' } });
    await waitFor(() => expect(screen.getByRole('button', { name: /Ask a Question/i })).toBeInTheDocument());
  });

  it('does not show "Ask a Question" button when unauthenticated', async () => {
    renderQA({ questions: [] });
    await waitFor(() => expect(global.fetch).toHaveBeenCalled());
    expect(screen.queryByRole('button', { name: /Ask a Question/i })).not.toBeInTheDocument();
  });

  it('shows ask form after clicking Ask a Question', async () => {
    renderQA({ user: { id: 1, name: 'Alice', role: 'user' } });
    const btn = await screen.findByRole('button', { name: /Ask a Question/i });
    fireEvent.click(btn);
    expect(screen.getByPlaceholderText(/What would you like to know/i)).toBeInTheDocument();
  });
});
