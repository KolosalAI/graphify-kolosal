import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import Header from '../../src/components/Header';

// Mock fetch for auth/me and notifications
beforeEach(() => {
  localStorage.getItem.mockReturnValue(null);
  global.fetch.mockResolvedValue({ ok: false, json: async () => ({}) });
});

function renderHeader() {
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>
          <Header />
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('Header component', () => {
  it('renders the logo', async () => {
    renderHeader();
    await waitFor(() => expect(screen.getByText(/ShopKolosal/i)).toBeInTheDocument());
  });

  it('shows Login and Register links when not authenticated', async () => {
    renderHeader();
    await waitFor(() => {
      expect(screen.getByRole('link', { name: /Login/i })).toBeInTheDocument();
      expect(screen.getByRole('link', { name: /Register/i })).toBeInTheDocument();
    });
  });

  it('shows Prime subscribe link when unauthenticated', async () => {
    renderHeader();
    await waitFor(() => {
      expect(screen.getByRole('link', { name: /Prime/i })).toBeInTheDocument();
    });
  });

  it('shows cart icon', async () => {
    renderHeader();
    await waitFor(() => {
      const cartLink = document.querySelector('a[href="/cart"]');
      expect(cartLink).toBeInTheDocument();
    });
  });

  it('shows Logout button when authenticated', async () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'tok' : null);
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ id: 1, name: 'Alice', email: 'alice@test.com', role: 'user' }),
    });

    renderHeader();
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Logout/i })).toBeInTheDocument();
    });
  });

  it('shows Admin link for admin user', async () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'admintok' : null);
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ id: 2, name: 'Admin', email: 'admin@test.com', role: 'admin' }),
    });

    renderHeader();
    await waitFor(() => {
      const adminLinks = screen.getAllByRole('link', { name: /Admin/i });
      expect(adminLinks.length).toBeGreaterThan(0);
    });
  });
});
