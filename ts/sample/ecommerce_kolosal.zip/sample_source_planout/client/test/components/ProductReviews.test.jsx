import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import ProductReviews from '../../src/components/ProductReviews';

const mockReviewData = {
  stats: {
    total: 2,
    average: 4.5,
    five: 1,
    four: 1,
    three: 0,
    two: 0,
    one: 0,
    zero: 0,
  },
  reviews: [
    {
      id: 1,
      rating: 5,
      title: 'Excellent product',
      body: 'Really happy with this purchase.',
      user_name: 'Alice',
      created_at: new Date().toISOString(),
    },
    {
      id: 2,
      rating: 4,
      title: 'Great value',
      body: 'Works as expected.',
      user_name: 'Bob',
      created_at: new Date().toISOString(),
    },
  ],
  userReview: null,
};

const emptyReviewData = { stats: { total: 0 }, reviews: [], userReview: null };

function renderReviews({ mockData = mockReviewData, user = null } = {}) {
  if (user) {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => user });
      if (url.includes('/api/reviews')) return Promise.resolve({ ok: true, json: async () => mockData });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
  } else {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      if (url.includes('/api/reviews')) return Promise.resolve({ ok: true, json: async () => mockData });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
  }

  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>
          <ProductReviews productId={99} />
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('ProductReviews', () => {
  it('renders the Customer Reviews heading', async () => {
    renderReviews();
    await waitFor(() => expect(screen.getByText('Customer Reviews')).toBeInTheDocument());
  });

  it('shows empty state when there are no reviews', async () => {
    renderReviews({ mockData: emptyReviewData });
    await waitFor(() => expect(screen.getByText(/No reviews yet/i)).toBeInTheDocument());
  });

  it('renders review titles and bodies', async () => {
    renderReviews();
    await waitFor(() => {
      expect(screen.getByText('Excellent product')).toBeInTheDocument();
      expect(screen.getByText('Really happy with this purchase.')).toBeInTheDocument();
    });
  });

  it('renders reviewer names', async () => {
    renderReviews();
    await waitFor(() => {
      expect(screen.getByText('Alice')).toBeInTheDocument();
      expect(screen.getByText('Bob')).toBeInTheDocument();
    });
  });

  it('renders stats summary when reviews exist', async () => {
    renderReviews();
    await waitFor(() => {
      expect(screen.getByText('4.5')).toBeInTheDocument();
      expect(screen.getByText('2 reviews')).toBeInTheDocument();
    });
  });

  it('shows write review form when user is authenticated and has no review', async () => {
    renderReviews({ user: { id: 1, name: 'Alice', role: 'user' } });
    await waitFor(() => expect(screen.getByText('Write a Review')).toBeInTheDocument());
  });

  it('does not show write review form when unauthenticated', async () => {
    renderReviews();
    await waitFor(() => expect(screen.getByText('Customer Reviews')).toBeInTheDocument());
    expect(screen.queryByText('Write a Review')).not.toBeInTheDocument();
  });
});
