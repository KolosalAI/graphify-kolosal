import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import BannerCarousel from '../../src/components/BannerCarousel';

const mockBanners = [
  { id: 1, title: 'Summer Sale', subtitle: 'Up to 50% off', image_url: '/img1.jpg', bg_color: '#ff0000', link: '/sale' },
  { id: 2, title: 'New Arrivals', subtitle: 'Shop the latest', image_url: '/img2.jpg', bg_color: '#0000ff', link: '/new' },
];

function renderCarousel() {
  return render(<MemoryRouter><BannerCarousel /></MemoryRouter>);
}

describe('BannerCarousel', () => {
  it('renders nothing when banners array is empty', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
    const { container } = renderCarousel();
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith('/api/banners'));
    expect(container.firstChild).toBeNull();
  });

  it('renders banner title when data is provided', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockBanners });
    renderCarousel();
    await waitFor(() => expect(screen.getByText('Summer Sale')).toBeInTheDocument());
  });

  it('renders the correct number of dot indicators for multiple banners', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockBanners });
    renderCarousel();
    await waitFor(() => {
      const dots = document.querySelectorAll('.banner-dot');
      expect(dots.length).toBe(mockBanners.length);
    });
  });

  it('renders prev/next arrows only for multiple banners', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockBanners });
    renderCarousel();
    await waitFor(() => {
      expect(document.querySelector('.banner-arrow-left')).toBeInTheDocument();
      expect(document.querySelector('.banner-arrow-right')).toBeInTheDocument();
    });
  });

  it('renders subtitle text', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockBanners });
    renderCarousel();
    await waitFor(() => expect(screen.getByText('Up to 50% off')).toBeInTheDocument());
  });

  it('renders Shop Now button when banner has a link', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockBanners });
    renderCarousel();
    await waitFor(() => expect(screen.getByText(/Shop Now/i)).toBeInTheDocument());
  });
});
