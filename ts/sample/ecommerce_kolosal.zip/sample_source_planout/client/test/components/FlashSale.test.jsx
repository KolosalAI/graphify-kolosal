import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import FlashSale from '../../src/components/FlashSale';

const futureDate = new Date(Date.now() + 7200000).toISOString();

const mockSale = {
  id: 1,
  title: 'Flash Sale!',
  ends_at: futureDate,
  items: [
    {
      id: 10,
      product_id: 101,
      name: 'Gaming Mouse',
      slug: 'gaming-mouse',
      image_url: '/mouse.jpg',
      sale_price: 29.99,
      original_price: 59.99,
      sold: 40,
      quantity_limit: 100,
      category_name: 'Electronics',
      avg_rating: 4.5,
      review_count: 12,
    },
  ],
};

function renderFlashSale() {
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>
          <FlashSale />
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('FlashSale', () => {
  it('renders nothing when there is no active sale', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      if (url.includes('/api/flash-sales/active')) return Promise.resolve({ ok: true, json: async () => null });
      return Promise.resolve({ ok: true, json: async () => [] });
    });
    const { container } = renderFlashSale();
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith('/api/flash-sales/active'));
    expect(container.querySelector('.flash-sale-section')).toBeNull();
  });

  it('renders the flash sale title when a sale is active', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      if (url.includes('/api/flash-sales/active')) return Promise.resolve({ ok: true, json: async () => mockSale });
      return Promise.resolve({ ok: true, json: async () => [] });
    });
    renderFlashSale();
    await waitFor(() => expect(screen.getByText('Flash Sale!')).toBeInTheDocument());
  });

  it('renders flash sale item name and price', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      if (url.includes('/api/flash-sales/active')) return Promise.resolve({ ok: true, json: async () => mockSale });
      return Promise.resolve({ ok: true, json: async () => [] });
    });
    renderFlashSale();
    await waitFor(() => {
      expect(screen.getByText('Gaming Mouse')).toBeInTheDocument();
      expect(screen.getByText('$29.99')).toBeInTheDocument();
    });
  });

  it('shows countdown timer', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      if (url.includes('/api/flash-sales/active')) return Promise.resolve({ ok: true, json: async () => mockSale });
      return Promise.resolve({ ok: true, json: async () => [] });
    });
    renderFlashSale();
    await waitFor(() => expect(screen.getByText('Ends in')).toBeInTheDocument());
  });

  it('renders Add to Cart button for in-stock items', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: async () => ({}) });
      if (url.includes('/api/flash-sales/active')) return Promise.resolve({ ok: true, json: async () => mockSale });
      return Promise.resolve({ ok: true, json: async () => [] });
    });
    renderFlashSale();
    await waitFor(() => expect(screen.getByRole('button', { name: /Add to Cart/i })).toBeInTheDocument());
  });
});
