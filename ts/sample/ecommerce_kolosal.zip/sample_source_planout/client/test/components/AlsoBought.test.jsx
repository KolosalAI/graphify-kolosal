import { describe, it, expect } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AlsoBought from '../../src/components/AlsoBought';

const mockProducts = [
  { id: 1, name: 'USB Hub', slug: 'usb-hub', price: 19.99, image_url: '/hub.jpg', avg_rating: 4.2, review_count: 8 },
  { id: 2, name: 'Keyboard', slug: 'keyboard', price: 79.99, image_url: '/keyboard.jpg', avg_rating: 4.8, review_count: 25 },
];

function renderAlsoBought(props = { productId: 5 }) {
  return render(<MemoryRouter><AlsoBought {...props} /></MemoryRouter>);
}

describe('AlsoBought', () => {
  it('renders nothing when productId is not provided', () => {
    const { container } = renderAlsoBought({ productId: undefined });
    expect(container.firstChild).toBeNull();
  });

  it('renders nothing when the API returns an empty array', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
    const { container } = renderAlsoBought();
    await waitFor(() => expect(global.fetch).toHaveBeenCalled());
    expect(container.firstChild).toBeNull();
  });

  it('renders the default section title', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockProducts });
    renderAlsoBought();
    await waitFor(() => expect(screen.getByText('Customers also bought')).toBeInTheDocument());
  });

  it('renders a custom title when provided', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockProducts });
    renderAlsoBought({ productId: 5, title: 'You may also like' });
    await waitFor(() => expect(screen.getByText('You may also like')).toBeInTheDocument());
  });

  it('renders product names and prices', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockProducts });
    renderAlsoBought();
    await waitFor(() => {
      expect(screen.getByText('USB Hub')).toBeInTheDocument();
      expect(screen.getByText('Keyboard')).toBeInTheDocument();
      expect(screen.getByText('$19.99')).toBeInTheDocument();
      expect(screen.getByText('$79.99')).toBeInTheDocument();
    });
  });

  it('fetches from the correct endpoint using productId', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
    renderAlsoBought({ productId: 42 });
    await waitFor(() =>
      expect(global.fetch).toHaveBeenCalledWith('/api/recommendations/also-bought/42')
    );
  });

  it('renders star ratings for products with ratings', async () => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => mockProducts });
    renderAlsoBought();
    await waitFor(() => expect(screen.getByText(/\(8\)/)).toBeInTheDocument());
  });
});
