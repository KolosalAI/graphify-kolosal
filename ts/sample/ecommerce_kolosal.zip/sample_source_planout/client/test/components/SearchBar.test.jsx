import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import SearchBar from '../../src/components/SearchBar';

let navigatedTo = '';

// Capture navigation using a test route
function renderSearchBar(initialEntry = '/') {
  return render(
    <MemoryRouter initialEntries={[initialEntry]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="*" element={<SearchBar />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('SearchBar component', () => {
  beforeEach(() => {
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
    localStorage.getItem.mockReturnValue(null);
  });

  it('renders the search input', async () => {
    renderSearchBar();
    await waitFor(() => {
      expect(screen.getByPlaceholderText(/Search products/i)).toBeInTheDocument();
    });
  });

  it('updates input value on typing', async () => {
    renderSearchBar();
    const input = await waitFor(() => screen.getByPlaceholderText(/Search products/i));
    fireEvent.change(input, { target: { value: 'laptop' } });
    expect(input.value).toBe('laptop');
  });

  it('fetches suggestions after typing 2+ characters', async () => {
    global.fetch.mockResolvedValue({
      ok: true,
      json: async () => [{ id: 1, name: 'Laptop', slug: 'laptop', price: 999 }],
    });

    renderSearchBar();
    const input = await waitFor(() => screen.getByPlaceholderText(/Search products/i));
    fireEvent.change(input, { target: { value: 'la' } });

    await waitFor(() => {
      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/products/suggestions?q=la')
      );
    }, { timeout: 500 });
  });

  it('shows suggestion dropdown when results exist', async () => {
    global.fetch.mockResolvedValue({
      ok: true,
      json: async () => [{ id: 1, name: 'Laptop Pro', slug: 'laptop-pro', price: 1299, image_url: '/l.jpg' }],
    });

    renderSearchBar();
    const input = await waitFor(() => screen.getByPlaceholderText(/Search products/i));
    fireEvent.change(input, { target: { value: 'lap' } });

    await waitFor(() => {
      expect(screen.getByText('Laptop Pro')).toBeInTheDocument();
    }, { timeout: 500 });
  });
});
