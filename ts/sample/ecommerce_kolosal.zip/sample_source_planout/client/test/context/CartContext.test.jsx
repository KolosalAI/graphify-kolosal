import { describe, it, expect, vi } from 'vitest';
import { render, act, screen } from '@testing-library/react';
import { CartProvider, useCart } from '../../src/context/CartContext';

const product1 = { id: 1, name: 'Widget', price: 10.00, image_url: '/w.jpg', slug: 'widget' };
const product2 = { id: 2, name: 'Gadget', price: 25.00, image_url: '/g.jpg', slug: 'gadget' };

// Helper component to expose cart state
function CartConsumer({ onRender }) {
  const cart = useCart();
  onRender(cart);
  return <div data-testid="cart-count">{cart.cartCount}</div>;
}

function renderCart(onRender) {
  return render(
    <CartProvider>
      <CartConsumer onRender={onRender} />
    </CartProvider>
  );
}

describe('CartContext', () => {
  describe('initial state', () => {
    it('starts with empty cart', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      expect(cartState.cart).toEqual([]);
      expect(cartState.cartCount).toBe(0);
      expect(cartState.totalPrice).toBe(0);
    });
  });

  describe('addItem', () => {
    it('adds a new item to cart', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      expect(cartState.cart).toHaveLength(1);
      expect(cartState.cart[0].id).toBe(1);
      expect(cartState.cart[0].quantity).toBe(1);
    });

    it('increments quantity for existing item', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.addItem(product1));
      expect(cartState.cart).toHaveLength(1);
      expect(cartState.cart[0].quantity).toBe(2);
    });

    it('adds item with specified quantity', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1, 3));
      expect(cartState.cart[0].quantity).toBe(3);
    });

    it('adds multiple different items', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.addItem(product2));
      expect(cartState.cart).toHaveLength(2);
    });
  });

  describe('removeItem', () => {
    it('removes item by id', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.addItem(product2));
      act(() => cartState.removeItem(1));
      expect(cartState.cart).toHaveLength(1);
      expect(cartState.cart[0].id).toBe(2);
    });

    it('does nothing for non-existent item', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.removeItem(999));
      expect(cartState.cart).toHaveLength(1);
    });
  });

  describe('updateQuantity', () => {
    it('updates quantity of an item', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.updateQuantity(1, 5));
      expect(cartState.cart[0].quantity).toBe(5);
    });

    it('removes item when quantity set to 0', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.updateQuantity(1, 0));
      expect(cartState.cart).toHaveLength(0);
    });
  });

  describe('clearCart', () => {
    it('empties the cart', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      act(() => cartState.addItem(product2));
      act(() => cartState.clearCart());
      expect(cartState.cart).toHaveLength(0);
      expect(cartState.cartCount).toBe(0);
    });
  });

  describe('derived values', () => {
    it('calculates totalPrice correctly', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1, 2)); // 2 × $10 = $20
      act(() => cartState.addItem(product2, 1)); // 1 × $25 = $25
      expect(cartState.totalPrice).toBe(45);
    });

    it('calculates cartCount correctly', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1, 3));
      act(() => cartState.addItem(product2, 2));
      expect(cartState.cartCount).toBe(5);
    });
  });

  describe('localStorage persistence', () => {
    it('saves cart to localStorage on change', () => {
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      expect(localStorage.setItem).toHaveBeenCalledWith(
        'shopkolosal_cart',
        expect.stringContaining('"id":1')
      );
    });
  });

  describe('loadCartFromServer', () => {
    it('merges server cart with local items', async () => {
      const serverItems = [{ id: 1, name: 'Widget', price: 10, quantity: 3, image_url: '/w.jpg', slug: 'widget' }];
      global.fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => serverItems,
      });

      let cartState;
      renderCart(cart => { cartState = cart; });
      await act(async () => {
        await cartState.loadCartFromServer('test-token');
      });
      expect(cartState.cart.find(i => i.id === 1)?.quantity).toBe(3);
    });

    it('does nothing on server error', async () => {
      global.fetch.mockResolvedValueOnce({ ok: false });
      let cartState;
      renderCart(cart => { cartState = cart; });
      act(() => cartState.addItem(product1));
      await act(async () => {
        await cartState.loadCartFromServer('bad-token');
      });
      expect(cartState.cart).toHaveLength(1);
    });
  });
});
