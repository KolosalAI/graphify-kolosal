import { describe, it, expect, vi } from 'vitest';
import { render, act, waitFor } from '@testing-library/react';
import { AuthProvider, useAuth } from '../../src/context/AuthContext';

const mockUser = { id: 1, name: 'Test User', email: 'test@test.com', role: 'user' };
const mockAdmin = { id: 2, name: 'Admin', email: 'admin@test.com', role: 'admin' };

function AuthConsumer({ onRender }) {
  const auth = useAuth();
  onRender(auth);
  return <div>{auth.user?.name ?? 'guest'}</div>;
}

function renderAuth(onRender) {
  return render(
    <AuthProvider>
      <AuthConsumer onRender={onRender} />
    </AuthProvider>
  );
}

describe('AuthContext', () => {
  describe('initial state (no token)', () => {
    it('starts with no user when no token in localStorage', async () => {
      localStorage.getItem.mockReturnValue(null);
      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));
      expect(authState.user).toBeNull();
      expect(authState.token).toBeNull();
    });
  });

  describe('login', () => {
    it('sets user and token on successful login', async () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch
        .mockResolvedValueOnce({ ok: true, json: async () => ({ user: mockUser, token: 'tok123' }) }) // login
        .mockResolvedValueOnce({ ok: true, json: async () => mockUser }); // auth/me after token set

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      await act(async () => {
        await authState.login('test@test.com', 'password123');
      });

      await waitFor(() => expect(authState.token).toBe('tok123'));
      expect(authState.user).toEqual(mockUser);
      expect(localStorage.setItem).toHaveBeenCalledWith('token', 'tok123');
    });

    it('throws on invalid credentials', async () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch.mockResolvedValueOnce({
        ok: false,
        json: async () => ({ error: 'Invalid email or password.' }),
      });

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      await expect(act(async () => {
        await authState.login('wrong@test.com', 'badpass');
      })).rejects.toThrow('Invalid email or password.');
    });
  });

  describe('register', () => {
    it('sets user and token on successful registration', async () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch
        .mockResolvedValueOnce({ ok: true, json: async () => ({ user: mockUser, token: 'newtok' }) }) // register
        .mockResolvedValueOnce({ ok: true, json: async () => mockUser }); // auth/me after token set

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      await act(async () => {
        await authState.register('Test User', 'test@test.com', 'password123');
      });

      await waitFor(() => expect(authState.user).toEqual(mockUser));
      expect(localStorage.setItem).toHaveBeenCalledWith('token', 'newtok');
    });
  });

  describe('logout', () => {
    it('clears user and token', async () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch
        .mockResolvedValueOnce({ ok: true, json: async () => ({ user: mockUser, token: 'tok123' }) }) // login
        .mockResolvedValueOnce({ ok: true, json: async () => mockUser }); // auth/me after token set

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      await act(async () => {
        await authState.login('test@test.com', 'password123');
      });
      await waitFor(() => expect(authState.user).toEqual(mockUser));
      act(() => authState.logout());

      expect(authState.user).toBeNull();
      expect(authState.token).toBeNull();
      expect(localStorage.removeItem).toHaveBeenCalledWith('token');
    });
  });

  describe('isAdmin', () => {
    it('returns true for admin user', async () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch
        .mockResolvedValueOnce({ ok: true, json: async () => ({ user: mockAdmin, token: 'admintok' }) }) // login
        .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin }); // auth/me after token set

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      await act(async () => {
        await authState.login('admin@test.com', 'password123');
      });

      expect(authState.isAdmin).toBe(true);
    });

    it('returns false for regular user', async () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch
        .mockResolvedValueOnce({ ok: true, json: async () => ({ user: mockUser, token: 'tok' }) }) // login
        .mockResolvedValueOnce({ ok: true, json: async () => mockUser }); // auth/me after token set

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      await act(async () => {
        await authState.login('test@test.com', 'password123');
      });

      expect(authState.isAdmin).toBe(false);
    });
  });

  describe('session restore', () => {
    it('restores user from existing token on mount', async () => {
      localStorage.getItem.mockImplementation((key) =>
        key === 'token' ? 'existing-token' : null
      );
      global.fetch.mockResolvedValueOnce({
        ok: true,
        json: async () => mockUser,
      });

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      expect(authState.user).toEqual(mockUser);
    });

    it('clears invalid token on restore failure', async () => {
      localStorage.getItem.mockImplementation((key) =>
        key === 'token' ? 'bad-token' : null
      );
      global.fetch.mockResolvedValueOnce({ ok: false });

      let authState;
      renderAuth(auth => { authState = auth; });
      await waitFor(() => expect(authState.loading).toBe(false));

      expect(authState.user).toBeNull();
      expect(localStorage.removeItem).toHaveBeenCalledWith('token');
    });
  });
});
