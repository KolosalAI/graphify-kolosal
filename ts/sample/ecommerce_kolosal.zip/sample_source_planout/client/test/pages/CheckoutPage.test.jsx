import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import CheckoutPage from '../../src/pages/CheckoutPage';

const cartItem = { id: 1, name: 'Widget A', price: 19.99, quantity: 2, stock: 10 };

function renderCheckout({ withCart = true, withAuth = false } = {}) {
  if (withCart) {
    localStorage.getItem.mockImplementation(key => {
      if (key === 'shopkolosal_cart') return JSON.stringify([cartItem]);
      if (withAuth && key === 'token') return 'fake-token';
      return null;
    });
  } else {
    localStorage.getItem.mockImplementation(() => null);
  }

  return render(
    <MemoryRouter initialEntries={['/checkout']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/checkout" element={<CheckoutPage />} />
            <Route path="/cart" element={<div>Cart Page</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('CheckoutPage', () => {
  beforeEach(() => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Test', email: 'test@test.com', role: 'user' }) });
      if (url.includes('/api/shipping-options')) return Promise.resolve({ ok: true, json: async () => [] });
      if (url.includes('/api/loyalty/balance')) return Promise.resolve({ ok: true, json: async () => ({ balance: 0 }) });
      if (url.includes('/api/addresses')) return Promise.resolve({ ok: true, json: async () => [] });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
  });

  it('redirects to cart when cart is empty', async () => {
    renderCheckout({ withCart: false });
    await waitFor(() => expect(screen.getByText('Cart Page')).toBeInTheDocument());
  });

  it('shows checkout heading when cart has items', async () => {
    renderCheckout({ withCart: true });
    await waitFor(() => expect(screen.getByText('Checkout')).toBeInTheDocument());
  });

  it('shows order summary with cart items', async () => {
    renderCheckout({ withCart: true });
    await waitFor(() => expect(screen.getByText('Order Summary')).toBeInTheDocument());
    await waitFor(() => expect(screen.getByText(/Widget A/)).toBeInTheDocument());
  });

  it('shows checkout form with address fields', async () => {
    renderCheckout({ withCart: true });
    await waitFor(() => expect(screen.getByLabelText('Full Name')).toBeInTheDocument());
    expect(screen.getByLabelText('Email')).toBeInTheDocument();
    expect(screen.getByLabelText('Shipping Address')).toBeInTheDocument();
  });

  it('shows place order button', async () => {
    renderCheckout({ withCart: true });
    await waitFor(() => expect(screen.getByRole('button', { name: /Place Order/i })).toBeInTheDocument());
  });
});
