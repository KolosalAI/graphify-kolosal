import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import CartPage from '../../src/pages/CartPage';

const mockCartItems = [
  { id: 1, name: 'Widget A', price: 15.00, quantity: 2, image_url: '/wa.jpg', slug: 'widget-a', stock: 10 },
  { id: 2, name: 'Gadget B', price: 40.00, quantity: 1, image_url: '/gb.jpg', slug: 'gadget-b', stock: 5 },
];

function renderCart(initialCart = []) {
  // Pre-populate cart via localStorage mock
  localStorage.getItem.mockImplementation(key => {
    if (key === 'shopkolosal_cart') return JSON.stringify(initialCart);
    return null;
  });

  return render(
    <MemoryRouter initialEntries={['/cart']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<div>Checkout</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('CartPage', () => {
  beforeEach(() => {
    global.fetch.mockResolvedValue({ ok: false, json: async () => ({}) });
  });

  it('shows empty cart message when cart is empty', async () => {
    renderCart([]);
    await waitFor(() => {
      expect(screen.getByText(/Your cart is empty/i)).toBeInTheDocument();
    });
  });

  it('renders cart items', async () => {
    renderCart(mockCartItems);
    await waitFor(() => {
      expect(screen.getByText('Widget A')).toBeInTheDocument();
      expect(screen.getByText('Gadget B')).toBeInTheDocument();
    });
  });

  it('shows item prices', async () => {
    renderCart(mockCartItems);
    await waitFor(() => {
      expect(screen.getAllByText('$15.00').length).toBeGreaterThan(0);
      expect(screen.getAllByText('$40.00').length).toBeGreaterThan(0);
    });
  });

  it('shows order total', async () => {
    renderCart(mockCartItems);
    // 2 × $15 + 1 × $40 = $70
    await waitFor(() => {
      expect(screen.getByText(/\$70\.00/)).toBeInTheDocument();
    });
  });

  it('shows Checkout button when cart has items', async () => {
    renderCart(mockCartItems);
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Proceed to Checkout/i }) ||
             screen.getByRole('link', { name: /Checkout/i })).toBeInTheDocument();
    });
  });

  it('renders a link back to shop when empty', async () => {
    renderCart([]);
    await waitFor(() => {
      expect(screen.getByRole('link', { name: /Browse Products/i }) ||
             screen.getByRole('link', { name: /Continue Shopping/i }) ||
             screen.getByRole('link', { name: /Shop/i })).toBeInTheDocument();
    });
  });
});
