import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import SearchPage from '../../src/pages/SearchPage';

function renderSearch(queryString = '') {
  return render(
    <MemoryRouter initialEntries={[`/search${queryString}`]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/search" element={<SearchPage />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

const mockProducts = {
  products: [
    { id: 1, name: 'Found Widget', slug: 'found-widget', price: 29.99, image_url: '/w.jpg', category_name: 'Electronics', stock: 5, avg_rating: 4, review_count: 3, badge: null },
  ],
  pagination: { page: 1, limit: 20, total: 1, totalPages: 1 },
  priceRange: { min: 29.99, max: 29.99 },
  brands: [],
};

const emptyResult = {
  products: [],
  pagination: { page: 1, limit: 20, total: 0, totalPages: 0 },
  priceRange: { min: 0, max: 0 },
  brands: [],
};

describe('SearchPage', () => {
  beforeEach(() => {
    localStorage.getItem.mockReturnValue(null);
    global.fetch
      .mockResolvedValueOnce({ ok: true, json: async () => [] })          // categories
      .mockResolvedValueOnce({ ok: true, json: async () => mockProducts }); // products
  });

  it('renders search heading', async () => {
    renderSearch('?q=widget');
    await waitFor(() => {
      expect(screen.getByText(/Results for/i)).toBeInTheDocument();
    });
  });

  it('shows loading state initially', () => {
    renderSearch('?q=widget');
    expect(screen.getByText(/Loading/i)).toBeInTheDocument();
  });

  it('displays products after loading', async () => {
    renderSearch('?q=widget');
    await waitFor(() => {
      expect(screen.getByText('Found Widget')).toBeInTheDocument();
    });
  });

  it('shows no results message for empty results', async () => {
    global.fetch.mockReset();
    global.fetch
      .mockResolvedValueOnce({ ok: true, json: async () => [] })
      .mockResolvedValueOnce({ ok: true, json: async () => emptyResult });

    renderSearch('?q=zzznoresults');
    await waitFor(() => {
      expect(screen.getByText(/No products found/i)).toBeInTheDocument();
    });
  });

  it('shows result count', async () => {
    renderSearch('?q=widget');
    await waitFor(() => {
      expect(screen.getByText(/1 result/i)).toBeInTheDocument();
    });
  });
});
