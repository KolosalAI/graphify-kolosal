import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminGiftCards from '../../../src/pages/admin/AdminGiftCards';

const mockGiftCards = [
  { id: 1, code: 'GC-ABC123', initial_value: 50, balance: 50, used: false, created_at: new Date().toISOString() },
];

function renderAdmin(ui, { giftCards = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/gift-cards'))
      return Promise.resolve({ ok: true, json: async () => giftCards });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminGiftCards', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Gift Cards heading', async () => {
    renderAdmin(<AdminGiftCards />, { giftCards: mockGiftCards });
    await waitFor(() => {
      expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(/gift cards/i);
    });
  });

  it('shows generate gift card form/input', async () => {
    renderAdmin(<AdminGiftCards />, { giftCards: mockGiftCards });
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /generate/i })).toBeInTheDocument();
    });
  });

  it('shows gift card list when loaded', async () => {
    renderAdmin(<AdminGiftCards />, { giftCards: mockGiftCards });
    await waitFor(() => {
      expect(screen.getByText('GC-ABC123')).toBeInTheDocument();
    });
  });

  it('shows gift card code in list', async () => {
    renderAdmin(<AdminGiftCards />, { giftCards: mockGiftCards });
    await waitFor(() => {
      expect(screen.getByText('GC-ABC123')).toBeInTheDocument();
    });
  });
});
