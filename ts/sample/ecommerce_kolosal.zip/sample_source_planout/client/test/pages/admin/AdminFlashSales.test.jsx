import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminFlashSales from '../../../src/pages/admin/AdminFlashSales';

const mockFlashSales = [
  { id: 1, title: 'Summer Flash', starts_at: new Date().toISOString(), ends_at: new Date(Date.now() + 3600000).toISOString(), active: true, item_count: 3 },
];

function renderAdmin(ui, { sales = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/flash-sales'))
      return Promise.resolve({ ok: true, json: async () => sales });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminFlashSales', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Flash Sales heading', async () => {
    renderAdmin(<AdminFlashSales />, { sales: mockFlashSales });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /flash sales/i })).toBeInTheDocument();
    });
  });

  it('shows New Flash Sale button', async () => {
    renderAdmin(<AdminFlashSales />, { sales: mockFlashSales });
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /new flash sale/i })).toBeInTheDocument();
    });
  });

  it('shows flash sales list when loaded', async () => {
    renderAdmin(<AdminFlashSales />, { sales: mockFlashSales });
    await waitFor(() => {
      expect(screen.getByText(/Summer Flash/)).toBeInTheDocument();
    });
  });

  it('shows empty state when no sales', async () => {
    renderAdmin(<AdminFlashSales />, { sales: [] });
    await waitFor(() => {
      expect(screen.getByText(/no flash sales yet/i)).toBeInTheDocument();
    });
  });
});
