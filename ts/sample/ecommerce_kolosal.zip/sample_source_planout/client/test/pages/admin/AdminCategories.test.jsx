import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminCategories from '../../../src/pages/admin/AdminCategories';

const mockAdmin = { id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' };

const mockCategories = [
  {
    id: 1,
    name: 'Electronics',
    slug: 'electronics',
    description: 'Electronic items',
    product_count: 5,
  },
];

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAdminAuth() {
  localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));
  // Child useEffect (categories fetch) fires before AuthProvider's useEffect (auth/me)
  global.fetch
    .mockResolvedValueOnce({ ok: true, json: async () => mockCategories })
    .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });
}

describe('AdminCategories', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Add Category form with admin auth', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminCategories />);

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /add category/i })).toBeInTheDocument();
    });

    expect(screen.getByRole('button', { name: /create category/i })).toBeInTheDocument();
    expect(screen.getAllByText('Name').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('Slug').length).toBeGreaterThanOrEqual(1);
    expect(screen.getByText('Description')).toBeInTheDocument();
  });

  it('shows categories list when categories are loaded', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminCategories />);

    await waitFor(() => {
      expect(screen.getByText('Electronics')).toBeInTheDocument();
    });

    expect(screen.getByText(/all categories/i)).toBeInTheDocument();
  });

  it('shows category name in the table', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminCategories />);

    await waitFor(() => {
      expect(screen.getByText('Electronics')).toBeInTheDocument();
    });

    expect(screen.getByText('electronics')).toBeInTheDocument();
  });

  it('shows Edit and Delete buttons for each category', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminCategories />);

    await waitFor(() => {
      expect(screen.getByText('Electronics')).toBeInTheDocument();
    });

    expect(screen.getByRole('button', { name: /edit/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /delete/i })).toBeInTheDocument();
  });
});
