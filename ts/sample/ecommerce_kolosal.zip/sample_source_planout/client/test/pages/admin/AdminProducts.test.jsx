import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminProducts from '../../../src/pages/admin/AdminProducts';

const mockAdmin = { id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' };

const mockProductsData = {
  products: [
    {
      id: 1,
      name: 'Widget',
      slug: 'widget',
      price: 19.99,
      stock: 10,
      category_name: 'Electronics',
      image_url: '',
    },
  ],
};

const mockCategories = [{ id: 1, name: 'Electronics', slug: 'electronics' }];

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAdminAuth() {
  localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));
  // Child useEffect fires first: products (authFetch), then categories (plain fetch);
  // AuthProvider's useEffect (auth/me) fires last as the parent
  global.fetch
    .mockResolvedValueOnce({ ok: true, json: async () => mockProductsData })
    .mockResolvedValueOnce({ ok: true, json: async () => mockCategories })
    .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });
}

describe('AdminProducts', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Add Product heading and form with admin auth', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminProducts />);

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /add product/i })).toBeInTheDocument();
    });

    expect(screen.getByRole('button', { name: /create product/i })).toBeInTheDocument();
  });

  it('shows product list when products are loaded', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminProducts />);

    await waitFor(() => {
      expect(screen.getByText('Widget')).toBeInTheDocument();
    });

    expect(screen.getByText(/all products/i)).toBeInTheDocument();
  });

  it('shows product form fields for Name, Price, and Stock', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminProducts />);

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /add product/i })).toBeInTheDocument();
    });

    expect(screen.getByText('Name')).toBeInTheDocument();
    expect(screen.getAllByText('Price').length).toBeGreaterThanOrEqual(1);
    expect(screen.getAllByText('Stock').length).toBeGreaterThanOrEqual(1);
  });

  it('shows Edit and Delete buttons for each product', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminProducts />);

    await waitFor(() => {
      expect(screen.getByText('Widget')).toBeInTheDocument();
    });

    expect(screen.getByRole('button', { name: /edit/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /delete/i })).toBeInTheDocument();
  });
});
