import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminDeals from '../../../src/pages/admin/AdminDeals';

const mockDeals = [
  { id: 1, product_name: 'Widget', product_id: 1, sale_price: 9.99, active: true, starts_at: new Date().toISOString(), ends_at: new Date().toISOString() },
];

const mockProducts = [{ id: 1, name: 'Widget', price: 19.99 }];

function renderAdmin(ui, { deals = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/deals/admin'))
      return Promise.resolve({ ok: true, json: async () => deals });
    if (url.includes('/api/products'))
      return Promise.resolve({ ok: true, json: async () => ({ products: mockProducts }) });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminDeals', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Deals of the Day heading', async () => {
    renderAdmin(<AdminDeals />, { deals: mockDeals });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /deals of the day/i })).toBeInTheDocument();
    });
  });

  it('shows Add Deal button', async () => {
    renderAdmin(<AdminDeals />, { deals: mockDeals });
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /new deal/i })).toBeInTheDocument();
    });
  });

  it('shows deals list when loaded', async () => {
    renderAdmin(<AdminDeals />, { deals: mockDeals });
    await waitFor(() => {
      expect(screen.getByText('Widget')).toBeInTheDocument();
    });
  });

  it('shows empty state when no deals', async () => {
    renderAdmin(<AdminDeals />, { deals: [] });
    await waitFor(() => {
      expect(screen.queryByText('Widget')).not.toBeInTheDocument();
    });
  });
});
