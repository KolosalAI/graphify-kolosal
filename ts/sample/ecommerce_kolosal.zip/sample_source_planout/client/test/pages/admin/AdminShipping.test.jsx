import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminShipping from '../../../src/pages/admin/AdminShipping';

const mockShipping = [
  { id: 1, name: 'Standard Shipping', description: '5-7 days', price: 5.99, prime_price: 0, days_min: 5, days_max: 7 },
];

function renderAdmin(ui, { shipping = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/shipping-options'))
      return Promise.resolve({ ok: true, json: async () => shipping });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminShipping', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Shipping Options heading', async () => {
    renderAdmin(<AdminShipping />, { shipping: mockShipping });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /shipping options/i })).toBeInTheDocument();
    });
  });

  it('shows shipping options list when loaded', async () => {
    renderAdmin(<AdminShipping />, { shipping: mockShipping });
    await waitFor(() => {
      expect(screen.getByText('Standard Shipping')).toBeInTheDocument();
    });
  });

  it('shows option name in list', async () => {
    renderAdmin(<AdminShipping />, { shipping: mockShipping });
    await waitFor(() => {
      expect(screen.getByText('Standard Shipping')).toBeInTheDocument();
    });
  });

  it('shows Add Option button', async () => {
    renderAdmin(<AdminShipping />, { shipping: mockShipping });
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /add option/i })).toBeInTheDocument();
    });
  });
});
