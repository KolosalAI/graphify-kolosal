import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminCoupons from '../../../src/pages/admin/AdminCoupons';

const mockCoupons = [
  { id: 1, code: 'SAVE10', type: 'percentage', value: 10, min_order: 0, max_uses: 100, uses_count: 5, active: true, expires_at: null },
];

function renderAdmin(ui) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/coupons'))
      return Promise.resolve({ ok: true, json: async () => mockCoupons });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminCoupons', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Coupon Codes heading', async () => {
    renderAdmin(<AdminCoupons />);
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /coupon codes/i })).toBeInTheDocument();
    });
  });

  it('shows Create New Coupon form', async () => {
    renderAdmin(<AdminCoupons />);
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /create new coupon/i })).toBeInTheDocument();
    });
  });

  it('shows coupon list when loaded', async () => {
    renderAdmin(<AdminCoupons />);
    await waitFor(() => {
      expect(screen.getByText('SAVE10')).toBeInTheDocument();
    });
  });

  it('shows coupon code in table', async () => {
    renderAdmin(<AdminCoupons />);
    await waitFor(() => {
      expect(screen.getByText('SAVE10')).toBeInTheDocument();
    });
  });
});
