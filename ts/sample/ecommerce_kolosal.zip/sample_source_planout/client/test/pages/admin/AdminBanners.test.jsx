import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminBanners from '../../../src/pages/admin/AdminBanners';

const mockBanners = [
  { id: 1, title: 'Summer Sale', image_url: '/img.jpg', link_url: '/sale', active: true, sort_order: 1 },
];

function renderAdmin(ui, { banners = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/banners/admin'))
      return Promise.resolve({ ok: true, json: async () => banners });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminBanners', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Manage Banners heading', async () => {
    renderAdmin(<AdminBanners />, { banners: mockBanners });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /manage banners/i })).toBeInTheDocument();
    });
  });

  it('shows empty state when no banners', async () => {
    renderAdmin(<AdminBanners />, { banners: [] });
    await waitFor(() => {
      expect(screen.getByText(/no banners yet/i)).toBeInTheDocument();
    });
  });

  it('shows banner list when banners loaded', async () => {
    renderAdmin(<AdminBanners />, { banners: mockBanners });
    await waitFor(() => {
      expect(screen.getByText('Summer Sale')).toBeInTheDocument();
    });
  });

  it('shows Add Banner button', async () => {
    renderAdmin(<AdminBanners />, { banners: mockBanners });
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /add banner/i })).toBeInTheDocument();
    });
  });
});
