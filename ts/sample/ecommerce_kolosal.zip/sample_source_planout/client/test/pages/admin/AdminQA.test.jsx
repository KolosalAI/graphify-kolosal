import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminQA from '../../../src/pages/admin/AdminQA';

const mockStats = { total: 10, answered: 7, unanswered: 3, reported: 1, total_helpful: 25 };

const mockQuestions = [
  {
    id: 1, product_id: 1, user_id: 2,
    question: 'Is this waterproof?',
    answer: 'Yes, fully waterproof.',
    asker_name: 'Alice', answerer_name: 'Admin',
    product_name: 'Cool Widget', product_slug: 'cool-widget',
    helpful_count: 5, report_count: 0,
    created_at: new Date().toISOString(),
  },
  {
    id: 2, product_id: 1, user_id: 3,
    question: 'What colors are available?',
    answer: null,
    asker_name: 'Bob', answerer_name: null,
    product_name: 'Cool Widget', product_slug: 'cool-widget',
    helpful_count: 0, report_count: 1,
    created_at: new Date().toISOString(),
  },
];

const mockAdmin = { id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' };

function renderAdminQA() {
  return render(
    <MemoryRouter initialEntries={['/admin/qa']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/admin/qa" element={<AdminQA />} />
            <Route path="/product/:slug" element={<div>Product Page</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

beforeEach(() => {
  localStorage.setItem('token', 'mock-token');
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me')) {
      return Promise.resolve({ ok: true, json: () => Promise.resolve(mockAdmin) });
    }
    if (url.includes('/api/qa/stats')) {
      return Promise.resolve({ ok: true, json: () => Promise.resolve(mockStats) });
    }
    if (url.includes('/api/qa')) {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ questions: mockQuestions, total: 2, page: 1, limit: 20 }),
      });
    }
    return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
  });
});

describe('AdminQA', () => {
  it('renders the page heading', async () => {
    renderAdminQA();
    await waitFor(() => expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(/Q.*A Management/i));
  });

  it('displays stats cards after load', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByText('Total Questions')).toBeInTheDocument();
      expect(screen.getByText('Unanswered')).toBeInTheDocument();
      expect(screen.getByText('Reported')).toBeInTheDocument();
    });
  });

  it('shows answered and unanswered questions', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByText(/Is this waterproof/)).toBeInTheDocument();
      expect(screen.getByText(/What colors are available/)).toBeInTheDocument();
    });
  });

  it('shows answered badge for answered questions', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getAllByText(/Answered/i).length).toBeGreaterThanOrEqual(1);
    });
  });

  it('shows unanswered state and answer input for unanswered questions', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getAllByText(/Unanswered/i).length).toBeGreaterThanOrEqual(1);
      expect(screen.getByPlaceholderText(/Type an answer/i)).toBeInTheDocument();
    });
  });

  it('shows report count for reported questions', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByText(/1 report/i)).toBeInTheDocument();
    });
  });

  it('renders status filter tabs', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByRole('button', { name: 'All' })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /⏳ Unanswered/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /🚩 Reported/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /✅ Answered/i })).toBeInTheDocument();
    });
  });

  it('switches tab and reloads when clicking Unanswered', async () => {
    renderAdminQA();
    await waitFor(() => screen.getByText('All'));
    const unansweredTab = screen.getAllByText(/Unanswered/i).find(el => el.tagName === 'BUTTON');
    fireEvent.click(unansweredTab);
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith(
      expect.stringContaining('status=unanswered'),
      expect.anything()
    ));
  });

  it('has a search input and search button', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByPlaceholderText(/Search questions/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /search/i })).toBeInTheDocument();
    });
  });

  it('submits search and calls API with search param', async () => {
    renderAdminQA();
    await waitFor(() => screen.getByPlaceholderText(/Search questions/i));
    fireEvent.change(screen.getByPlaceholderText(/Search questions/i), { target: { value: 'waterproof' } });
    fireEvent.submit(screen.getByPlaceholderText(/Search questions/i).closest('form'));
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith(
      expect.stringContaining('search=waterproof'),
      expect.anything()
    ));
  });

  it('posts answer when "Post Answer" is clicked', async () => {
    global.fetch.mockImplementation((url, opts) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: () => Promise.resolve(mockAdmin) });
      if (url.includes('/api/qa/stats')) return Promise.resolve({ ok: true, json: () => Promise.resolve(mockStats) });
      if (url.includes('answer-direct')) {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ ...mockQuestions[1], answer: 'Red and blue.', answerer_name: 'Admin' }),
        });
      }
      if (url.includes('/api/qa')) {
        return Promise.resolve({ ok: true, json: () => Promise.resolve({ questions: mockQuestions, total: 2, page: 1, limit: 20 }) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderAdminQA();
    await waitFor(() => screen.getByPlaceholderText(/Type an answer/i));
    fireEvent.change(screen.getByPlaceholderText(/Type an answer/i), { target: { value: 'Red and blue.' } });
    fireEvent.click(screen.getByRole('button', { name: /Post Answer/i }));
    await waitFor(() => expect(global.fetch).toHaveBeenCalledWith(
      expect.stringContaining('answer-direct'),
      expect.anything()
    ));
  });

  it('shows delete buttons for each question', async () => {
    renderAdminQA();
    await waitFor(() => {
      const deleteBtns = screen.getAllByRole('button', { name: /Delete/i });
      expect(deleteBtns.length).toBeGreaterThanOrEqual(1);
    });
  });

  it('shows Dismiss Report button for reported questions', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /Dismiss Report/i })).toBeInTheDocument();
    });
  });

  it('shows total result count', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getByText(/2 question/i)).toBeInTheDocument();
    });
  });

  it('renders product links for questions', async () => {
    renderAdminQA();
    await waitFor(() => {
      expect(screen.getAllByText(/Cool Widget/).length).toBeGreaterThanOrEqual(1);
    });
  });
});
