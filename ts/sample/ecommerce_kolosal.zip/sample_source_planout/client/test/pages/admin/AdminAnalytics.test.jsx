import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminAnalytics from '../../../src/pages/admin/AdminAnalytics';

const mockAnalytics = {
  dailyRevenue: [{ date: '2024-01-15', revenue: 299.99, orders: 10 }],
  monthlyRevenue: [{ month: '2024-01', revenue: 1299.99, orders: 45 }],
  topProducts: [{ slug: 'widget', name: 'Widget', image_url: '', total_sold: 20, total_revenue: 399.8 }],
};

function renderAdmin(ui, { analytics = mockAnalytics, loading = false } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/admin/analytics'))
      return loading
        ? new Promise(() => {})
        : Promise.resolve({ ok: true, json: async () => analytics });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminAnalytics', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Analytics & Reports heading', async () => {
    renderAdmin(<AdminAnalytics />);
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /analytics & reports/i })).toBeInTheDocument();
    });
  });

  it('shows loading state initially', async () => {
    renderAdmin(<AdminAnalytics />, { loading: true });
    await waitFor(() => {
      expect(screen.getByText(/loading/i)).toBeInTheDocument();
    });
  });

  it('shows monthly revenue section', async () => {
    renderAdmin(<AdminAnalytics />);
    await waitFor(() => {
      expect(screen.getByText(/monthly revenue/i)).toBeInTheDocument();
    });
  });

  it('shows top products section', async () => {
    renderAdmin(<AdminAnalytics />);
    await waitFor(() => {
      expect(screen.getByText(/top 5 best-selling products/i)).toBeInTheDocument();
    });
  });
});
