import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminOrders from '../../../src/pages/admin/AdminOrders';

const mockAdmin = { id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' };

const mockOrdersData = {
  orders: [
    {
      id: 1,
      customer_name: 'Bob',
      customer_email: 'bob@test.com',
      total: 49.99,
      status: 'pending',
      created_at: new Date().toISOString(),
      shipping_address: '123 Main St',
    },
  ],
};

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAdminAuth(ordersResponse = mockOrdersData) {
  localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));
  // Child useEffect (orders fetch) fires before AuthProvider's useEffect (auth/me)
  global.fetch
    .mockResolvedValueOnce({ ok: true, json: async () => ordersResponse })
    .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });
}

describe('AdminOrders', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Manage Orders heading with admin auth', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminOrders />);

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /manage orders/i })).toBeInTheDocument();
    });
  });

  it('shows loading state while orders are being fetched', async () => {
    localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));

    let resolveOrders;
    const ordersPromise = new Promise(resolve => { resolveOrders = resolve; });

    // Child effect (orders) fires first and is delayed; parent effect (auth/me) fires second
    global.fetch
      .mockReturnValueOnce({ ok: true, json: () => ordersPromise })
      .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });

    renderWithProviders(<AdminOrders />);

    await waitFor(() => {
      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    resolveOrders(mockOrdersData);
  });

  it('shows orders list when orders are loaded', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminOrders />);

    await waitFor(() => {
      expect(screen.getByText('Bob')).toBeInTheDocument();
    });

    expect(screen.getByText('#1')).toBeInTheDocument();
    expect(screen.getByText('$49.99')).toBeInTheDocument();
  });

  it('shows empty state when no orders exist', async () => {
    setupAdminAuth({ orders: [] });
    renderWithProviders(<AdminOrders />);

    await waitFor(() => {
      expect(screen.getByText(/no orders found/i)).toBeInTheDocument();
    });
  });
});
