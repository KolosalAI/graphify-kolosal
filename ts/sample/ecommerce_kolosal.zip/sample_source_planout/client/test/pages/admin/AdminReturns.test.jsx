import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminReturns from '../../../src/pages/admin/AdminReturns';

const mockReturns = [
  { id: 1, order_id: 5, reason: 'Damaged item', status: 'pending', created_at: new Date().toISOString(), customer_name: 'Alice' },
];

function renderAdmin(ui, { returns = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/returns/all'))
      return Promise.resolve({ ok: true, json: async () => returns });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminReturns', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Return Requests heading', async () => {
    renderAdmin(<AdminReturns />, { returns: mockReturns });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /return requests/i })).toBeInTheDocument();
    });
  });

  it('shows return list when loaded', async () => {
    renderAdmin(<AdminReturns />, { returns: mockReturns });
    await waitFor(() => {
      expect(screen.getByText(/Return #1/)).toBeInTheDocument();
    });
  });

  it('shows empty state when no returns', async () => {
    renderAdmin(<AdminReturns />, { returns: [] });
    await waitFor(() => {
      expect(screen.getByText(/no return requests/i)).toBeInTheDocument();
    });
  });

  it('shows return reason', async () => {
    renderAdmin(<AdminReturns />, { returns: mockReturns });
    await waitFor(() => {
      expect(screen.getByText(/damaged item/i)).toBeInTheDocument();
    });
  });
});
