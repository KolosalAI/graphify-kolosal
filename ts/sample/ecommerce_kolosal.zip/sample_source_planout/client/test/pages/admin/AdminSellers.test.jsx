import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminSellers from '../../../src/pages/admin/AdminSellers';

const mockSellers = [
  { id: 1, store_name: 'Cool Shop', status: 'pending', created_at: new Date().toISOString(), user_name: 'Alice' },
];

function renderAdmin(ui, { sellers = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/sellers/admin/all'))
      return Promise.resolve({ ok: true, json: async () => sellers });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminSellers', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Seller Management heading', async () => {
    renderAdmin(<AdminSellers />, { sellers: mockSellers });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /seller management/i })).toBeInTheDocument();
    });
  });

  it('shows seller list when loaded', async () => {
    renderAdmin(<AdminSellers />, { sellers: mockSellers });
    await waitFor(() => {
      expect(screen.getByText(/Cool Shop/)).toBeInTheDocument();
    });
  });

  it('shows store name in list', async () => {
    renderAdmin(<AdminSellers />, { sellers: mockSellers });
    await waitFor(() => {
      expect(screen.getByText(/Cool Shop/)).toBeInTheDocument();
    });
  });

  it('shows pending tab with sellers', async () => {
    renderAdmin(<AdminSellers />, { sellers: mockSellers });
    await waitFor(() => {
      expect(screen.getByRole('button', { name: /pending/i })).toBeInTheDocument();
    });
  });
});
