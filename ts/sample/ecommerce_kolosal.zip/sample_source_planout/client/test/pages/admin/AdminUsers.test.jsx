import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminUsers from '../../../src/pages/admin/AdminUsers';

const mockAdmin = { id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' };

const mockUsersData = {
  users: [
    {
      id: 1,
      name: 'Alice Smith',
      email: 'alice@test.com',
      role: 'user',
      subscription_plan: null,
      loyalty_points_balance: 100,
      created_at: new Date().toISOString(),
    },
  ],
  pagination: { total: 1, totalPages: 1, page: 1 },
};

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAdminAuth() {
  localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));
  // Child useEffect (users fetch) fires before AuthProvider's useEffect (auth/me)
  global.fetch
    .mockResolvedValueOnce({ ok: true, json: async () => mockUsersData })
    .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });
}

describe('AdminUsers', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows User Management heading with admin auth', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminUsers />);

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /user management/i })).toBeInTheDocument();
    });
  });

  it('shows user list when users are loaded', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminUsers />);

    await waitFor(() => {
      expect(screen.getByText('Alice Smith')).toBeInTheDocument();
    });
  });

  it('shows user name and email in the table', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminUsers />);

    await waitFor(() => {
      expect(screen.getByText('Alice Smith')).toBeInTheDocument();
    });

    expect(screen.getByText('alice@test.com')).toBeInTheDocument();
  });

  it('shows Delete button for each user', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminUsers />);

    await waitFor(() => {
      expect(screen.getByText('Alice Smith')).toBeInTheDocument();
    });

    expect(screen.getByRole('button', { name: /delete/i })).toBeInTheDocument();
  });
});
