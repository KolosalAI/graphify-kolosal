import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminSupport from '../../../src/pages/admin/AdminSupport';

const mockTickets = [
  { id: 1, subject: 'My order is late', status: 'open', created_at: new Date().toISOString(), user_name: 'Bob', messages: [] },
];

function renderAdmin(ui, { tickets = [] } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'admin-token' : null);
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me'))
      return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' }) });
    if (url.includes('/api/support/admin/all'))
      return Promise.resolve({ ok: true, json: async () => tickets });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });
  return render(
    <MemoryRouter>
      <AuthProvider>
        <CartProvider>{ui}</CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AdminSupport', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows Support Tickets heading', async () => {
    renderAdmin(<AdminSupport />, { tickets: mockTickets });
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /support tickets/i })).toBeInTheDocument();
    });
  });

  it('shows ticket list when loaded', async () => {
    renderAdmin(<AdminSupport />, { tickets: mockTickets });
    await waitFor(() => {
      expect(screen.getByText(/my order is late/i)).toBeInTheDocument();
    });
  });

  it('shows ticket subject', async () => {
    renderAdmin(<AdminSupport />, { tickets: mockTickets });
    await waitFor(() => {
      expect(screen.getByText(/my order is late/i)).toBeInTheDocument();
    });
  });

  it('shows empty state when no tickets', async () => {
    renderAdmin(<AdminSupport />, { tickets: [] });
    await waitFor(() => {
      expect(screen.queryByText(/my order is late/i)).not.toBeInTheDocument();
    });
  });
});
