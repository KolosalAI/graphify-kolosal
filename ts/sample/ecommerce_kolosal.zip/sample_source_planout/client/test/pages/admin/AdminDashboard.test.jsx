import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../../src/context/AuthContext';
import { CartProvider } from '../../../src/context/CartContext';
import AdminDashboard from '../../../src/pages/admin/AdminDashboard';

const mockStats = {
  totalRevenue: 1234.56,
  totalOrders: 50,
  totalProducts: 100,
  totalUsers: 200,
  lowStockProducts: [],
  ordersByStatus: [{ status: 'pending', count: 5 }],
  recentOrders: [
    {
      id: 1,
      customer_name: 'Alice',
      total: 29.99,
      status: 'pending',
      created_at: new Date().toISOString(),
    },
  ],
};

const mockAdmin = { id: 1, name: 'Admin', email: 'admin@test.com', role: 'admin' };

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAdminAuth() {
  localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));
  // Child useEffects fire before parent useEffects in React:
  // AdminDashboard's effect (authFetch /api/admin/stats) fires before AuthProvider's effect (/api/auth/me)
  global.fetch
    .mockResolvedValueOnce({ ok: true, json: async () => mockStats })
    .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });
}

describe('AdminDashboard', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('shows loading state when stats not yet loaded', async () => {
    localStorage.getItem.mockImplementation(key => (key === 'token' ? 'admin-token' : null));

    // Child effect (stats) fires first and is delayed; parent effect (auth/me) fires second
    let resolveStats;
    const statsPromise = new Promise(resolve => { resolveStats = resolve; });

    global.fetch
      .mockReturnValueOnce({ ok: true, json: () => statsPromise })
      .mockResolvedValueOnce({ ok: true, json: async () => mockAdmin });

    renderWithProviders(<AdminDashboard />);

    // After auth resolves, stats is still pending → loading div shown
    await waitFor(() => {
      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    // cleanup: resolve stats so no dangling promises
    resolveStats(mockStats);
  });

  it('shows Admin Dashboard heading after data loads', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminDashboard />);

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /admin dashboard/i })).toBeInTheDocument();
    });
  });

  it('shows stat cards for Total Revenue, Total Orders, Products, and Users', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminDashboard />);

    await waitFor(() => {
      expect(screen.getByText('Total Revenue')).toBeInTheDocument();
    });

    expect(screen.getByText('Total Orders')).toBeInTheDocument();
    expect(screen.getByText('Products')).toBeInTheDocument();
    expect(screen.getByText('Users')).toBeInTheDocument();
  });

  it('shows recent orders table with order data', async () => {
    setupAdminAuth();
    renderWithProviders(<AdminDashboard />);

    await waitFor(() => {
      expect(screen.getByText('Recent Orders')).toBeInTheDocument();
    });

    expect(screen.getByText('Alice')).toBeInTheDocument();
    expect(screen.getByText('#1')).toBeInTheDocument();
    expect(screen.getByText('$29.99')).toBeInTheDocument();
  });
});
