import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import LoyaltyPage from '../../src/pages/LoyaltyPage';

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

const mockLoyaltyData = {
  balance: 1250,
  history: [
    { id: 1, points: 100, reason: 'Purchase #42', created_at: '2024-01-15T10:00:00Z' },
    { id: 2, points: -50, reason: 'Redeemed at checkout', created_at: '2024-01-20T10:00:00Z' },
    { id: 3, points: 200, reason: 'Referral bonus', created_at: '2024-01-25T10:00:00Z' },
  ],
};

const mockReferralData = {
  referral_code: 'REF-USER123',
  referrals: [
    { id: 1, status: 'completed' },
    { id: 2, status: 'pending' },
  ],
};

const mockEmptyLoyaltyData = {
  balance: 0,
  history: [],
};

function renderLoyalty() {
  return render(
    <MemoryRouter initialEntries={['/loyalty']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/loyalty" element={<LoyaltyPage />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('LoyaltyPage', () => {
  describe('loading state', () => {
    it('shows loading indicator when data has not yet loaded', () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch.mockImplementation(() => new Promise(() => {})); // never resolves

      renderLoyalty();

      expect(screen.getByText(/Loading loyalty/i)).toBeInTheDocument();
    });
  });

  describe('authenticated with loyalty data', () => {
    beforeEach(() => {
      localStorage.getItem.mockImplementation(key => (key === 'token' ? 'mytoken' : null));
      global.fetch.mockImplementation(url => {
        if (url === '/api/loyalty')
          return Promise.resolve({ ok: true, json: async () => mockLoyaltyData });
        if (url === '/api/loyalty/referral')
          return Promise.resolve({ ok: true, json: async () => mockReferralData });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });
    });

    it('renders the Loyalty & Rewards heading', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByRole('heading', { name: /Loyalty & Rewards/i })).toBeInTheDocument();
      });
    });

    it('shows the loyalty points balance', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText('1,250')).toBeInTheDocument();
      });
    });

    it('shows the savings equivalent for points balance', async () => {
      renderLoyalty();

      await waitFor(() => {
        // 1250 points / 100 = $12.50
        expect(screen.getByText(/\$12\.50 in savings/i)).toBeInTheDocument();
      });
    });

    it('renders the Points History section', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText(/Points History/i)).toBeInTheDocument();
      });
    });

    it('shows each points history entry', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText('Purchase #42')).toBeInTheDocument();
        expect(screen.getByText('Redeemed at checkout')).toBeInTheDocument();
        expect(screen.getByText('Referral bonus')).toBeInTheDocument();
      });
    });

    it('shows positive points with a + prefix', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText('+100 pts')).toBeInTheDocument();
        expect(screen.getByText('+200 pts')).toBeInTheDocument();
      });
    });

    it('shows negative points without a + prefix', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText('-50 pts')).toBeInTheDocument();
      });
    });

    it('renders the Referral Program section with referral code', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText(/Referral Program/i)).toBeInTheDocument();
        expect(screen.getByText(/REF-USER123/)).toBeInTheDocument();
      });
    });

    it('shows the number of successful referrals', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText(/1 successful referral/i)).toBeInTheDocument();
      });
    });

    it('renders the Enter a Referral Code form', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText(/Enter a Referral Code/i)).toBeInTheDocument();
        expect(screen.getByPlaceholderText(/REF-/i)).toBeInTheDocument();
        expect(screen.getByRole('button', { name: /Apply/i })).toBeInTheDocument();
      });
    });

    it('shows success message when referral code is applied', async () => {
      global.fetch.mockImplementation(url => {
        if (url === '/api/loyalty')
          return Promise.resolve({ ok: true, json: async () => mockLoyaltyData });
        if (url === '/api/loyalty/referral')
          return Promise.resolve({ ok: true, json: async () => mockReferralData });
        if (url === '/api/loyalty/use-referral')
          return Promise.resolve({
            ok: true,
            json: async () => ({ points_earned: 200 }),
          });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });

      renderLoyalty();

      await waitFor(() => screen.getByPlaceholderText(/REF-/i));

      fireEvent.change(screen.getByPlaceholderText(/REF-/i), {
        target: { value: 'REF-FRIEND42' },
      });
      fireEvent.click(screen.getByRole('button', { name: /Apply/i }));

      await waitFor(() => {
        expect(screen.getByText(/200 loyalty points/i)).toBeInTheDocument();
      });
    });

    it('shows error message when referral code is invalid', async () => {
      global.fetch.mockImplementation(url => {
        if (url === '/api/loyalty')
          return Promise.resolve({ ok: true, json: async () => mockLoyaltyData });
        if (url === '/api/loyalty/referral')
          return Promise.resolve({ ok: true, json: async () => mockReferralData });
        if (url === '/api/loyalty/use-referral')
          return Promise.resolve({
            ok: false,
            json: async () => ({ error: 'Invalid or already used referral code' }),
          });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });

      renderLoyalty();

      await waitFor(() => screen.getByPlaceholderText(/REF-/i));

      fireEvent.change(screen.getByPlaceholderText(/REF-/i), {
        target: { value: 'REF-INVALID' },
      });
      fireEvent.click(screen.getByRole('button', { name: /Apply/i }));

      await waitFor(() => {
        expect(screen.getByText(/Invalid or already used referral code/i)).toBeInTheDocument();
      });
    });
  });

  describe('authenticated with empty points history', () => {
    beforeEach(() => {
      localStorage.getItem.mockImplementation(key => (key === 'token' ? 'mytoken' : null));
      global.fetch.mockImplementation(url => {
        if (url === '/api/loyalty')
          return Promise.resolve({ ok: true, json: async () => mockEmptyLoyaltyData });
        if (url === '/api/loyalty/referral')
          return Promise.resolve({ ok: true, json: async () => mockReferralData });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });
    });

    it('shows zero balance', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText('0')).toBeInTheDocument();
      });
    });

    it('shows empty history message', async () => {
      renderLoyalty();

      await waitFor(() => {
        expect(screen.getByText(/No points history yet/i)).toBeInTheDocument();
      });
    });
  });
});
