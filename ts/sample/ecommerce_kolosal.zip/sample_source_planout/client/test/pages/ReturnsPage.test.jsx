import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import ReturnsPage from '../../src/pages/ReturnsPage';

const mockReturns = [
  { id: 10, order_id: 42, status: 'pending', reason: 'Item damaged on arrival', notes: null, created_at: '2024-03-01T10:00:00Z' },
  { id: 11, order_id: 43, status: 'approved', reason: 'Wrong size', notes: 'Please ship back within 7 days', created_at: '2024-03-05T12:00:00Z' },
];

function renderReturns({ withReturns = false } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'fake-token' : null);

  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Test User', email: 'test@example.com', role: 'user' }) });
    if (url.includes('/api/returns')) return Promise.resolve({ ok: true, json: async () => (withReturns ? mockReturns : []) });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });

  return render(
    <MemoryRouter initialEntries={['/returns']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/returns" element={<ReturnsPage />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('ReturnsPage', () => {
  it('shows loading state initially', () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'fake-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Test User', email: 'test@example.com', role: 'user' }) });
      return new Promise(() => {});
    });

    render(
      <MemoryRouter initialEntries={['/returns']}>
        <AuthProvider>
          <CartProvider>
            <Routes>
              <Route path="/returns" element={<ReturnsPage />} />
            </Routes>
          </CartProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    expect(screen.getByText('Loading returns...')).toBeInTheDocument();
  });

  it('shows empty state when no return requests', async () => {
    renderReturns({ withReturns: false });
    await waitFor(() => expect(screen.getByText('Return Requests')).toBeInTheDocument());
    expect(screen.getByText('No return requests found.')).toBeInTheDocument();
  });

  it('shows return requests when populated', async () => {
    renderReturns({ withReturns: true });
    await waitFor(() => expect(screen.getByText('Return Request #10')).toBeInTheDocument());
    expect(screen.getByText('Return Request #11')).toBeInTheDocument();
  });

  it('shows return status information', async () => {
    renderReturns({ withReturns: true });
    await waitFor(() => expect(screen.getByText('Return Request #10')).toBeInTheDocument());
    expect(screen.getByText(/Pending/)).toBeInTheDocument();
    expect(screen.getByText(/Approved/)).toBeInTheDocument();
    expect(screen.getByText('Item damaged on arrival')).toBeInTheDocument();
  });
});
