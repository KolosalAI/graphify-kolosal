import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import ProfilePage from '../../src/pages/ProfilePage';

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

const mockProfile = {
  id: 1,
  name: 'Jane Smith',
  email: 'jane@example.com',
  role: 'user',
  orderCount: 5,
  wishlistCount: 3,
  reviewCount: 2,
  loyalty_points_balance: 150,
  subscription_plan: 'free',
  referral_code: 'REF-JANE123',
  created_at: '2024-01-01T00:00:00Z',
};

function renderProfile() {
  return render(
    <MemoryRouter initialEntries={['/profile']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/addresses" element={<div>Address Book</div>} />
            <Route path="/loyalty" element={<div>Loyalty</div>} />
            <Route path="/prime" element={<div>Prime</div>} />
            <Route path="/support" element={<div>Support</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('ProfilePage', () => {
  describe('loading state', () => {
    it('shows loading indicator before data arrives', () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch.mockImplementation(() => new Promise(() => {})); // never resolves

      renderProfile();

      expect(screen.getByText(/Loading profile/i)).toBeInTheDocument();
    });
  });

  describe('unauthenticated (no token) — API returns empty profile', () => {
    beforeEach(() => {
      localStorage.getItem.mockReturnValue(null);
      // authFetch still calls fetch without auth header; API returns empty object
      global.fetch.mockResolvedValue({ ok: false, json: async () => ({}) });
    });

    it('stops loading after API responds', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.queryByText(/Loading profile/i)).not.toBeInTheDocument();
      });
    });
  });

  describe('authenticated with profile data', () => {
    beforeEach(() => {
      localStorage.getItem.mockImplementation(key => (key === 'token' ? 'mytoken' : null));
      global.fetch.mockImplementation(url => {
        if (url === '/api/profile')
          return Promise.resolve({ ok: true, json: async () => mockProfile });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });
    });

    it('renders the My Account heading', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.getByRole('heading', { name: /My Account/i })).toBeInTheDocument();
      });
    });

    it('shows the user name from the API in the profile form', async () => {
      renderProfile();

      await waitFor(() => {
        const nameInput = screen.getByDisplayValue('Jane Smith');
        expect(nameInput).toBeInTheDocument();
      });
    });

    it('shows the user email from the API in the profile form', async () => {
      renderProfile();

      await waitFor(() => {
        const emailInput = screen.getByDisplayValue('jane@example.com');
        expect(emailInput).toBeInTheDocument();
      });
    });

    it('renders the Personal Information form section', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.getByText(/Personal Information/i)).toBeInTheDocument();
        expect(screen.getByRole('button', { name: /Save Changes/i })).toBeInTheDocument();
      });
    });

    it('renders the Change Password form section', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.getByRole('heading', { name: /Change Password/i })).toBeInTheDocument();
        expect(screen.getByRole('button', { name: /Change Password/i })).toBeInTheDocument();
      });
    });

    it('shows account stats (orders, wishlist, reviews)', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.getByText('Orders')).toBeInTheDocument();
        expect(screen.getByText('Wishlist')).toBeInTheDocument();
        expect(screen.getByText('Reviews')).toBeInTheDocument();
        expect(screen.getByText('5')).toBeInTheDocument();
        expect(screen.getByText('3')).toBeInTheDocument();
        expect(screen.getByText('2')).toBeInTheDocument();
      });
    });

    it('shows the referral code', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.getByText('REF-JANE123')).toBeInTheDocument();
      });
    });

    it('shows the loyalty points balance link', async () => {
      renderProfile();

      await waitFor(() => {
        expect(screen.getByText(/150 pts available/i)).toBeInTheDocument();
      });
    });

    it('shows success message after saving profile', async () => {
      global.fetch.mockImplementation(url => {
        if (url === '/api/profile')
          return Promise.resolve({ ok: true, json: async () => mockProfile });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });

      renderProfile();

      // Wait for form to be populated (useEffect sets values after profile loads)
      await waitFor(() => {
        expect(screen.getByDisplayValue('Jane Smith')).toBeInTheDocument();
      });

      fireEvent.click(screen.getByRole('button', { name: /Save Changes/i }));

      await waitFor(() => {
        expect(screen.getByText(/Profile updated successfully/i)).toBeInTheDocument();
      });
    });

    it('shows error message when passwords do not match on change password', async () => {
      renderProfile();

      await waitFor(() => screen.getByRole('heading', { name: /Change Password/i }));

      // Password inputs have no associated labels, query them via the DOM directly
      const passwordInputs = document.querySelectorAll('input[type="password"]');
      // [0] = Current Password, [1] = New Password, [2] = Confirm New Password
      fireEvent.change(passwordInputs[0], { target: { value: 'oldpass' } });
      fireEvent.change(passwordInputs[1], { target: { value: 'newpass1' } });
      fireEvent.change(passwordInputs[2], { target: { value: 'differentpass' } });

      fireEvent.click(screen.getByRole('button', { name: /Change Password/i }));

      await waitFor(() => {
        expect(screen.getByText(/New passwords do not match/i)).toBeInTheDocument();
      });
    });
  });
});
