import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import ProductPage from '../../src/pages/ProductPage';

function renderProduct(slug = 'test-product') {
  return render(
    <MemoryRouter initialEntries={[`/products/${slug}`]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/products/:slug" element={<ProductPage />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

const mockProduct = {
  id: 1, name: 'Test Product', slug: 'test-product', price: 29.99,
  description: 'A great product', stock: 10, category_name: 'Electronics',
  category_slug: 'electronics', images: [], review_count: 0, avg_rating: 0,
};

describe('ProductPage', () => {
  it('shows loading state initially', () => {
    global.fetch.mockImplementation(() => new Promise(() => {}));
    renderProduct();
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('shows product details after fetch', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/products/')) return Promise.resolve({ ok: true, json: async () => mockProduct });
      if (url.includes('/api/reviews/')) return Promise.resolve({ ok: true, json: async () => ({ stats: null, reviews: [], userReview: null }) });
      if (url.includes('/api/recommendations/also-bought/')) return Promise.resolve({ ok: true, json: async () => [] });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderProduct();
    await waitFor(() => expect(screen.getByText('Test Product')).toBeInTheDocument());
    expect(screen.getByText(/29\.99/)).toBeInTheDocument();
    expect(screen.getByText('A great product')).toBeInTheDocument();
  });

  it('shows product not found when fetch fails', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/products/')) return Promise.resolve({ ok: false, json: async () => ({}) });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderProduct();
    await waitFor(() => expect(screen.getByText('Product not found')).toBeInTheDocument());
  });

  it('shows Add to Cart button when product has stock', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/products/')) return Promise.resolve({ ok: true, json: async () => mockProduct });
      if (url.includes('/api/reviews/')) return Promise.resolve({ ok: true, json: async () => ({ stats: null, reviews: [], userReview: null }) });
      if (url.includes('/api/recommendations/also-bought/')) return Promise.resolve({ ok: true, json: async () => [] });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderProduct();
    await waitFor(() => expect(screen.getByText('Add to Cart')).toBeInTheDocument());
  });

  it('renders reviews section', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/products/')) return Promise.resolve({ ok: true, json: async () => mockProduct });
      if (url.includes('/api/reviews/')) return Promise.resolve({ ok: true, json: async () => ({ stats: null, reviews: [], userReview: null }) });
      if (url.includes('/api/recommendations/also-bought/')) return Promise.resolve({ ok: true, json: async () => [] });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderProduct();
    await waitFor(() => expect(screen.getByText('Test Product')).toBeInTheDocument());
    expect(document.getElementById('reviews')).toBeInTheDocument();
  });

  it('adds item with variant-adjusted price when a variant is selected', async () => {
    const productWithVariant = {
      ...mockProduct,
      variants: [{ id: 10, group_name: 'Size', value: 'XL', price_modifier: 5, stock: 10 }],
    };
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/products/')) return Promise.resolve({ ok: true, json: async () => productWithVariant });
      if (url.includes('/api/reviews/')) return Promise.resolve({ ok: true, json: async () => ({ stats: null, reviews: [], userReview: null }) });
      if (url.includes('/api/recommendations/also-bought/')) return Promise.resolve({ ok: true, json: async () => [] });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderProduct();

    await waitFor(() => expect(screen.getByText('XL (+$5)')).toBeInTheDocument());

    // Select the XL variant
    fireEvent.click(screen.getByText('XL (+$5)'));

    // Add to cart
    fireEvent.click(screen.getByText('Add to Cart'));

    // Wait for cart confirmation feedback, then inspect persisted cart
    await waitFor(() => expect(screen.getByText('✓ Added to Cart!')).toBeInTheDocument());

    // CartContext persists to localStorage after every state change — find the last write
    const cartCalls = localStorage.setItem.mock.calls.filter(([key]) => key === 'shopkolosal_cart');
    const lastCartJson = cartCalls[cartCalls.length - 1][1];
    const cartItems = JSON.parse(lastCartJson);
    // Price should be base (29.99) + modifier (5) = 34.99
    expect(cartItems[0].price).toBe(34.99);
  });

  it('alsoViewed items link to /product/:slug not /products/:slug', async () => {
    const productWithAlsoViewed = {
      ...mockProduct,
      alsoViewed: [{ id: 99, name: 'Also Viewed Item', slug: 'also-viewed-item', price: 15.99, avg_rating: 4 }],
    };
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/products/')) return Promise.resolve({ ok: true, json: async () => productWithAlsoViewed });
      if (url.includes('/api/reviews/')) return Promise.resolve({ ok: true, json: async () => ({ stats: null, reviews: [], userReview: null }) });
      if (url.includes('/api/recommendations/also-bought/')) return Promise.resolve({ ok: true, json: async () => [] });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderProduct();
    await waitFor(() => expect(screen.getByText('Also Viewed Item')).toBeInTheDocument());
    const link = screen.getByText('Also Viewed Item').closest('a');
    expect(link).toHaveAttribute('href', '/product/also-viewed-item');
  });
});
