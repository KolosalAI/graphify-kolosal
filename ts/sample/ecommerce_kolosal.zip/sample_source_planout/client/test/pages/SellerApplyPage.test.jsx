import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SellerApplyPage from '../../src/pages/SellerApplyPage';

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

function setupAuthMocks() {
  localStorage.getItem.mockImplementation((key) =>
    key === 'token' ? 'fake-token' : null
  );
  global.fetch.mockImplementation((url) => {
    if (url === '/api/auth/me') {
      return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
    }
    return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
  });
}

describe('SellerApplyPage', () => {
  it('shows a login prompt when the user is not authenticated', () => {
    // No token in localStorage — AuthContext sets user=null
    renderWithProviders(
      <SellerApplyPage />,
      { route: '/sell/apply', path: '/sell/apply' }
    );

    expect(screen.getByRole('link', { name: /log in/i })).toBeInTheDocument();
    expect(screen.getByText(/apply as a seller/i)).toBeInTheDocument();
  });

  it('shows the Become a Seller heading when the user is authenticated', async () => {
    setupAuthMocks();

    renderWithProviders(
      <SellerApplyPage />,
      { route: '/sell/apply', path: '/sell/apply' }
    );

    await waitFor(() =>
      expect(
        screen.getByRole('heading', { name: /Become a Seller/i })
      ).toBeInTheDocument()
    );
  });

  it('renders Store Name and Store Description form fields when authenticated', async () => {
    setupAuthMocks();

    renderWithProviders(
      <SellerApplyPage />,
      { route: '/sell/apply', path: '/sell/apply' }
    );

    await waitFor(() =>
      expect(screen.getByPlaceholderText('My Awesome Store')).toBeInTheDocument()
    );
    expect(
      screen.getByPlaceholderText('Tell customers what you sell...')
    ).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /Apply to Become a Seller/i })
    ).toBeInTheDocument();
  });

  it('shows the Application Submitted success state after submitting the form', async () => {
    localStorage.getItem.mockImplementation((key) =>
      key === 'token' ? 'fake-token' : null
    );
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
      }
      if (url === '/api/sellers/apply') {
        return Promise.resolve({
          ok: true,
          json: () =>
            Promise.resolve({ id: 10, store_name: 'My Shop', status: 'pending' }),
        });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(
      <SellerApplyPage />,
      { route: '/sell/apply', path: '/sell/apply' }
    );

    await waitFor(() =>
      expect(screen.getByPlaceholderText('My Awesome Store')).toBeInTheDocument()
    );

    fireEvent.change(screen.getByPlaceholderText('My Awesome Store'), {
      target: { value: 'My Awesome Shop' },
    });
    fireEvent.change(
      screen.getByPlaceholderText('Tell customers what you sell...'),
      { target: { value: 'We sell great products.' } }
    );
    fireEvent.click(
      screen.getByRole('button', { name: /Apply to Become a Seller/i })
    );

    await waitFor(() =>
      expect(
        screen.getByRole('heading', { name: /Application Submitted!/i })
      ).toBeInTheDocument()
    );
  });
});
