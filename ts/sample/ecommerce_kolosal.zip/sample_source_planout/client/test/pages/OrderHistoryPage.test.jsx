import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import OrderHistoryPage from '../../src/pages/OrderHistoryPage';

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

const mockOrders = [
  {
    id: 42,
    status: 'delivered',
    created_at: '2024-01-15T10:00:00Z',
    total: 89.99,
    subtotal: 89.99,
    discount: 0,
    items: [{ id: 1, name: 'Widget' }],
    coupon_code: null,
  },
  {
    id: 43,
    status: 'pending',
    created_at: '2024-01-20T10:00:00Z',
    total: 45.0,
    subtotal: 45.0,
    discount: 0,
    items: [],
    coupon_code: null,
  },
];

function renderOrderHistory() {
  return render(
    <MemoryRouter initialEntries={['/orders']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/orders" element={<OrderHistoryPage />} />
            <Route path="/order/:id" element={<div>Order Detail</div>} />
            <Route path="/" element={<div>Home</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('OrderHistoryPage', () => {
  describe('unauthenticated (no token)', () => {
    beforeEach(() => {
      localStorage.getItem.mockReturnValue(null);
    });

    it('shows empty state when no orders are returned', async () => {
      global.fetch.mockResolvedValue({ ok: true, json: async () => [] });

      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByText(/No orders yet/i)).toBeInTheDocument();
      });
    });

    it('renders a link to start shopping', async () => {
      global.fetch.mockResolvedValue({ ok: true, json: async () => [] });

      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByRole('link', { name: /Start Shopping/i })).toBeInTheDocument();
      });
    });
  });

  describe('loading state', () => {
    it('shows loading indicator before data arrives', () => {
      localStorage.getItem.mockReturnValue(null);
      global.fetch.mockImplementation(() => new Promise(() => {})); // never resolves

      renderOrderHistory();

      expect(screen.getByText(/Loading orders/i)).toBeInTheDocument();
    });
  });

  describe('authenticated with orders', () => {
    beforeEach(() => {
      localStorage.getItem.mockImplementation(key => (key === 'token' ? 'mytoken' : null));
      global.fetch.mockImplementation(url => {
        if (url === '/api/orders/my-orders')
          return Promise.resolve({ ok: true, json: async () => mockOrders });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });
    });

    it('renders the Order History heading', async () => {
      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByRole('heading', { name: /Order History/i })).toBeInTheDocument();
      });
    });

    it('renders a card for each order', async () => {
      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByText(/Order #42/i)).toBeInTheDocument();
        expect(screen.getByText(/Order #43/i)).toBeInTheDocument();
      });
    });

    it('shows order status for each order', async () => {
      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByText('delivered')).toBeInTheDocument();
        expect(screen.getByText('pending')).toBeInTheDocument();
      });
    });

    it('shows the order total for each order', async () => {
      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByText('$89.99')).toBeInTheDocument();
        expect(screen.getByText('$45.00')).toBeInTheDocument();
      });
    });

    it('renders a View link for each order', async () => {
      renderOrderHistory();

      await waitFor(() => {
        const viewLinks = screen.getAllByRole('link', { name: /View/i });
        expect(viewLinks.length).toBeGreaterThanOrEqual(mockOrders.length);
      });
    });

    it('shows Cancel button for pending orders', async () => {
      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByRole('button', { name: /Cancel/i })).toBeInTheDocument();
      });
    });

    it('shows Return link for delivered orders', async () => {
      renderOrderHistory();

      await waitFor(() => {
        expect(screen.getByRole('link', { name: /Return/i })).toBeInTheDocument();
      });
    });
  });
});
