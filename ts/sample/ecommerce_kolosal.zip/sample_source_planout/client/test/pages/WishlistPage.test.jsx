import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import WishlistPage from '../../src/pages/WishlistPage';

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

const mockWishlistItems = [
  {
    id: 1,
    product_id: 101,
    name: 'Wireless Headphones',
    price: 79.99,
    image_url: '/headphones.jpg',
    slug: 'wireless-headphones',
    category_name: 'Electronics',
    stock: 10,
  },
  {
    id: 2,
    product_id: 102,
    name: 'Running Shoes',
    price: 49.99,
    image_url: '/shoes.jpg',
    slug: 'running-shoes',
    category_name: 'Sports',
    stock: 0,
  },
];

function renderWishlist() {
  return render(
    <MemoryRouter initialEntries={['/wishlist']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/wishlist" element={<WishlistPage />} />
            <Route path="/" element={<div>Home</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('WishlistPage', () => {
  describe('unauthenticated (no token)', () => {
    beforeEach(() => {
      localStorage.getItem.mockReturnValue(null);
    });

    it('shows empty state when wishlist returns no items', async () => {
      global.fetch.mockResolvedValue({ ok: true, json: async () => [] });

      renderWishlist();

      await waitFor(() => {
        expect(screen.getByText(/Your wishlist is empty/i)).toBeInTheDocument();
      });
    });

    it('renders a browse products link when wishlist is empty', async () => {
      global.fetch.mockResolvedValue({ ok: true, json: async () => [] });

      renderWishlist();

      await waitFor(() => {
        expect(screen.getByRole('button', { name: /Browse Products/i })).toBeInTheDocument();
      });
    });
  });

  describe('authenticated', () => {
    beforeEach(() => {
      localStorage.getItem.mockImplementation(key => (key === 'token' ? 'mytoken' : null));
      global.fetch.mockImplementation(url => {
        if (url === '/api/wishlist')
          return Promise.resolve({ ok: true, json: async () => mockWishlistItems });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });
    });

    it('renders wishlist items when API returns data', async () => {
      renderWishlist();

      await waitFor(() => {
        expect(screen.getByText('Wireless Headphones')).toBeInTheDocument();
        expect(screen.getByText('Running Shoes')).toBeInTheDocument();
      });
    });

    it('shows item prices', async () => {
      renderWishlist();

      await waitFor(() => {
        expect(screen.getByText('$79.99')).toBeInTheDocument();
        expect(screen.getByText('$49.99')).toBeInTheDocument();
      });
    });

    it('shows in-stock and out-of-stock status', async () => {
      renderWishlist();

      await waitFor(() => {
        expect(screen.getByText('In Stock')).toBeInTheDocument();
        expect(screen.getByText('Out of Stock')).toBeInTheDocument();
      });
    });

    it('renders a Remove button for each wishlist item', async () => {
      renderWishlist();

      await waitFor(() => {
        const removeButtons = screen.getAllByRole('button', { name: /Remove/i });
        expect(removeButtons).toHaveLength(mockWishlistItems.length);
      });
    });

    it('removes item from list when Remove is clicked', async () => {
      global.fetch.mockImplementation(url => {
        if (url === '/api/wishlist')
          return Promise.resolve({ ok: true, json: async () => mockWishlistItems });
        if (url.startsWith('/api/wishlist/'))
          return Promise.resolve({ ok: true, json: async () => ({}) });
        if (url === '/api/auth/me')
          return Promise.resolve({ ok: true, json: async () => mockUser });
        return Promise.resolve({ ok: true, json: async () => [] });
      });

      renderWishlist();

      await waitFor(() => screen.getByText('Wireless Headphones'));

      const [firstRemove] = screen.getAllByRole('button', { name: /Remove/i });
      fireEvent.click(firstRemove);

      await waitFor(() => {
        expect(screen.queryByText('Wireless Headphones')).not.toBeInTheDocument();
      });
    });

    it('shows item category', async () => {
      renderWishlist();

      await waitFor(() => {
        expect(screen.getByText('Electronics')).toBeInTheDocument();
        expect(screen.getByText('Sports')).toBeInTheDocument();
      });
    });
  });
});
