import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SellerAnalyticsPage from '../../src/pages/SellerAnalyticsPage';

const mockAnalytics = {
  monthly: [{ month: '2024-01', orders: 3, revenue: 89.97 }],
  daily: [{ date: '2024-01-15', orders: 1, revenue: 29.99 }],
};

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAuthMock({ analytics = mockAnalytics, fail = false } = {}) {
  localStorage.getItem.mockImplementation((key) =>
    key === 'token' ? 'fake-token' : null
  );
  global.fetch.mockImplementation((url) => {
    if (url === '/api/auth/me') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
      });
    }
    if (url === '/api/sellers/me/analytics') {
      if (fail) {
        return Promise.resolve({
          ok: false,
          json: () => Promise.resolve({ error: 'Failed to fetch analytics' }),
        });
      }
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(analytics),
      });
    }
    return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.getItem.mockReturnValue(null);
  global.fetch.mockResolvedValue({
    ok: true,
    json: () => Promise.resolve({}),
  });
});

describe('SellerAnalyticsPage', () => {
  it('shows loading state', () => {
    localStorage.getItem.mockImplementation((key) =>
      key === 'token' ? 'fake-token' : null
    );
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
        });
      }
      return new Promise(() => {}); // never resolves
    });

    renderWithProviders(<SellerAnalyticsPage />);
    expect(screen.getByText('Loading analytics...')).toBeInTheDocument();
  });

  it('shows error message when analytics fetch fails', async () => {
    setupAuthMock({ fail: true });

    renderWithProviders(<SellerAnalyticsPage />);
    await waitFor(() => {
      expect(
        screen.getByText(/failed to fetch analytics/i) ||
        screen.getByText(/error/i)
      ).toBeInTheDocument();
    });
  });

  it('shows Sales Analytics heading after fetch', async () => {
    setupAuthMock();

    renderWithProviders(<SellerAnalyticsPage />);
    await waitFor(() => {
      expect(screen.getByText(/Sales Analytics/i)).toBeInTheDocument();
    });
  });

  it('shows monthly revenue section', async () => {
    setupAuthMock();

    renderWithProviders(<SellerAnalyticsPage />);
    await waitFor(() => {
      expect(
        screen.getByText(/Monthly Revenue/i)
      ).toBeInTheDocument();
    });

    expect(screen.getByText(/Last 12 Months/i)).toBeInTheDocument();
  });
});
