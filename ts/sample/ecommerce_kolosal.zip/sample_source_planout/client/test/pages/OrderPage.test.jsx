import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import OrderPage from '../../src/pages/OrderPage';

const mockOrder = {
  id: 42, customer_name: 'Jane Doe', customer_email: 'jane@test.com',
  shipping_address: '123 Main St', status: 'confirmed',
  total: 59.98, tax_amount: 0, shipping_cost: 0, gift_card_discount: 0,
  items: [{ id: 1, product_name: 'Widget A', quantity: 2, price: 19.99 }],
};

function renderOrder(orderId = '42') {
  return render(
    <MemoryRouter initialEntries={[`/order/${orderId}`]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/order/:id" element={<OrderPage />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('OrderPage', () => {
  it('shows loading state initially', () => {
    global.fetch.mockImplementation(() => new Promise(() => {}));
    renderOrder();
    expect(screen.getByText('Loading order...')).toBeInTheDocument();
  });

  it('shows order confirmed after fetch', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/orders/')) return Promise.resolve({ ok: true, json: async () => mockOrder });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderOrder();
    await waitFor(() => expect(screen.getByText('Order Confirmed!')).toBeInTheDocument());
    expect(screen.getByText('Order #42')).toBeInTheDocument();
  });

  it('shows order not found when fetch fails', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/orders/')) return Promise.resolve({ ok: false, json: async () => ({}) });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderOrder();
    await waitFor(() => expect(screen.getByText('Order not found')).toBeInTheDocument());
  });

  it('shows order details including status and total', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/orders/')) return Promise.resolve({ ok: true, json: async () => mockOrder });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderOrder();
    await waitFor(() => expect(screen.getByText('confirmed')).toBeInTheDocument());
    expect(screen.getByText('Jane Doe')).toBeInTheDocument();
    expect(screen.getByText('$59.98')).toBeInTheDocument();
  });

  it('shows order items', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/orders/')) return Promise.resolve({ ok: true, json: async () => mockOrder });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });
    renderOrder();
    await waitFor(() => expect(screen.getByText(/Widget A/)).toBeInTheDocument());
  });

  it('invoice download is a button that fetches with auth header, not a bare anchor', async () => {
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/orders/')) return Promise.resolve({ ok: true, json: async () => mockOrder });
      if (url.includes('/api/invoices/'))
        return Promise.resolve({
          ok: true,
          blob: async () => new Blob(['%PDF'], { type: 'application/pdf' }),
        });
      return Promise.resolve({ ok: true, json: async () => ({}) });
    });

    localStorage.getItem.mockImplementation(key => key === 'token' ? 'test-token' : null);

    render(
      <MemoryRouter initialEntries={['/order/42']}>
        <AuthProvider>
          <CartProvider>
            <Routes>
              <Route path="/order/:id" element={<OrderPage />} />
            </Routes>
          </CartProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    await waitFor(() => expect(screen.getByText('Order Confirmed!')).toBeInTheDocument());

    // Must NOT be a bare anchor pointing directly at the PDF endpoint
    const anchors = document.querySelectorAll('a[href*="/api/invoices/"]');
    expect(anchors.length).toBe(0);

    // Must be a button that triggers fetch
    const downloadBtn = screen.getByRole('button', { name: /Download Invoice/i });
    expect(downloadBtn).toBeInTheDocument();
  });
});
