import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import LoginPage from '../../src/pages/LoginPage';

function renderLogin() {
  return render(
    <MemoryRouter initialEntries={['/login']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/" element={<div>Home</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('LoginPage', () => {
  beforeEach(() => {
    localStorage.getItem.mockReturnValue(null);
    global.fetch.mockResolvedValue({ ok: false, json: async () => ({}) });
  });

  it('renders login form', async () => {
    renderLogin();
    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /Login/i })).toBeInTheDocument();
      expect(screen.getByLabelText(/Email/i)).toBeInTheDocument();
      expect(screen.getByLabelText(/Password/i)).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Login/i })).toBeInTheDocument();
    });
  });

  it('renders Forgot password link', async () => {
    renderLogin();
    await waitFor(() => {
      expect(screen.getByRole('link', { name: /Forgot your password/i })).toBeInTheDocument();
    });
  });

  it('renders Register link', async () => {
    renderLogin();
    await waitFor(() => {
      expect(screen.getByRole('link', { name: /Register/i })).toBeInTheDocument();
    });
  });

  it('shows error on failed login', async () => {
    global.fetch.mockResolvedValueOnce({
      ok: false,
      json: async () => ({ error: 'Invalid email or password.' }),
    });

    renderLogin();
    await waitFor(() => screen.getByLabelText(/Email/i));

    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'bad@test.com' } });
    fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'badpass' } });
    fireEvent.click(screen.getByRole('button', { name: /Login/i }));

    await waitFor(() => {
      expect(screen.getByText(/Invalid email or password/i)).toBeInTheDocument();
    });
  });

  it('redirects to home on successful login', async () => {
    global.fetch
      .mockResolvedValueOnce({ ok: true, json: async () => ({ user: { id: 1, name: 'User', role: 'user' }, token: 'tok' }) })  // login
      .mockResolvedValueOnce({ ok: true, json: async () => [] }); // cart load

    renderLogin();
    await waitFor(() => screen.getByLabelText(/Email/i));

    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'user@test.com' } });
    fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('button', { name: /Login/i }));

    await waitFor(() => {
      expect(screen.getByText('Home')).toBeInTheDocument();
    });
  });

  it('disables submit button while submitting', async () => {
    global.fetch.mockImplementation(() => new Promise(resolve =>
      setTimeout(() => resolve({ ok: true, json: async () => ({ user: {}, token: 'tok' }) }), 100)
    ));

    renderLogin();
    await waitFor(() => screen.getByLabelText(/Email/i));

    fireEvent.change(screen.getByLabelText(/Email/i), { target: { value: 'user@test.com' } });
    fireEvent.change(screen.getByLabelText(/Password/i), { target: { value: 'password123' } });
    fireEvent.click(screen.getByRole('button', { name: /Login/i }));

    expect(screen.getByRole('button', { name: /Logging in/i })).toBeDisabled();
  });
});
