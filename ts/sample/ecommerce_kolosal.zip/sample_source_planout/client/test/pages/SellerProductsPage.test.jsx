import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SellerProductsPage from '../../src/pages/SellerProductsPage';

const mockProducts = [
  { id: 1, name: 'Widget A', price: 19.99, stock: 10, category_id: 1 },
  { id: 2, name: 'Gadget B', price: 49.99, stock: 3, category_id: 2 },
];

const mockCategories = [
  { id: 1, name: 'Electronics' },
  { id: 2, name: 'Accessories' },
];

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAuthMock({ products = mockProducts } = {}) {
  localStorage.getItem.mockImplementation((key) =>
    key === 'token' ? 'fake-token' : null
  );
  global.fetch.mockImplementation((url) => {
    if (url === '/api/auth/me') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
      });
    }
    if (url === '/api/categories') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(mockCategories),
      });
    }
    if (url === '/api/sellers/me/products') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(products),
      });
    }
    return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.getItem.mockReturnValue(null);
  global.fetch.mockResolvedValue({
    ok: true,
    json: () => Promise.resolve([]),
  });
});

describe('SellerProductsPage', () => {
  it('shows loading state', () => {
    localStorage.getItem.mockImplementation((key) =>
      key === 'token' ? 'fake-token' : null
    );
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
        });
      }
      return new Promise(() => {}); // never resolves
    });

    renderWithProviders(<SellerProductsPage />);
    expect(screen.getByText('Loading products...')).toBeInTheDocument();
  });

  it('shows empty state when no products', async () => {
    setupAuthMock({ products: [] });

    renderWithProviders(<SellerProductsPage />);
    await waitFor(() => {
      expect(
        screen.getByText(/you haven't listed any products yet/i)
      ).toBeInTheDocument();
    });

    expect(screen.getByText(/My Products/i)).toBeInTheDocument();
  });

  it('shows product list when products are loaded', async () => {
    setupAuthMock();

    renderWithProviders(<SellerProductsPage />);
    await waitFor(() => {
      expect(screen.getByText('Widget A')).toBeInTheDocument();
    });

    expect(screen.getByText('Gadget B')).toBeInTheDocument();
  });

  it('shows add product form when button clicked', async () => {
    setupAuthMock();

    renderWithProviders(<SellerProductsPage />);
    await waitFor(() => {
      expect(screen.getByText(/\+ Add Product/i)).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText(/\+ Add Product/i));

    await waitFor(() => {
      expect(screen.getByText(/List Product/i)).toBeInTheDocument();
    });

    expect(screen.getAllByRole('textbox')[0]).toBeInTheDocument();
  });
});
