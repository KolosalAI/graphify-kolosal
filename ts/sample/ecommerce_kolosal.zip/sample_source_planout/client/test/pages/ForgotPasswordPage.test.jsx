import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import ForgotPasswordPage from '../../src/pages/ForgotPasswordPage';

function renderForgotPassword() {
  return render(
    <MemoryRouter initialEntries={['/forgot-password']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/login" element={<div>Login Page</div>} />
            <Route path="/reset-password" element={<div>Reset Password Page</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('ForgotPasswordPage', () => {
  beforeEach(() => {
    localStorage.getItem.mockReturnValue(null);
    global.fetch.mockResolvedValue({ ok: false, json: async () => ({}) });
  });

  it('renders email input and submit button', () => {
    renderForgotPassword();
    expect(screen.getByLabelText(/Email Address/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Send Reset Link/i })).toBeInTheDocument();
  });

  it('renders the Forgot Password heading', () => {
    renderForgotPassword();
    expect(screen.getByRole('heading', { name: /Forgot Password/i })).toBeInTheDocument();
  });

  it('renders a link back to the login page', () => {
    renderForgotPassword();
    expect(screen.getByRole('link', { name: /Back to Login/i })).toBeInTheDocument();
  });

  it('shows success message when fetch returns ok', async () => {
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ message: 'Email sent' }),
    });

    renderForgotPassword();

    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'user@example.com' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Send Reset Link/i }));

    await waitFor(() => {
      expect(screen.getByRole('heading', { name: /Check Your Email/i })).toBeInTheDocument();
    });

    expect(screen.getByText(/user@example\.com/i)).toBeInTheDocument();
  });

  it('shows reset token link in demo mode when token is returned', async () => {
    global.fetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({ reset_token: 'demo-reset-token-xyz' }),
    });

    renderForgotPassword();

    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'user@example.com' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Send Reset Link/i }));

    await waitFor(() => {
      expect(screen.getByText('demo-reset-token-xyz')).toBeInTheDocument();
    });
  });

  it('shows error message when fetch fails', async () => {
    global.fetch.mockResolvedValueOnce({
      ok: false,
      json: async () => ({ error: 'No account found with that email' }),
    });

    renderForgotPassword();

    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'nobody@example.com' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Send Reset Link/i }));

    await waitFor(() => {
      expect(screen.getByText(/No account found with that email/i)).toBeInTheDocument();
    });
  });

  it('disables button and shows loading text while submitting', async () => {
    global.fetch.mockImplementation(
      () => new Promise(resolve =>
        setTimeout(() => resolve({ ok: true, json: async () => ({}) }), 200)
      )
    );

    renderForgotPassword();

    fireEvent.change(screen.getByLabelText(/Email Address/i), {
      target: { value: 'user@example.com' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Send Reset Link/i }));

    expect(screen.getByRole('button', { name: /Sending/i })).toBeDisabled();
  });
});
