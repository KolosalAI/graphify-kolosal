import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SellerDashboardPage from '../../src/pages/SellerDashboardPage';

const mockDashboard = {
  seller: { store_name: 'My Test Store', id: 1 },
  totalProducts: 5,
  totalOrders: 12,
  totalRevenue: 349.99,
  recentOrders: [
    {
      id: 1,
      customer_name: 'John',
      created_at: new Date().toISOString(),
      total: 29.99,
      status: 'pending',
    },
  ],
  topProducts: [],
};

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAuthMock() {
  localStorage.getItem.mockImplementation((key) =>
    key === 'token' ? 'fake-token' : null
  );
  global.fetch.mockImplementation((url) => {
    if (url === '/api/auth/me') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
      });
    }
    return Promise.resolve({
      ok: true,
      json: () => Promise.resolve(mockDashboard),
    });
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.getItem.mockReturnValue(null);
  global.fetch.mockResolvedValue({
    ok: true,
    json: () => Promise.resolve({}),
  });
});

describe('SellerDashboardPage', () => {
  it('shows loading state', () => {
    setupAuthMock();
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
        });
      }
      return new Promise(() => {}); // never resolves
    });

    renderWithProviders(<SellerDashboardPage />);
    expect(screen.getByText('Loading dashboard...')).toBeInTheDocument();
  });

  it('shows not approved seller message when no data or error returned', async () => {
    setupAuthMock();
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
        });
      }
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ error: 'Not a seller' }),
      });
    });

    renderWithProviders(<SellerDashboardPage />);
    await waitFor(() => {
      expect(
        screen.getByText(/you are not an approved seller/i)
      ).toBeInTheDocument();
    });
  });

  it('shows dashboard with store name and stats when data loads', async () => {
    setupAuthMock();

    renderWithProviders(<SellerDashboardPage />);
    await waitFor(() => {
      expect(screen.getByText(/My Test Store/i)).toBeInTheDocument();
    });

    expect(screen.getByText('5')).toBeInTheDocument();
    expect(screen.getByText('12')).toBeInTheDocument();
  });

  it('shows recent orders section', async () => {
    setupAuthMock();

    renderWithProviders(<SellerDashboardPage />);
    await waitFor(() => {
      expect(screen.getByText(/Recent Orders/i)).toBeInTheDocument();
    });

    expect(screen.getByText(/John/i)).toBeInTheDocument();
  });
});
