import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SellerOrdersPage from '../../src/pages/SellerOrdersPage';

const mockOrders = [
  {
    id: 101,
    customer_name: 'Alice Smith',
    created_at: new Date().toISOString(),
    total: 59.98,
    status: 'pending',
    items: [
      { product_name: 'Widget A', quantity: 2, price: 19.99 },
    ],
  },
  {
    id: 102,
    customer_name: 'Bob Jones',
    created_at: new Date().toISOString(),
    total: 49.99,
    status: 'shipped',
    items: [
      { product_name: 'Gadget B', quantity: 1, price: 49.99 },
    ],
  },
];

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

function setupAuthMock({ orders = mockOrders } = {}) {
  localStorage.getItem.mockImplementation((key) =>
    key === 'token' ? 'fake-token' : null
  );
  global.fetch.mockImplementation((url) => {
    if (url === '/api/auth/me') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
      });
    }
    if (url === '/api/sellers/me/orders') {
      return Promise.resolve({
        ok: true,
        json: () => Promise.resolve(orders),
      });
    }
    return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
  });
}

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.getItem.mockReturnValue(null);
  global.fetch.mockResolvedValue({
    ok: true,
    json: () => Promise.resolve([]),
  });
});

describe('SellerOrdersPage', () => {
  it('shows loading state', () => {
    localStorage.getItem.mockImplementation((key) =>
      key === 'token' ? 'fake-token' : null
    );
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ id: 1, name: 'Test User', role: 'seller' }),
        });
      }
      return new Promise(() => {}); // never resolves
    });

    renderWithProviders(<SellerOrdersPage />);
    expect(screen.getByText('Loading orders...')).toBeInTheDocument();
  });

  it('shows empty state when no orders', async () => {
    setupAuthMock({ orders: [] });

    renderWithProviders(<SellerOrdersPage />);
    await waitFor(() => {
      expect(
        screen.getByText(/no orders for your products yet/i)
      ).toBeInTheDocument();
    });

    expect(screen.getByText(/My Store Orders/i)).toBeInTheDocument();
  });

  it('shows orders list when orders are loaded', async () => {
    setupAuthMock();

    renderWithProviders(<SellerOrdersPage />);
    await waitFor(() => {
      expect(screen.getByText(/Order #101/i)).toBeInTheDocument();
    });

    expect(screen.getByText(/Order #102/i)).toBeInTheDocument();
  });

  it('shows order details when an order row is clicked', async () => {
    setupAuthMock();

    renderWithProviders(<SellerOrdersPage />);
    await waitFor(() => {
      expect(screen.getByText(/Order #101/i)).toBeInTheDocument();
    });

    fireEvent.click(screen.getByText(/Order #101/i));

    await waitFor(() => {
      expect(screen.getByText(/Alice Smith/i) || screen.getByText(/Widget A/i)).toBeInTheDocument();
    });
  });
});
