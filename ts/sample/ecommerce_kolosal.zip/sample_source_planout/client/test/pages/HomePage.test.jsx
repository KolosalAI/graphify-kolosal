import { describe, it, expect, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { CartProvider } from '../../src/context/CartContext';
import { AuthProvider } from '../../src/context/AuthContext';
import HomePage from '../../src/pages/HomePage';

function renderHome() {
  localStorage.getItem.mockReturnValue(null);
  return render(
    <MemoryRouter initialEntries={['/']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/product/:slug" element={<div>Product</div>} />
            <Route path="/search" element={<div>Search</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('HomePage', () => {
  beforeEach(() => {
    localStorage.getItem.mockReturnValue(null);
    // Return empty arrays for ALL fetch calls so sub-components render gracefully
    global.fetch.mockResolvedValue({ ok: true, json: async () => [] });
  });

  it('renders without crashing', async () => {
    renderHome();
    // If the component renders at all, this test passes
    await waitFor(() => {
      expect(document.body).toBeTruthy();
    });
  });

  it('renders the category filter dropdown', async () => {
    renderHome();

    await waitFor(() => {
      expect(screen.getByRole('option', { name: /All Categories/i })).toBeInTheDocument();
    });
  });

  it('renders the sort dropdown with default option', async () => {
    renderHome();

    await waitFor(() => {
      expect(screen.getByRole('option', { name: /Name A/i })).toBeInTheDocument();
    });
  });

  it('renders the In Stock filter checkbox', async () => {
    renderHome();

    await waitFor(() => {
      expect(screen.getByRole('checkbox')).toBeInTheDocument();
      expect(screen.getByText(/In Stock/i)).toBeInTheDocument();
    });
  });

  it('shows empty state with no products found when API returns empty list', async () => {
    // products API returns {products: [], pages: 1}
    global.fetch.mockImplementation(url => {
      if (url.includes('/api/products'))
        return Promise.resolve({ ok: true, json: async () => ({ products: [], pages: 1 }) });
      return Promise.resolve({ ok: true, json: async () => [] });
    });

    renderHome();

    await waitFor(() => {
      expect(screen.getByText(/No products found/i)).toBeInTheDocument();
    });
  });

  it('renders product cards when products are returned', async () => {
    const mockProducts = {
      products: [
        {
          id: 1,
          name: 'Cool Gadget',
          slug: 'cool-gadget',
          price: 29.99,
          image_url: '/img.jpg',
          category_name: 'Electronics',
          stock: 5,
          avg_rating: 4.2,
          review_count: 10,
          badge: null,
        },
      ],
      pages: 1,
    };

    global.fetch.mockImplementation(url => {
      if (url.includes('/api/products'))
        return Promise.resolve({ ok: true, json: async () => mockProducts });
      return Promise.resolve({ ok: true, json: async () => [] });
    });

    renderHome();

    await waitFor(() => {
      expect(screen.getByText('Cool Gadget')).toBeInTheDocument();
    });
  });

  it('renders gracefully when all APIs return empty or error responses', async () => {
    // The beforeEach default (ok: true, json: () => []) handles this, but here we
    // also test mixed ok:false responses, as long as json() returns safe values.
    global.fetch.mockImplementation(url => {
      if (url.includes('/api/products'))
        return Promise.resolve({ ok: false, json: async () => ({ products: [], pages: 1 }) });
      return Promise.resolve({ ok: false, json: async () => [] });
    });

    expect(() => renderHome()).not.toThrow();

    await waitFor(() => {
      expect(screen.getByText(/No products found/i)).toBeInTheDocument();
    });
  });

  it('renders price filter inputs', async () => {
    renderHome();

    await waitFor(() => {
      expect(screen.getByPlaceholderText(/Min \$/i)).toBeInTheDocument();
      expect(screen.getByPlaceholderText(/Max \$/i)).toBeInTheDocument();
    });
  });

  it('renders category options when categories API returns data', async () => {
    const mockCategories = [
      { id: 1, name: 'Electronics', slug: 'electronics' },
      { id: 2, name: 'Books', slug: 'books' },
    ];

    global.fetch.mockImplementation(url => {
      if (url === '/api/categories')
        return Promise.resolve({ ok: true, json: async () => mockCategories });
      if (url.includes('/api/products'))
        return Promise.resolve({ ok: true, json: async () => ({ products: [], pages: 1 }) });
      return Promise.resolve({ ok: true, json: async () => [] });
    });

    renderHome();

    await waitFor(() => {
      expect(screen.getByRole('option', { name: 'Electronics' })).toBeInTheDocument();
      expect(screen.getByRole('option', { name: 'Books' })).toBeInTheDocument();
    });
  });

  it('personalized recommendation links navigate to /product/:slug not /products/:slug', async () => {
    const mockUser = { id: 1, name: 'Test User', email: 'test@test.com', role: 'user' };
    const mockRec = { id: 5, name: 'Rec Product', slug: 'rec-product', price: 19.99 };

    localStorage.getItem.mockImplementation(key => key === 'token' ? 'mock-token' : null);

    global.fetch.mockImplementation(url => {
      if (url === '/api/auth/me')
        return Promise.resolve({ ok: true, json: async () => mockUser });
      if (url === '/api/recommendations')
        return Promise.resolve({ ok: true, json: async () => [mockRec] });
      if (url.includes('/api/products'))
        return Promise.resolve({ ok: true, json: async () => ({ products: [], pagination: {} }) });
      return Promise.resolve({ ok: true, json: async () => [] });
    });

    // Render directly (not via renderHome helper) to preserve our localStorage mock
    render(
      <MemoryRouter initialEntries={['/']}>
        <AuthProvider>
          <CartProvider>
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/product/:slug" element={<div>Product</div>} />
            </Routes>
          </CartProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    await waitFor(() => {
      expect(screen.getByText('Rec Product')).toBeInTheDocument();
    });

    const link = screen.getByText('Rec Product').closest('a');
    expect(link).toHaveAttribute('href', '/product/rec-product');
  });
});
