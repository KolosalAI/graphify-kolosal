import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import { AuthContext } from '../../src/context/AuthContext';
import { useAuth } from '../../src/context/AuthContext';

// Mirror of the SellerRoute guard we will put in App.jsx
function SellerRoute({ children }) {
  const { user, isSeller, isAdmin, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (!isSeller && !isAdmin) return <Navigate to="/seller/apply" replace />;
  return children;
}

function renderWithAuth(authValues, initialPath = '/seller/dashboard') {
  return render(
    <MemoryRouter initialEntries={[initialPath]}>
      <AuthContext.Provider value={authValues}>
        <Routes>
          <Route path="/seller/dashboard" element={
            <SellerRoute><div>Seller Dashboard</div></SellerRoute>
          } />
          <Route path="/login" element={<div>Login Page</div>} />
          <Route path="/seller/apply" element={<div>Apply As Seller</div>} />
        </Routes>
      </AuthContext.Provider>
    </MemoryRouter>
  );
}

function makeAuthContext(overrides = {}) {
  return {
    user: null,
    token: null,
    loading: false,
    isSeller: false,
    isAdmin: false,
    login: () => {},
    register: () => {},
    logout: () => {},
    authFetch: () => {},
    ...overrides,
  };
}

describe('SellerRoute guard', () => {
  it('redirects unauthenticated users to /login', () => {
    renderWithAuth(makeAuthContext({ user: null }));
    expect(screen.getByText('Login Page')).toBeInTheDocument();
  });

  it('redirects logged-in non-sellers to /seller/apply', () => {
    renderWithAuth(makeAuthContext({
      user: { id: 1, name: 'Regular User', role: 'user' },
      isSeller: false,
      isAdmin: false,
    }));
    expect(screen.getByText('Apply As Seller')).toBeInTheDocument();
  });

  it('allows approved sellers to access seller pages', () => {
    renderWithAuth(makeAuthContext({
      user: { id: 2, name: 'Approved Seller', role: 'seller' },
      isSeller: true,
      isAdmin: false,
    }));
    expect(screen.getByText('Seller Dashboard')).toBeInTheDocument();
  });

  it('allows admins to access seller pages', () => {
    renderWithAuth(makeAuthContext({
      user: { id: 3, name: 'Admin', role: 'admin' },
      isSeller: false,
      isAdmin: true,
    }));
    expect(screen.getByText('Seller Dashboard')).toBeInTheDocument();
  });
});
