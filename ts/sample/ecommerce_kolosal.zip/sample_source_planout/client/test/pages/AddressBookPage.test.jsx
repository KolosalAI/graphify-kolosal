import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import AddressBookPage from '../../src/pages/AddressBookPage';

const mockAddresses = [
  { id: 1, full_name: 'John Smith', line1: '123 Main St', line2: '', city: 'Springfield', state: 'IL', postal_code: '62701', country: 'US', phone: '555-1234', is_default: true },
  { id: 2, full_name: 'Jane Doe', line1: '456 Oak Ave', line2: 'Apt 2', city: 'Chicago', state: 'IL', postal_code: '60601', country: 'US', phone: '', is_default: false },
];

function renderAddressBook({ withAddresses = false } = {}) {
  localStorage.getItem.mockImplementation(key => key === 'token' ? 'fake-token' : null);

  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Test User', email: 'test@example.com', role: 'user' }) });
    if (url.includes('/api/addresses')) return Promise.resolve({ ok: true, json: async () => (withAddresses ? mockAddresses : []) });
    return Promise.resolve({ ok: true, json: async () => ({}) });
  });

  return render(
    <MemoryRouter initialEntries={['/address-book']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/address-book" element={<AddressBookPage />} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('AddressBookPage', () => {
  it('shows loading state initially', () => {
    localStorage.getItem.mockImplementation(key => key === 'token' ? 'fake-token' : null);
    global.fetch.mockImplementation((url) => {
      if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: async () => ({ id: 1, name: 'Test User', email: 'test@example.com', role: 'user' }) });
      return new Promise(() => {});
    });

    render(
      <MemoryRouter initialEntries={['/address-book']}>
        <AuthProvider>
          <CartProvider>
            <Routes>
              <Route path="/address-book" element={<AddressBookPage />} />
            </Routes>
          </CartProvider>
        </AuthProvider>
      </MemoryRouter>
    );

    expect(screen.getByText('Loading addresses...')).toBeInTheDocument();
  });

  it('shows empty state when no addresses', async () => {
    renderAddressBook({ withAddresses: false });
    await waitFor(() => expect(screen.getByText('Address Book')).toBeInTheDocument());
    expect(screen.getByText(/No saved addresses/)).toBeInTheDocument();
  });

  it('shows address list when addresses exist', async () => {
    renderAddressBook({ withAddresses: true });
    await waitFor(() => expect(screen.getByText('John Smith')).toBeInTheDocument());
    expect(screen.getByText('Jane Doe')).toBeInTheDocument();
  });

  it('shows add address form when button is clicked', async () => {
    renderAddressBook({ withAddresses: false });
    await waitFor(() => expect(screen.getByText('+ Add Address')).toBeInTheDocument());
    fireEvent.click(screen.getByText('+ Add Address'));
    expect(screen.getByText('Full Name *')).toBeInTheDocument();
    expect(screen.getByText('Address Line 1 *')).toBeInTheDocument();
    expect(screen.getByText('City *')).toBeInTheDocument();
    expect(screen.getByText('State *')).toBeInTheDocument();
    expect(screen.getByText('Postal Code *')).toBeInTheDocument();
  });
});
