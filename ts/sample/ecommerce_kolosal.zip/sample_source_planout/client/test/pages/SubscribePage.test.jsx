import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SubscribePage from '../../src/pages/SubscribePage';

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

const mockPlans = [
  {
    billing_cycle: 'monthly',
    name: 'Monthly',
    price: 9.99,
    features: ['Free shipping'],
  },
  {
    billing_cycle: 'annual',
    name: 'Annual',
    price: 79.99,
    features: ['All monthly benefits'],
  },
];

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

describe('SubscribePage', () => {
  it('renders the Prime Membership page without authentication', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/subscriptions/plans') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockPlans) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SubscribePage />, { route: '/subscribe', path: '/subscribe' });

    expect(screen.getByRole('heading', { level: 1 })).toBeInTheDocument();
    expect(screen.getByRole('heading', { name: /Prime Membership/i })).toBeInTheDocument();
  });

  it('shows subscription plan features', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/subscriptions/plans') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockPlans) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SubscribePage />, { route: '/subscribe', path: '/subscribe' });

    expect(screen.getByText('Free Fast Shipping')).toBeInTheDocument();
    expect(screen.getByText('Exclusive Deals')).toBeInTheDocument();
    expect(screen.getByText('Bonus Loyalty Points')).toBeInTheDocument();
    expect(screen.getByText('Priority Support')).toBeInTheDocument();
  });

  it('shows plan selection cards when plans are loaded', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/subscriptions/plans') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockPlans) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SubscribePage />, { route: '/subscribe', path: '/subscribe' });

    await waitFor(() =>
      expect(screen.getByText('Choose Your Plan')).toBeInTheDocument()
    );
    expect(screen.getByText('Monthly')).toBeInTheDocument();
    expect(screen.getByText('Annual')).toBeInTheDocument();
  });

  it('shows "Log in to subscribe" button when not authenticated', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/subscriptions/plans') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockPlans) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SubscribePage />, { route: '/subscribe', path: '/subscribe' });

    await waitFor(() =>
      expect(screen.getByRole('button', { name: /Log in to subscribe/i })).toBeInTheDocument()
    );
  });
});
