import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import QAPage from '../../src/pages/QAPage';

const mockUser = { id: 1, name: 'Alice', email: 'alice@test.com', role: 'customer' };
const mockAdmin = { id: 2, name: 'Admin', email: 'admin@test.com', role: 'admin' };

const mockMyQuestions = [
  {
    id: 1, product_id: 10, user_id: 1,
    question: 'Is this waterproof?',
    answer: 'Yes, fully waterproof.',
    asker_name: 'Alice', answerer_name: 'Support',
    product_name: 'Blue Widget', product_slug: 'blue-widget',
    helpful_count: 3, report_count: 0,
    created_at: new Date().toISOString(),
  },
  {
    id: 2, product_id: 10, user_id: 1,
    question: 'Does it come in red?',
    answer: null,
    asker_name: 'Alice', answerer_name: null,
    product_name: 'Blue Widget', product_slug: 'blue-widget',
    helpful_count: 0, report_count: 0,
    created_at: new Date().toISOString(),
  },
];

const mockBrowseQuestions = {
  questions: [
    {
      id: 3, product_id: 10, user_id: 99,  // different from mockAdmin.id=2
      question: 'What is the warranty period?',
      answer: '2 years.',
      asker_name: 'Bob', answerer_name: 'Admin',
      product_name: 'Blue Widget', product_slug: 'blue-widget',
      helpful_count: 1, report_count: 0,
      created_at: new Date().toISOString(),
    },
  ],
  total: 1, page: 1, limit: 50,
};

function renderWithUser(user = mockUser) {
  localStorage.setItem('token', 'mock-token');
  global.fetch.mockImplementation((url) => {
    if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: () => Promise.resolve(user) });
    if (url.includes('/api/qa/my')) return Promise.resolve({ ok: true, json: () => Promise.resolve(mockMyQuestions) });
    if (url.includes('/api/qa')) return Promise.resolve({ ok: true, json: () => Promise.resolve(mockBrowseQuestions) });
    return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
  });

  return render(
    <MemoryRouter initialEntries={['/qa']}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path="/qa" element={<QAPage />} />
            <Route path="/login" element={<div>Login Page</div>} />
            <Route path="/product/:slug" element={<div>Product Page</div>} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('QAPage', () => {
  describe('unauthenticated', () => {
    beforeEach(() => {
      global.fetch.mockImplementation((url) => {
        if (url.includes('/api/auth/me')) return Promise.resolve({ ok: false, json: () => Promise.resolve({}) });
        return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
      });
    });

    it('shows sign-in prompt when not logged in', async () => {
      render(
        <MemoryRouter initialEntries={['/qa']}>
          <AuthProvider>
            <CartProvider>
              <Routes>
                <Route path="/qa" element={<QAPage />} />
                <Route path="/login" element={<div>Login Page</div>} />
              </Routes>
            </CartProvider>
          </AuthProvider>
        </MemoryRouter>
      );
      await waitFor(() => {
        expect(screen.getByText(/sign in/i)).toBeInTheDocument();
      });
    });
  });

  describe('authenticated customer', () => {
    it('renders page heading', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getByRole('heading', { level: 1 })).toHaveTextContent(/Questions.*Answers/i);
      });
    });

    it('loads and displays My Questions tab by default', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getByText(/Is this waterproof/i)).toBeInTheDocument();
        expect(screen.getByText(/Does it come in red/i)).toBeInTheDocument();
      });
    });

    it('shows answered question with answer text', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getByText(/Yes, fully waterproof/i)).toBeInTheDocument();
      });
    });

    it('shows "Awaiting answer" for unanswered questions', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getByText(/Awaiting answer/i)).toBeInTheDocument();
      });
    });

    it('shows My Questions tab button', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getByText(/My Questions/i)).toBeInTheDocument();
      });
    });

    it('does not show Browse All or Unanswered tabs for regular customers', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.queryByText(/Browse All/i)).not.toBeInTheDocument();
        expect(screen.queryByText(/Unanswered/i)).not.toBeInTheDocument();
      });
    });

    it('shows product name links', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getAllByText(/Blue Widget/).length).toBeGreaterThanOrEqual(1);
      });
    });

    it('shows helpful count buttons', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        const helpfulBtns = screen.getAllByText(/👍/);
        expect(helpfulBtns.length).toBeGreaterThanOrEqual(1);
      });
    });

    it('shows delete button for own questions', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(screen.getAllByText(/🗑 Delete/).length).toBeGreaterThanOrEqual(1);
      });
    });

    it('calls /api/qa/my on My Questions tab', async () => {
      renderWithUser(mockUser);
      await waitFor(() => {
        expect(global.fetch).toHaveBeenCalledWith(
          expect.stringContaining('/api/qa/my'),
          expect.anything()
        );
      });
    });
  });

  describe('authenticated admin', () => {
    it('shows all three tabs for admin', async () => {
      renderWithUser(mockAdmin);
      await waitFor(() => {
        expect(screen.getByText(/My Questions/i)).toBeInTheDocument();
        expect(screen.getByText(/Browse All/i)).toBeInTheDocument();
        expect(screen.getByText(/Unanswered/i)).toBeInTheDocument();
      });
    });

    it('shows search bar for admin', async () => {
      renderWithUser(mockAdmin);
      await waitFor(() => {
        expect(screen.getByPlaceholderText(/Search questions/i)).toBeInTheDocument();
      });
    });

    it('switches to Browse All tab when clicked', async () => {
      renderWithUser(mockAdmin);
      await waitFor(() => screen.getByText(/Browse All/i));
      fireEvent.click(screen.getByText(/Browse All/i));
      await waitFor(() => {
        expect(global.fetch).toHaveBeenCalledWith(
          expect.stringContaining('/api/qa?'),
          expect.anything()
        );
      });
    });

    it('switches to Unanswered tab when clicked', async () => {
      renderWithUser(mockAdmin);
      await waitFor(() => screen.getByText(/Unanswered/i));
      fireEvent.click(screen.getByText(/Unanswered/i));
      await waitFor(() => {
        expect(global.fetch).toHaveBeenCalledWith(
          expect.stringContaining('status=unanswered'),
          expect.anything()
        );
      });
    });

    it('submits search query', async () => {
      renderWithUser(mockAdmin);
      await waitFor(() => screen.getByPlaceholderText(/Search questions/i));
      fireEvent.change(screen.getByPlaceholderText(/Search questions/i), {
        target: { value: 'warranty' },
      });
      fireEvent.submit(screen.getByPlaceholderText(/Search questions/i).closest('form'));
      await waitFor(() => {
        expect(global.fetch).toHaveBeenCalledWith(
          expect.stringContaining('search=warranty'),
          expect.anything()
        );
      });
    });
  });

  describe('empty state', () => {
    it('shows empty message when no questions', async () => {
      localStorage.setItem('token', 'mock-token');
      global.fetch.mockImplementation((url) => {
        if (url.includes('/api/auth/me')) return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
        if (url.includes('/api/qa/my')) return Promise.resolve({ ok: true, json: () => Promise.resolve([]) });
        return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
      });

      render(
        <MemoryRouter initialEntries={['/qa']}>
          <AuthProvider>
            <CartProvider>
              <Routes>
                <Route path="/qa" element={<QAPage />} />
              </Routes>
            </CartProvider>
          </AuthProvider>
        </MemoryRouter>
      );

      await waitFor(() => {
        expect(screen.getByText(/haven't asked any questions/i)).toBeInTheDocument();
      });
    });
  });

  describe('report flow', () => {
    it('shows Report button for questions by other users (admin browsing)', async () => {
      renderWithUser(mockAdmin);
      await waitFor(() => screen.getByText(/Browse All/i));
      fireEvent.click(screen.getByText(/Browse All/i));
      await waitFor(() => {
        expect(screen.getByText(/🚩 Report/)).toBeInTheDocument();
      });
    });
  });
});
