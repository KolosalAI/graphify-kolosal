import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SellerStorefrontPage from '../../src/pages/SellerStorefrontPage';

const mockSeller = {
  id: 42,
  store_name: 'Awesome Store',
  description: 'The best store around.',
  user_id: 5,
};

const mockProducts = [
  { id: 1, name: 'Cool Product', price: 24.99, stock: 7, seller_id: 42 },
  { id: 2, name: 'Another Item', price: 9.99, stock: 15, seller_id: 42 },
];

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

beforeEach(() => {
  vi.clearAllMocks();
  localStorage.getItem.mockReturnValue(null);
  global.fetch.mockResolvedValue({
    ok: true,
    json: () => Promise.resolve({}),
  });
});

describe('SellerStorefrontPage', () => {
  it('shows loading state', () => {
    global.fetch.mockImplementation(() => new Promise(() => {})); // never resolves

    renderWithProviders(<SellerStorefrontPage />, {
      route: '/seller/42',
      path: '/seller/:id',
    });

    expect(screen.getByText('Loading storefront...')).toBeInTheDocument();
  });

  it('shows seller info and store name after fetch', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/sellers/42') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockSeller),
        });
      }
      if (url === '/api/sellers/42/products') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve([]),
        });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SellerStorefrontPage />, {
      route: '/seller/42',
      path: '/seller/:id',
    });

    await waitFor(() => {
      expect(screen.getByText('Awesome Store')).toBeInTheDocument();
    });

    expect(screen.getByText(/The best store around/i)).toBeInTheDocument();
  });

  it('shows seller products when loaded', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/sellers/42') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockSeller),
        });
      }
      if (url === '/api/sellers/42/products') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve(mockProducts),
        });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SellerStorefrontPage />, {
      route: '/seller/42',
      path: '/seller/:id',
    });

    await waitFor(() => {
      expect(screen.getByText('Cool Product')).toBeInTheDocument();
    });

    expect(screen.getByText('Another Item')).toBeInTheDocument();
    expect(screen.getByText(/Products from Awesome Store/i)).toBeInTheDocument();
  });

  it('shows seller not found when fetch fails or returns error', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/sellers/42') {
        return Promise.resolve({
          ok: false,
          json: () => Promise.resolve({ error: 'Not found' }),
        });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve([]) });
    });

    renderWithProviders(<SellerStorefrontPage />, {
      route: '/seller/42',
      path: '/seller/:id',
    });

    await waitFor(() => {
      expect(screen.getByText(/Seller not found/i)).toBeInTheDocument();
    });
  });
});
