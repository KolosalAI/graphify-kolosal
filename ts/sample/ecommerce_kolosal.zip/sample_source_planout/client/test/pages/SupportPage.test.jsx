import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import SupportPage from '../../src/pages/SupportPage';

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

const mockUser = { id: 1, name: 'Test User', email: 'test@example.com', role: 'user' };

beforeEach(() => {
  localStorage.getItem.mockImplementation((key) =>
    key === 'token' ? 'fake-token' : null
  );
});

describe('SupportPage', () => {
  it('shows loading state initially', () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
      }
      // /api/support never resolves — keeps loading=true
      return new Promise(() => {});
    });

    renderWithProviders(<SupportPage />, { route: '/support', path: '/support' });

    expect(screen.getByText('Loading support tickets...')).toBeInTheDocument();
  });

  it('shows empty state when no tickets', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
      }
      if (url === '/api/support') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve([]) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SupportPage />, { route: '/support', path: '/support' });

    await waitFor(() =>
      expect(screen.getByText('No support tickets yet!')).toBeInTheDocument()
    );
  });

  it('shows ticket list when tickets are loaded', async () => {
    const tickets = [
      {
        id: 42,
        subject: 'My Order Issue',
        status: 'open',
        created_at: '2024-01-15T10:00:00Z',
        messages: [],
      },
      {
        id: 43,
        subject: 'Refund Request',
        status: 'in_progress',
        created_at: '2024-01-16T12:00:00Z',
        messages: [{ id: 1, body: 'Hello', is_admin: false, sender_name: 'Test User', created_at: '2024-01-16T12:00:00Z' }],
      },
    ];

    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
      }
      if (url === '/api/support') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(tickets) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SupportPage />, { route: '/support', path: '/support' });

    await waitFor(() =>
      expect(screen.getByText('My Order Issue')).toBeInTheDocument()
    );
    expect(screen.getByText(/Ticket #42/)).toBeInTheDocument();
    expect(screen.getByText('Refund Request')).toBeInTheDocument();
    expect(screen.getByText(/Ticket #43/)).toBeInTheDocument();
  });

  it('shows new ticket form when the button is clicked', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/me') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(mockUser) });
      }
      if (url === '/api/support') {
        return Promise.resolve({ ok: true, json: () => Promise.resolve([]) });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(<SupportPage />, { route: '/support', path: '/support' });

    await waitFor(() =>
      expect(screen.getByText('+ New Ticket')).toBeInTheDocument()
    );

    fireEvent.click(screen.getByText('+ New Ticket'));

    expect(screen.getByPlaceholderText('Describe your issue briefly')).toBeInTheDocument();
    expect(screen.getByPlaceholderText('Provide as much detail as possible...')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Submit Ticket/i })).toBeInTheDocument();
  });
});
