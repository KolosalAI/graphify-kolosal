import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import ResetPasswordPage from '../../src/pages/ResetPasswordPage';

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

describe('ResetPasswordPage', () => {
  it('shows the reset password form with New Password and Confirm New Password fields', () => {
    renderWithProviders(
      <ResetPasswordPage />,
      { route: '/reset-password?token=abc123', path: '/reset-password' }
    );

    expect(
      screen.getByRole('heading', { name: /Reset Password/i })
    ).toBeInTheDocument();
    expect(screen.getByLabelText(/^New Password$/i)).toBeInTheDocument();
    expect(screen.getByLabelText(/Confirm New Password/i)).toBeInTheDocument();
    expect(
      screen.getByRole('button', { name: /Reset Password/i })
    ).toBeInTheDocument();
  });

  it('shows an error when no token is present in the URL', () => {
    renderWithProviders(
      <ResetPasswordPage />,
      { route: '/reset-password', path: '/reset-password' }
    );

    expect(screen.getByText(/Missing reset token/i)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Reset Password/i })).toBeDisabled();
  });

  it('shows an error when passwords do not match', async () => {
    renderWithProviders(
      <ResetPasswordPage />,
      { route: '/reset-password?token=abc123', path: '/reset-password' }
    );

    fireEvent.change(screen.getByLabelText(/^New Password$/i), {
      target: { value: 'password123' },
    });
    fireEvent.change(screen.getByLabelText(/Confirm New Password/i), {
      target: { value: 'differentpassword' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Reset Password/i }));

    await waitFor(() =>
      expect(screen.getByText('Passwords do not match.')).toBeInTheDocument()
    );
  });

  it('shows success heading after a valid form submission', async () => {
    global.fetch.mockImplementation((url) => {
      if (url === '/api/auth/reset-password') {
        return Promise.resolve({
          ok: true,
          json: () => Promise.resolve({ message: 'Password reset successfully.' }),
        });
      }
      return Promise.resolve({ ok: true, json: () => Promise.resolve({}) });
    });

    renderWithProviders(
      <ResetPasswordPage />,
      { route: '/reset-password?token=abc123', path: '/reset-password' }
    );

    fireEvent.change(screen.getByLabelText(/^New Password$/i), {
      target: { value: 'newpassword123' },
    });
    fireEvent.change(screen.getByLabelText(/Confirm New Password/i), {
      target: { value: 'newpassword123' },
    });
    fireEvent.click(screen.getByRole('button', { name: /Reset Password/i }));

    await waitFor(() =>
      expect(screen.getByRole('heading', { name: /Password Reset/i })).toBeInTheDocument()
    );
    expect(
      screen.getByText(/Your password has been reset successfully/i)
    ).toBeInTheDocument();
  });
});
