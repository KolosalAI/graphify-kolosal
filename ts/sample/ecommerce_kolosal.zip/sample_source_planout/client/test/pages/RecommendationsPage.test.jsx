import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '../../src/context/AuthContext';
import { CartProvider } from '../../src/context/CartContext';
import RecommendationsPage from '../../src/pages/RecommendationsPage';

function renderWithProviders(ui, { route = '/', path = '/' } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        <CartProvider>
          <Routes>
            <Route path={path} element={ui} />
          </Routes>
        </CartProvider>
      </AuthProvider>
    </MemoryRouter>
  );
}

const mockProducts = [
  { id: 1, name: 'Wireless Headphones', price: 49.99, image_url: null },
  { id: 2, name: 'Mechanical Keyboard', price: 89.99, image_url: null },
];

describe('RecommendationsPage', () => {
  it('shows loading state initially', () => {
    // Return a never-resolving promise so loading state persists
    global.fetch.mockImplementation(() => new Promise(() => {}));

    renderWithProviders(
      <RecommendationsPage />,
      { route: '/recommendations', path: '/recommendations' }
    );

    expect(screen.getByText('Loading recommendations...')).toBeInTheDocument();
  });

  it('shows empty state when there are no recommendations', async () => {
    global.fetch.mockImplementation(() =>
      Promise.resolve({ ok: true, json: () => Promise.resolve([]) })
    );

    renderWithProviders(
      <RecommendationsPage />,
      { route: '/recommendations', path: '/recommendations' }
    );

    await waitFor(() =>
      expect(
        screen.getByText('Start browsing products to get personalized recommendations!')
      ).toBeInTheDocument()
    );
    expect(screen.getByRole('link', { name: /Browse Products/i })).toBeInTheDocument();
  });

  it('shows product cards when recommendations are loaded', async () => {
    global.fetch.mockImplementation(() =>
      Promise.resolve({ ok: true, json: () => Promise.resolve(mockProducts) })
    );

    renderWithProviders(
      <RecommendationsPage />,
      { route: '/recommendations', path: '/recommendations' }
    );

    await waitFor(() =>
      expect(screen.getByText('Wireless Headphones')).toBeInTheDocument()
    );
    expect(screen.getByText('Mechanical Keyboard')).toBeInTheDocument();
    expect(screen.getByText('$49.99')).toBeInTheDocument();
    expect(screen.getByText('$89.99')).toBeInTheDocument();
  });

  it('renders the "Your Recommendations" heading', async () => {
    global.fetch.mockImplementation(() =>
      Promise.resolve({ ok: true, json: () => Promise.resolve([]) })
    );

    renderWithProviders(
      <RecommendationsPage />,
      { route: '/recommendations', path: '/recommendations' }
    );

    await waitFor(() =>
      expect(
        screen.getByRole('heading', { name: /Your Recommendations/i })
      ).toBeInTheDocument()
    );
  });
});
