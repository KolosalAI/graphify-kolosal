# Client

React + Vite frontend for the Kolosal E-Commerce Platform.

> **Start from the project root** using `npm run dev` — do not run this client in isolation unless you have the backend already running on port 3001.

## Scripts

Run from the **project root** (`../`):

```bash
npm run dev          # Start frontend + backend together
npm run build        # Production build → client/dist/
```

Or run from this directory if the backend is already up:

```bash
npm run dev          # Start Vite dev server only
npm run build        # Build for production
npm run test         # Run unit tests with Vitest
```

## Structure

```
src/
├── main.jsx          # React entry + context providers
├── App.jsx           # Router & route definitions
├── components/
│   ├── atoms/        # Button, Badge, Input, StarRating…
│   ├── molecules/    # FormField, PriceDisplay…
│   └── organisms/    # Header, ProductCard, SearchBar…
├── pages/            # One component per route
├── hooks/            # useProducts, useCategories, useCart…
├── services/         # API call functions
├── context/          # AuthContext, CartContext
└── design-system/    # CSS custom properties & base styles
```

## Path Aliases

| Alias         | Resolves to         |
|---------------|---------------------|
| `@components` | `src/components`    |
| `@pages`      | `src/pages`         |
| `@hooks`      | `src/hooks`         |
| `@services`   | `src/services`      |
| `@context`    | `src/context`       |
