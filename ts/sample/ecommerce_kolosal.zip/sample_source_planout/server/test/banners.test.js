import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let userToken;
let bannerId;

beforeAll(async () => {
  // Register a regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Banner User',
    email: 'banneruser@test.com',
    password: 'password123',
  });
  userToken = userRes.body.token;

  // Register admin user, promote to admin, re-login for admin token
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Banner Admin',
    email: 'banneradmin@test.com',
    password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminId);
  const loginRes = await request(app).post('/api/auth/login').send({
    email: 'banneradmin@test.com',
    password: 'password123',
  });
  adminToken = loginRes.body.token;

  // Seed one inactive banner to verify admin-only listing
  db.prepare(`
    INSERT INTO banners (title, subtitle, image_url, active, sort_order)
    VALUES ('Inactive Banner', NULL, 'https://example.com/inactive.jpg', 0, 99)
  `).run();
});

describe('Banners API', () => {
  describe('GET /api/banners — public', () => {
    it('returns an array of active banners', async () => {
      const res = await request(app).get('/api/banners');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('does not include inactive banners', async () => {
      const res = await request(app).get('/api/banners');
      expect(res.status).toBe(200);
      res.body.forEach(b => expect(b.active).toBe(1));
    });
  });

  describe('GET /api/banners/admin — admin only', () => {
    it('returns all banners including inactive for admin', async () => {
      const res = await request(app)
        .get('/api/banners/admin')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(b => b.active === 0)).toBe(true);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).get('/api/banners/admin');
      expect(res.status).toBe(401);
    });

    it('rejects non-admin user with 403', async () => {
      const res = await request(app)
        .get('/api/banners/admin')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });

  describe('POST /api/banners — admin only', () => {
    it('creates a banner with required fields and returns 201', async () => {
      const res = await request(app)
        .post('/api/banners')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          title: 'Summer Sale',
          image_url: 'https://example.com/summer.jpg',
          subtitle: 'Up to 50% off',
          link: '/sale',
          bg_color: '#ff6600',
          sort_order: 1,
          active: true,
        });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('id');
      expect(res.body.title).toBe('Summer Sale');
      expect(res.body.image_url).toBe('https://example.com/summer.jpg');
      bannerId = res.body.id;
    });

    it('returns 400 when title is missing', async () => {
      const res = await request(app)
        .post('/api/banners')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ image_url: 'https://example.com/img.jpg' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/title/i);
    });

    it('returns 400 when image_url is missing', async () => {
      const res = await request(app)
        .post('/api/banners')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ title: 'No Image Banner' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/image_url/i);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .post('/api/banners')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ title: 'Hack', image_url: 'https://example.com/x.jpg' });
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app)
        .post('/api/banners')
        .send({ title: 'No Auth', image_url: 'https://example.com/x.jpg' });
      expect(res.status).toBe(401);
    });
  });

  describe('PUT /api/banners/:id — admin only', () => {
    it('updates an existing banner and returns 200', async () => {
      const res = await request(app)
        .put(`/api/banners/${bannerId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          title: 'Updated Sale',
          image_url: 'https://example.com/updated.jpg',
          bg_color: '#ff0000',
          sort_order: 2,
          active: true,
        });
      expect(res.status).toBe(200);
      expect(res.body.title).toBe('Updated Sale');
      expect(res.body.id).toBe(bannerId);
    });

    it('returns 404 for nonexistent banner', async () => {
      const res = await request(app)
        .put('/api/banners/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ title: 'Ghost', image_url: 'https://example.com/ghost.jpg', bg_color: '#000', sort_order: 0, active: true });
      expect(res.status).toBe(404);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .put(`/api/banners/${bannerId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ title: 'Hack', image_url: 'https://example.com/x.jpg', bg_color: '#000', sort_order: 0, active: true });
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app)
        .put(`/api/banners/${bannerId}`)
        .send({ title: 'No Auth', image_url: 'https://example.com/x.jpg', bg_color: '#000', sort_order: 0, active: true });
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/banners/:id/toggle — admin only', () => {
    it('toggles banner active status', async () => {
      // Get current state first
      const before = await request(app)
        .get('/api/banners/admin')
        .set('Authorization', `Bearer ${adminToken}`);
      const current = before.body.find(b => b.id === bannerId);
      const originalActive = current.active;

      const res = await request(app)
        .patch(`/api/banners/${bannerId}/toggle`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body.id).toBe(bannerId);
      expect(res.body.active).toBe(!originalActive);
    });

    it('returns 404 for nonexistent banner', async () => {
      const res = await request(app)
        .patch('/api/banners/999999/toggle')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .patch(`/api/banners/${bannerId}/toggle`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).patch(`/api/banners/${bannerId}/toggle`);
      expect(res.status).toBe(401);
    });
  });

  describe('DELETE /api/banners/:id — admin only', () => {
    it('deletes an existing banner and returns 200', async () => {
      // Create a banner to delete
      const create = await request(app)
        .post('/api/banners')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ title: 'Disposable', image_url: 'https://example.com/del.jpg' });
      const deleteId = create.body.id;

      const res = await request(app)
        .delete(`/api/banners/${deleteId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body.message).toMatch(/deleted/i);
    });

    it('returns 404 for nonexistent banner', async () => {
      const res = await request(app)
        .delete('/api/banners/999999')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .delete(`/api/banners/${bannerId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).delete(`/api/banners/${bannerId}`);
      expect(res.status).toBe(401);
    });
  });
});
