import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let user1Token;
let user1Id;
let user2Token;
let user2Id;
let user3Token;
let user1ReferralCode;
let user3ReferralCode;

beforeAll(async () => {
  // Register user1
  const res1 = await request(app).post('/api/auth/register').send({
    name: 'Loyalty User1',
    email: 'loyaltyuser1@test.com',
    password: 'password123',
  });
  user1Token = res1.body.token;
  user1Id = res1.body.user.id;

  // Register user2
  const res2 = await request(app).post('/api/auth/register').send({
    name: 'Loyalty User2',
    email: 'loyaltyuser2@test.com',
    password: 'password123',
  });
  user2Token = res2.body.token;
  user2Id = res2.body.user.id;

  // Register user3 — used only to provide a second pending referral code
  const res3 = await request(app).post('/api/auth/register').send({
    name: 'Loyalty User3',
    email: 'loyaltyuser3@test.com',
    password: 'password123',
  });
  user3Token = res3.body.token;

  // Retrieve referral codes via the API (generates them if not yet created)
  const refRes1 = await request(app)
    .get('/api/loyalty/referral')
    .set('Authorization', `Bearer ${user1Token}`);
  user1ReferralCode = refRes1.body.referral_code;

  const refRes3 = await request(app)
    .get('/api/loyalty/referral')
    .set('Authorization', `Bearer ${user3Token}`);
  user3ReferralCode = refRes3.body.referral_code;
});

describe('Loyalty API', () => {
  describe('GET /api/loyalty — authenticated', () => {
    it('returns balance and history for authenticated user', async () => {
      const res = await request(app)
        .get('/api/loyalty')
        .set('Authorization', `Bearer ${user1Token}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('balance');
      expect(res.body).toHaveProperty('history');
      expect(typeof res.body.balance).toBe('number');
      expect(Array.isArray(res.body.history)).toBe(true);
    });

    it('returns 401 without authentication', async () => {
      const res = await request(app).get('/api/loyalty');
      expect(res.status).toBe(401);
    });

    it('returns 401 with an invalid token', async () => {
      const res = await request(app)
        .get('/api/loyalty')
        .set('Authorization', 'Bearer badtoken');
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/loyalty/balance — authenticated', () => {
    it('returns a numeric balance for authenticated user', async () => {
      const res = await request(app)
        .get('/api/loyalty/balance')
        .set('Authorization', `Bearer ${user1Token}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('balance');
      expect(typeof res.body.balance).toBe('number');
    });

    it('returns 0 balance for a brand-new user', async () => {
      const res = await request(app)
        .get('/api/loyalty/balance')
        .set('Authorization', `Bearer ${user2Token}`);
      expect(res.status).toBe(200);
      expect(res.body.balance).toBe(0);
    });

    it('returns 401 without authentication', async () => {
      const res = await request(app).get('/api/loyalty/balance');
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/loyalty/referral — authenticated', () => {
    it('returns referral_code and referrals array', async () => {
      const res = await request(app)
        .get('/api/loyalty/referral')
        .set('Authorization', `Bearer ${user1Token}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('referral_code');
      expect(res.body).toHaveProperty('referrals');
      expect(Array.isArray(res.body.referrals)).toBe(true);
      expect(typeof res.body.referral_code).toBe('string');
      expect(res.body.referral_code.length).toBeGreaterThan(0);
    });

    it('generates a referral code if user has none', async () => {
      // user2 hasn't fetched referral yet — code should be generated on first call
      const res = await request(app)
        .get('/api/loyalty/referral')
        .set('Authorization', `Bearer ${user2Token}`);
      expect(res.status).toBe(200);
      expect(res.body.referral_code).toBeTruthy();
    });

    it('returns the same referral code on repeated calls', async () => {
      const first = await request(app)
        .get('/api/loyalty/referral')
        .set('Authorization', `Bearer ${user1Token}`);
      const second = await request(app)
        .get('/api/loyalty/referral')
        .set('Authorization', `Bearer ${user1Token}`);
      expect(first.body.referral_code).toBe(second.body.referral_code);
    });

    it('returns 401 without authentication', async () => {
      const res = await request(app).get('/api/loyalty/referral');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/loyalty/use-referral — authenticated', () => {
    it('returns 400 when code is missing', async () => {
      const res = await request(app)
        .post('/api/loyalty/use-referral')
        .set('Authorization', `Bearer ${user2Token}`)
        .send({});
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/code/i);
    });

    it('returns 404 for an invalid or expired referral code', async () => {
      const res = await request(app)
        .post('/api/loyalty/use-referral')
        .set('Authorization', `Bearer ${user2Token}`)
        .send({ code: 'REF-INVALID-FAKE' });
      expect(res.status).toBe(404);
      expect(res.body.error).toMatch(/invalid|expired/i);
    });

    it('returns 400 when user tries to use their own referral code', async () => {
      const res = await request(app)
        .post('/api/loyalty/use-referral')
        .set('Authorization', `Bearer ${user1Token}`)
        .send({ code: user1ReferralCode });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/own/i);
    });

    it('successfully applies a valid referral code and awards 200 points', async () => {
      const res = await request(app)
        .post('/api/loyalty/use-referral')
        .set('Authorization', `Bearer ${user2Token}`)
        .send({ code: user1ReferralCode });
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.points_earned).toBe(200);
    });

    it('awards 200 points to the referrer (user1) as well', async () => {
      const res = await request(app)
        .get('/api/loyalty/balance')
        .set('Authorization', `Bearer ${user1Token}`);
      expect(res.status).toBe(200);
      expect(res.body.balance).toBeGreaterThanOrEqual(200);
    });

    it('awards 200 points to the referee (user2)', async () => {
      const res = await request(app)
        .get('/api/loyalty/balance')
        .set('Authorization', `Bearer ${user2Token}`);
      expect(res.status).toBe(200);
      expect(res.body.balance).toBe(200);
    });

    it('returns 400 when user has already used a referral code', async () => {
      // user2 already redeemed user1's code above; now try a different pending code (user3's)
      // The route checks referee_id first after finding a pending code → returns 400
      const res = await request(app)
        .post('/api/loyalty/use-referral')
        .set('Authorization', `Bearer ${user2Token}`)
        .send({ code: user3ReferralCode });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/already used/i);
    });

    it('returns 401 without authentication', async () => {
      const res = await request(app)
        .post('/api/loyalty/use-referral')
        .send({ code: user1ReferralCode });
      expect(res.status).toBe(401);
    });
  });
});
