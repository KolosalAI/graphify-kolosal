import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let productId;

beforeAll(async () => {
  // Authenticated user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Recs User', email: 'recsuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;

  // Seed a product (for also-bought / also-viewed endpoints)
  db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Recs Cat', 'recs-cat')").run();
  const catId = db.prepare("SELECT id FROM categories WHERE slug='recs-cat'").get()?.id;
  const prod = db.prepare(
    "INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run('Recs Product', 'recs-product', 'For recommendations', 15.00, 20, catId, 'https://example.com/rp.jpg');
  productId = prod.lastInsertRowid;
});

describe('Recommendations API', () => {
  describe('GET /api/recommendations', () => {
    it('returns an array of products when authenticated', async () => {
      const res = await request(app)
        .get('/api/recommendations')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('falls back to top-rated products when no viewing history', async () => {
      const res = await request(app)
        .get('/api/recommendations')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      // Should return at least the seeded product as fallback
      expect(res.body.length).toBeGreaterThanOrEqual(0);
    });

    it('returns 401 for unauthenticated requests', async () => {
      const res = await request(app).get('/api/recommendations');
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/recommendations/also-bought/:productId', () => {
    it('returns an array for a valid product (may be empty)', async () => {
      const res = await request(app).get(`/api/recommendations/also-bought/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('does not require authentication', async () => {
      const res = await request(app).get(`/api/recommendations/also-bought/${productId}`);
      expect(res.status).not.toBe(401);
    });

    it('falls back to related-by-category when no co-purchase data', async () => {
      const res = await request(app).get(`/api/recommendations/also-bought/${productId}`);
      expect(res.status).toBe(200);
      // Result is an array (possibly empty if no products in same category)
      expect(Array.isArray(res.body)).toBe(true);
    });
  });

  describe('GET /api/recommendations/also-viewed/:productId', () => {
    it('returns an array for a valid product', async () => {
      const res = await request(app).get(`/api/recommendations/also-viewed/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('returns an empty array for an unknown product', async () => {
      const res = await request(app).get('/api/recommendations/also-viewed/999999');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('does not require authentication', async () => {
      const res = await request(app).get(`/api/recommendations/also-viewed/${productId}`);
      expect(res.status).not.toBe(401);
    });
  });
});
