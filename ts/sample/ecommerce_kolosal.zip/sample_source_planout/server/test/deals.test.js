import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let userToken;
let productId;
let dealId;

const futureDate = () => {
  const d = new Date();
  d.setFullYear(d.getFullYear() + 1);
  return d.toISOString();
};

const pastDate = () => {
  const d = new Date();
  d.setFullYear(d.getFullYear() - 1);
  return d.toISOString();
};

beforeAll(async () => {
  // Register a regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Deals User',
    email: 'dealsuser@test.com',
    password: 'password123',
  });
  userToken = userRes.body.token;

  // Register and promote admin
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Deals Admin',
    email: 'dealsadmin@test.com',
    password: 'password123',
  });
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminRes.body.user.id);
  const loginRes = await request(app).post('/api/auth/login').send({
    email: 'dealsadmin@test.com',
    password: 'password123',
  });
  adminToken = loginRes.body.token;

  // Seed a category and product that deals can reference
  const cat = db.prepare(
    "INSERT OR IGNORE INTO categories (name, slug, description) VALUES ('Deals Cat', 'deals-cat', 'For deal tests')"
  ).run();
  const catId = cat.lastInsertRowid ||
    db.prepare("SELECT id FROM categories WHERE slug='deals-cat'").get()?.id;

  const prod = db.prepare(`
    INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run('Deals Product', 'deals-product', 'A product for deal tests', 99.99, 50, catId, 'https://example.com/dp.jpg');
  productId = prod.lastInsertRowid;

  // Seed one active deal so public GET returns results
  db.prepare(`
    INSERT INTO deals_of_day (product_id, sale_price, starts_at, ends_at, active)
    VALUES (?, ?, ?, ?, 1)
  `).run(productId, 49.99, pastDate(), futureDate());
});

describe('Deals API', () => {
  describe('GET /api/deals — public', () => {
    it('returns an array of active deals', async () => {
      const res = await request(app).get('/api/deals');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('includes product info in active deals', async () => {
      const res = await request(app).get('/api/deals');
      expect(res.status).toBe(200);
      if (res.body.length > 0) {
        expect(res.body[0]).toHaveProperty('name');
        expect(res.body[0]).toHaveProperty('sale_price');
        expect(res.body[0]).toHaveProperty('original_price');
      }
    });

    it('does not return expired or inactive deals', async () => {
      // Seed an expired deal
      db.prepare(`
        INSERT INTO deals_of_day (product_id, sale_price, starts_at, ends_at, active)
        VALUES (?, ?, ?, ?, 1)
      `).run(productId, 10.00, pastDate(), pastDate());

      const res = await request(app).get('/api/deals');
      expect(res.status).toBe(200);
      const now = new Date().toISOString();
      res.body.forEach(d => {
        expect(d.ends_at >= now).toBe(true);
      });
    });
  });

  describe('GET /api/deals/admin — admin only', () => {
    it('returns all deals including expired ones', async () => {
      const res = await request(app)
        .get('/api/deals/admin')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBeGreaterThan(0);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).get('/api/deals/admin');
      expect(res.status).toBe(401);
    });

    it('rejects non-admin user with 403', async () => {
      const res = await request(app)
        .get('/api/deals/admin')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });

  describe('POST /api/deals — admin only', () => {
    it('creates a deal with valid data and returns 201', async () => {
      const res = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          product_id: productId,
          sale_price: 59.99,
          starts_at: pastDate(),
          ends_at: futureDate(),
        });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('id');
      expect(res.body.sale_price).toBe(59.99);
      expect(res.body).toHaveProperty('name');
      dealId = res.body.id;
    });

    it('returns 400 when product_id is missing', async () => {
      const res = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ sale_price: 20.00, starts_at: pastDate(), ends_at: futureDate() });
      expect(res.status).toBe(400);
    });

    it('returns 400 when sale_price is missing', async () => {
      const res = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId, starts_at: pastDate(), ends_at: futureDate() });
      expect(res.status).toBe(400);
    });

    it('returns 400 when starts_at is missing', async () => {
      const res = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId, sale_price: 20.00, ends_at: futureDate() });
      expect(res.status).toBe(400);
    });

    it('returns 400 when ends_at is missing', async () => {
      const res = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId, sale_price: 20.00, starts_at: pastDate() });
      expect(res.status).toBe(400);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ product_id: productId, sale_price: 20.00, starts_at: pastDate(), ends_at: futureDate() });
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app)
        .post('/api/deals')
        .send({ product_id: productId, sale_price: 20.00, starts_at: pastDate(), ends_at: futureDate() });
      expect(res.status).toBe(401);
    });
  });

  describe('PUT /api/deals/:id — admin only', () => {
    it('updates an existing deal and returns 200', async () => {
      const res = await request(app)
        .put(`/api/deals/${dealId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ sale_price: 44.99, starts_at: pastDate(), ends_at: futureDate(), active: 1 });
      expect(res.status).toBe(200);
      expect(res.body.sale_price).toBe(44.99);
    });

    it('returns 404 for a nonexistent deal', async () => {
      const res = await request(app)
        .put('/api/deals/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ sale_price: 5.00, starts_at: pastDate(), ends_at: futureDate(), active: 1 });
      expect(res.status).toBe(404);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .put(`/api/deals/${dealId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ sale_price: 1.00, starts_at: pastDate(), ends_at: futureDate(), active: 1 });
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app)
        .put(`/api/deals/${dealId}`)
        .send({ sale_price: 1.00, starts_at: pastDate(), ends_at: futureDate(), active: 1 });
      expect(res.status).toBe(401);
    });
  });

  describe('DELETE /api/deals/:id — admin only', () => {
    it('deletes a deal and returns 200', async () => {
      // Create a dedicated deal to delete
      const create = await request(app)
        .post('/api/deals')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId, sale_price: 5.00, starts_at: pastDate(), ends_at: futureDate() });
      const deleteId = create.body.id;

      const res = await request(app)
        .delete(`/api/deals/${deleteId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .delete(`/api/deals/${dealId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).delete(`/api/deals/${dealId}`);
      expect(res.status).toBe(401);
    });
  });
});
