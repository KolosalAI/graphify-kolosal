import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let userToken;
let createdOptionId;

beforeAll(async () => {
  // Admin user
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Shipping Admin', email: 'shippingadmin@test.com', password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'shippingadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Shipping User', email: 'shippinguser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;
});

describe('Shipping Options API', () => {
  describe('GET /api/shipping-options', () => {
    it('returns array of active shipping options (public)', async () => {
      const res = await request(app).get('/api/shipping-options');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('includes seeded default options', async () => {
      const res = await request(app).get('/api/shipping-options');
      expect(res.status).toBe(200);
      // Default seed inserts Standard, Express, Same-Day Delivery
      expect(res.body.length).toBeGreaterThanOrEqual(1);
      expect(res.body[0]).toHaveProperty('name');
      expect(res.body[0]).toHaveProperty('price');
    });

    it('does not require authentication', async () => {
      const res = await request(app).get('/api/shipping-options');
      expect(res.status).not.toBe(401);
    });
  });

  describe('POST /api/shipping-options', () => {
    it('allows admin to create a shipping option', async () => {
      const res = await request(app)
        .post('/api/shipping-options')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Test Overnight',
          description: 'Next business day',
          price: 19.99,
          days_min: 1,
          days_max: 1,
        });
      expect(res.status).toBe(201);
      expect(res.body.name).toBe('Test Overnight');
      expect(res.body.price).toBe(19.99);
      createdOptionId = res.body.id;
    });

    it('returns 400 when required fields are missing', async () => {
      const res = await request(app)
        .post('/api/shipping-options')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Incomplete Option' });
      expect(res.status).toBe(400);
    });

    it('returns 400 when price is missing', async () => {
      const res = await request(app)
        .post('/api/shipping-options')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'No Price', days_min: 1, days_max: 3 });
      expect(res.status).toBe(400);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .post('/api/shipping-options')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Sneaky Option', price: 5, days_min: 1, days_max: 2 });
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .post('/api/shipping-options')
        .send({ name: 'Anon Option', price: 5, days_min: 1, days_max: 2 });
      expect(res.status).toBe(401);
    });
  });

  describe('PUT /api/shipping-options/:id', () => {
    it('allows admin to update a shipping option', async () => {
      const res = await request(app)
        .put(`/api/shipping-options/${createdOptionId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Test Overnight Updated', price: 22.99, days_min: 1, days_max: 1, active: 1 });
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Test Overnight Updated');
      expect(res.body.price).toBe(22.99);
    });

    it('returns 404 for unknown option', async () => {
      const res = await request(app)
        .put('/api/shipping-options/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Ghost Option', price: 1, days_min: 1, days_max: 1 });
      expect(res.status).toBe(404);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .put(`/api/shipping-options/${createdOptionId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Hack Option' });
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .put(`/api/shipping-options/${createdOptionId}`)
        .send({ name: 'Anon Update' });
      expect(res.status).toBe(401);
    });
  });

  describe('DELETE /api/shipping-options/:id', () => {
    it('allows admin to delete a shipping option', async () => {
      const res = await request(app)
        .delete(`/api/shipping-options/${createdOptionId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('blocks non-admin', async () => {
      // Get an existing option ID from the seeded data
      const listRes = await request(app).get('/api/shipping-options');
      const existingId = listRes.body[0]?.id;
      if (!existingId) return;

      const res = await request(app)
        .delete(`/api/shipping-options/${existingId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).delete(`/api/shipping-options/${createdOptionId}`);
      expect(res.status).toBe(401);
    });
  });
});
