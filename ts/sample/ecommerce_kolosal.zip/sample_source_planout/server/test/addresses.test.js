import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';

let token;
let addressId;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({
    name: 'Address Tester', email: 'addrtest@test.com', password: 'password123',
  });
  token = res.body.token;
});

describe('Addresses API', () => {
  describe('GET /api/addresses', () => {
    it('returns empty address book initially', async () => {
      const res = await request(app)
        .get('/api/addresses')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/addresses');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/addresses', () => {
    it('creates a new address', async () => {
      const res = await request(app)
        .post('/api/addresses')
        .set('Authorization', `Bearer ${token}`)
        .send({
          full_name: 'Address Tester',
          line1: '456 Main St',
          city: 'Springfield',
          state: 'IL',
          postal_code: '62701',
          country: 'US',
          phone: '555-0100',
        });
      expect(res.status).toBe(201);
      expect(res.body.full_name).toBe('Address Tester');
      addressId = res.body.id;
    });

    it('rejects missing required fields', async () => {
      const res = await request(app)
        .post('/api/addresses')
        .set('Authorization', `Bearer ${token}`)
        .send({ label: 'Work' });
      expect(res.status).toBe(400);
    });
  });

  describe('PUT /api/addresses/:id', () => {
    it('updates an address', async () => {
      const res = await request(app)
        .put(`/api/addresses/${addressId}`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          full_name: 'Address Tester Updated',
          line1: '789 Elm St',
          city: 'Springfield',
          state: 'IL',
          postal_code: '62701',
          country: 'US',
          phone: '555-0200',
        });
      expect(res.status).toBe(200);
      expect(res.body.full_name).toBe('Address Tester Updated');
    });
  });

  describe('DELETE /api/addresses/:id', () => {
    it('deletes an address', async () => {
      const res = await request(app)
        .delete(`/api/addresses/${addressId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });

    it('address no longer exists after deletion', async () => {
      const res = await request(app)
        .get('/api/addresses')
        .set('Authorization', `Bearer ${token}`);
      expect(res.body.some(a => a.id === addressId)).toBe(false);
    });
  });
});
