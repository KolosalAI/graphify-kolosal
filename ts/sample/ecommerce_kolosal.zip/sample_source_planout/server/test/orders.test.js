import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let token;
let userId;
let productId;
let orderId;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({
    name: 'Order Tester', email: 'ordertest@test.com', password: 'password123',
  });
  token = res.body.token;
  userId = res.body.user.id;

  // Seed product
  const cat = db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Order Cat', 'order-cat')").run();
  const catId = cat.lastInsertRowid || db.prepare("SELECT id FROM categories WHERE slug='order-cat'").get()?.id;
  const prod = db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Order Product', 'order-product', 'For order tests', 25.00, 100, catId, 'https://example.com/op.jpg');
  productId = prod.lastInsertRowid;
});

const orderPayload = () => ({
  customer_name: 'Order Tester',
  customer_email: 'ordertest@test.com',
  shipping_address: '123 Test Street, City, ST 12345',
  items: [{ product_id: productId, quantity: 2 }],
});

describe('Orders API', () => {
  describe('POST /api/orders', () => {
    it('creates an order successfully', async () => {
      const res = await request(app)
        .post('/api/orders')
        .set('Authorization', `Bearer ${token}`)
        .send(orderPayload());
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('id');
      expect(res.body.customer_name).toBe('Order Tester');
      expect(res.body.items.length).toBe(1);
      orderId = res.body.id;
    });

    it('rejects order with missing required fields', async () => {
      const res = await request(app)
        .post('/api/orders')
        .send({ customer_name: 'X' });
      expect(res.status).toBe(400);
    });

    it('rejects order with empty items', async () => {
      const res = await request(app)
        .post('/api/orders')
        .send({ ...orderPayload(), items: [] });
      expect(res.status).toBe(400);
    });

    it('rejects order with insufficient stock', async () => {
      const prod = db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Low Stock Item', 'low-stock-item', 'Only 1', 10.00, 1, 1, 'https://example.com/ls.jpg');
      const res = await request(app)
        .post('/api/orders')
        .send({ ...orderPayload(), items: [{ product_id: prod.lastInsertRowid, quantity: 999 }] });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/stock|insufficient/i);
    });
  });

  describe('GET /api/orders/my-orders', () => {
    it('returns user orders with valid token', async () => {
      const res = await request(app)
        .get('/api/orders/my-orders')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(o => o.id === orderId)).toBe(true);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/orders/my-orders');
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/orders/:id', () => {
    it('returns order detail', async () => {
      const res = await request(app)
        .get(`/api/orders/${orderId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.id).toBe(orderId);
      expect(res.body).toHaveProperty('items');
    });

    it('returns 404 for non-existent order', async () => {
      const res = await request(app)
        .get('/api/orders/999999')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(404);
    });
  });

  describe('PATCH /api/orders/:id/cancel', () => {
    it('cancels a pending order', async () => {
      // Create a fresh order to cancel
      const createRes = await request(app)
        .post('/api/orders')
        .set('Authorization', `Bearer ${token}`)
        .send(orderPayload());
      const newOrderId = createRes.body.id;

      const res = await request(app)
        .patch(`/api/orders/${newOrderId}/cancel`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('cancelled');
    });

    it('requires authentication', async () => {
      const res = await request(app).patch(`/api/orders/${orderId}/cancel`);
      expect(res.status).toBe(401);
    });
  });
});

export { token as orderToken, productId as orderProductId, orderId };
