import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let userId;
let user2Token;
let adminToken;
let adminId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Sub User', email: 'subuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;
  userId = userRes.body.user.id;

  // Second user for cancel tests
  const user2Res = await request(app).post('/api/auth/register').send({
    name: 'Sub User Two', email: 'subuser2@test.com', password: 'password123',
  });
  user2Token = user2Res.body.token;

  // Admin
  const adminReg = await request(app).post('/api/auth/register').send({
    name: 'Sub Admin', email: 'subadmin@test.com', password: 'password123',
  });
  adminId = adminReg.body.user.id;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'subadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;
});

describe('Subscriptions API', () => {
  describe('GET /api/subscriptions/plans', () => {
    it('is publicly accessible', async () => {
      const res = await request(app).get('/api/subscriptions/plans');
      expect(res.status).toBe(200);
    });

    it('returns an array of exactly 2 plans', async () => {
      const res = await request(app).get('/api/subscriptions/plans');
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(2);
    });

    it('includes prime_monthly and prime_annual plans', async () => {
      const res = await request(app).get('/api/subscriptions/plans');
      const ids = res.body.map(p => p.id);
      expect(ids).toContain('prime_monthly');
      expect(ids).toContain('prime_annual');
    });

    it('each plan has required fields', async () => {
      const res = await request(app).get('/api/subscriptions/plans');
      for (const plan of res.body) {
        expect(plan).toHaveProperty('id');
        expect(plan).toHaveProperty('name');
        expect(plan).toHaveProperty('price');
        expect(plan).toHaveProperty('billing_cycle');
        expect(Array.isArray(plan.features)).toBe(true);
      }
    });
  });

  describe('GET /api/subscriptions/me', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app).get('/api/subscriptions/me');
      expect(res.status).toBe(401);
    });

    it('returns null when user has no subscription', async () => {
      const res = await request(app)
        .get('/api/subscriptions/me')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toBeNull();
    });
  });

  describe('POST /api/subscriptions/subscribe', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .post('/api/subscriptions/subscribe')
        .send({ billing_cycle: 'monthly' });
      expect(res.status).toBe(401);
    });

    it('returns 400 for invalid billing_cycle', async () => {
      const res = await request(app)
        .post('/api/subscriptions/subscribe')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ billing_cycle: 'weekly' });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('subscribes with monthly billing → 200 with subscription object', async () => {
      const res = await request(app)
        .post('/api/subscriptions/subscribe')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ billing_cycle: 'monthly' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('plan', 'prime');
      expect(res.body).toHaveProperty('billing_cycle', 'monthly');
      expect(res.body).toHaveProperty('status', 'active');
      expect(res.body).toHaveProperty('current_period_end');
    });

    it('GET /me now returns the subscription', async () => {
      const res = await request(app)
        .get('/api/subscriptions/me')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body).not.toBeNull();
      expect(res.body).toHaveProperty('status', 'active');
    });

    it('subscribes with annual billing → 200 with subscription object', async () => {
      const res = await request(app)
        .post('/api/subscriptions/subscribe')
        .set('Authorization', `Bearer ${user2Token}`)
        .send({ billing_cycle: 'annual' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('billing_cycle', 'annual');
      expect(res.body).toHaveProperty('status', 'active');
    });

    it('annual subscription awards 500 loyalty points', async () => {
      const user2Res = await request(app).post('/api/auth/register').send({
        name: 'Annual Sub User', email: 'annualsub@test.com', password: 'password123',
      });
      const annualToken = user2Res.body.token;
      const annualUserId = user2Res.body.user.id;

      const before = db.prepare('SELECT loyalty_points_balance FROM users WHERE id = ?').get(annualUserId);

      await request(app)
        .post('/api/subscriptions/subscribe')
        .set('Authorization', `Bearer ${annualToken}`)
        .send({ billing_cycle: 'annual' });

      const after = db.prepare('SELECT loyalty_points_balance FROM users WHERE id = ?').get(annualUserId);
      expect(after.loyalty_points_balance).toBe((before?.loyalty_points_balance || 0) + 500);
    });

    it('monthly subscription does not award loyalty points', async () => {
      const regRes = await request(app).post('/api/auth/register').send({
        name: 'Monthly Sub User', email: 'monthlysub@test.com', password: 'password123',
      });
      const monthlyToken = regRes.body.token;
      const monthlyUserId = regRes.body.user.id;

      const before = db.prepare('SELECT loyalty_points_balance FROM users WHERE id = ?').get(monthlyUserId);

      await request(app)
        .post('/api/subscriptions/subscribe')
        .set('Authorization', `Bearer ${monthlyToken}`)
        .send({ billing_cycle: 'monthly' });

      const after = db.prepare('SELECT loyalty_points_balance FROM users WHERE id = ?').get(monthlyUserId);
      expect(after.loyalty_points_balance).toBe(before?.loyalty_points_balance || 0);
    });

    it('can update billing cycle by subscribing again', async () => {
      const res = await request(app)
        .post('/api/subscriptions/subscribe')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ billing_cycle: 'annual' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('billing_cycle', 'annual');
    });
  });

  describe('POST /api/subscriptions/cancel', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app).post('/api/subscriptions/cancel');
      expect(res.status).toBe(401);
    });

    it('cancels an active subscription → 200 with success: true', async () => {
      const res = await request(app)
        .post('/api/subscriptions/cancel')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('success', true);
    });

    it('returns 404 when no subscription exists', async () => {
      // Register a fresh user with no subscription
      const freshRes = await request(app).post('/api/auth/register').send({
        name: 'No Sub User', email: 'nosubuser@test.com', password: 'password123',
      });
      const freshToken = freshRes.body.token;

      const res = await request(app)
        .post('/api/subscriptions/cancel')
        .set('Authorization', `Bearer ${freshToken}`);
      expect(res.status).toBe(404);
    });
  });

  describe('GET /api/subscriptions/admin/all', () => {
    it('returns 401 without authentication', async () => {
      const res = await request(app).get('/api/subscriptions/admin/all');
      expect(res.status).toBe(401);
    });

    it('returns 403 for non-admin users', async () => {
      const regRes = await request(app).post('/api/auth/register').send({
        name: 'Regular Guy', email: 'regularguy@test.com', password: 'password123',
      });
      const regularToken = regRes.body.token;

      const res = await request(app)
        .get('/api/subscriptions/admin/all')
        .set('Authorization', `Bearer ${regularToken}`);
      expect(res.status).toBe(403);
    });

    it('admin gets all subscriptions with user info → 200', async () => {
      const res = await request(app)
        .get('/api/subscriptions/admin/all')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('admin result includes user name and email fields', async () => {
      const res = await request(app)
        .get('/api/subscriptions/admin/all')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      if (res.body.length > 0) {
        expect(res.body[0]).toHaveProperty('name');
        expect(res.body[0]).toHaveProperty('email');
        expect(res.body[0]).toHaveProperty('plan');
        expect(res.body[0]).toHaveProperty('status');
      }
    });
  });
});
