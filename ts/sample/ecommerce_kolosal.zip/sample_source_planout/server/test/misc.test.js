import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let productId;

beforeAll(async () => {
  // Admin user
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Deals Admin', email: 'dealsadmin@test.com', password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(adminId);
  const loginRes = await request(app).post('/api/auth/login').send({
    email: 'dealsadmin@test.com', password: 'password123',
  });
  adminToken = loginRes.body.token;

  // Seed product
  const cat = db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Deal Cat', 'deal-cat')").run();
  const catId = cat.lastInsertRowid || db.prepare("SELECT id FROM categories WHERE slug='deal-cat'").get()?.id;
  const prod = db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Deal Product', 'deal-product', 'For deals', 50.00, 40, catId, 'https://example.com/dp.jpg');
  productId = prod.lastInsertRowid;
});

describe('Deals API', () => {
  describe('GET /api/deals', () => {
    it('returns list of deals', async () => {
      const res = await request(app).get('/api/deals');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});

describe('Flash Sales API', () => {
  describe('GET /api/flash-sales/active', () => {
    it('returns active flash sales', async () => {
      const res = await request(app).get('/api/flash-sales/active');
      expect(res.status).toBe(200);
    });
  });
});

describe('Coupons API', () => {
  describe('POST /api/coupons/validate', () => {
    it('returns error for invalid coupon', async () => {
      const res = await request(app)
        .post('/api/coupons/validate')
        .send({ code: 'FAKECODE', subtotal: 100 });
      expect(res.status).toBeGreaterThanOrEqual(400);
    });
  });

  describe('Admin coupon management', () => {
    it('allows admin to create coupon', async () => {
      const res = await request(app)
        .post('/api/coupons')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          code: 'TEST20',
          type: 'percentage',
          value: 20,
          min_order: 50,
          max_uses: 100,
        });
      expect(res.status).toBe(201);
    });

    it('allows validating a real coupon', async () => {
      const res = await request(app)
        .post('/api/coupons/validate')
        .send({ code: 'TEST20', subtotal: 100 });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('discount');
    });
  });
});

describe('Shipping Options API', () => {
  describe('GET /api/shipping-options', () => {
    it('returns shipping options', async () => {
      const res = await request(app).get('/api/shipping-options');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});

describe('Banners API', () => {
  describe('GET /api/banners', () => {
    it('returns banner list', async () => {
      const res = await request(app).get('/api/banners');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});

describe('Gift Cards API', () => {
  describe('POST /api/gift-cards/validate', () => {
    it('returns error for invalid gift card code', async () => {
      const res = await request(app)
        .post('/api/gift-cards/validate')
        .send({ code: 'INVALIDGC' });
      expect(res.status).toBeGreaterThanOrEqual(400);
    });
  });
});

describe('Recommendations API', () => {
  describe('GET /api/recommendations', () => {
    it('returns recommendations list when authenticated', async () => {
      const res = await request(app)
        .get('/api/recommendations')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});

describe('Returns API', () => {
  describe('GET /api/returns', () => {
    it('requires authentication', async () => {
      const res = await request(app).get('/api/returns');
      expect(res.status).toBe(401);
    });
  });
});

describe('Health Check', () => {
  it('GET /api/health returns ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});
