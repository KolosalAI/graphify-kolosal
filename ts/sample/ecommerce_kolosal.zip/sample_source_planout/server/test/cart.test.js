import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let token;
let userId;
let productId;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({
    name: 'Cart Tester', email: 'carttest@test.com', password: 'password123',
  });
  token = res.body.token;
  userId = res.body.user.id;

  // Seed a product to add to cart
  const cat = db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Cart Cat', 'cart-cat')").run();
  const catId = cat.lastInsertRowid || db.prepare("SELECT id FROM categories WHERE slug='cart-cat'").get()?.id;
  const prod = db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Cart Product', 'cart-product', 'For cart testing', 15.00, 50, catId, 'https://example.com/cp.jpg');
  productId = prod.lastInsertRowid;
});

describe('Cart API', () => {
  describe('GET /api/cart', () => {
    it('returns empty cart for new user', async () => {
      const res = await request(app)
        .get('/api/cart')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/cart');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/cart/sync', () => {
    it('syncs cart items to server', async () => {
      const res = await request(app)
        .post('/api/cart/sync')
        .set('Authorization', `Bearer ${token}`)
        .send({ items: [{ id: productId, quantity: 2 }] });
      expect(res.status).toBe(200);
      expect(res.body.some(item => item.id === productId && item.quantity === 2)).toBe(true);
    });

    it('rejects invalid body', async () => {
      const res = await request(app)
        .post('/api/cart/sync')
        .set('Authorization', `Bearer ${token}`)
        .send({ items: 'not-an-array' });
      expect(res.status).toBe(400);
    });
  });

  describe('PUT /api/cart/:productId', () => {
    it('updates item quantity', async () => {
      const res = await request(app)
        .put(`/api/cart/${productId}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ quantity: 5 });
      expect(res.status).toBe(200);
      expect(res.body.some(item => item.id === productId && item.quantity === 5)).toBe(true);
    });
  });

  describe('DELETE /api/cart/:productId', () => {
    it('removes item from cart', async () => {
      const res = await request(app)
        .delete(`/api/cart/${productId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.some(item => item.id === productId)).toBe(false);
    });
  });

  describe('DELETE /api/cart', () => {
    it('clears entire cart', async () => {
      // Add item first
      await request(app)
        .post('/api/cart/sync')
        .set('Authorization', `Bearer ${token}`)
        .send({ items: [{ id: productId, quantity: 1 }] });

      const res = await request(app)
        .delete('/api/cart')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body).toEqual([]);
    });
  });
});
