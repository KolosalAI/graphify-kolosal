import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let reviewerToken;
let reviewerUserId;
let voterToken;
let productId;
let deliveredOrderId;
let createdReviewId;

beforeAll(async () => {
  // Reviewer user with a delivered order
  const reviewerRes = await request(app).post('/api/auth/register').send({
    name: 'Review Tester', email: 'reviewtest@test.com', password: 'password123',
  });
  reviewerToken = reviewerRes.body.token;
  reviewerUserId = reviewerRes.body.user.id;

  // Voter user (just needs to be authenticated, no purchase required to vote)
  const voterRes = await request(app).post('/api/auth/register').send({
    name: 'Review Voter', email: 'reviewvoter@test.com', password: 'password123',
  });
  voterToken = voterRes.body.token;

  // Seed product
  const cat = db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Review Cat', 'review-cat')").run();
  const catId = cat.lastInsertRowid || db.prepare("SELECT id FROM categories WHERE slug='review-cat'").get()?.id;
  const prod = db.prepare(
    "INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run('Review Product', 'review-product', 'For reviews', 20.00, 50, catId, 'https://example.com/rp.jpg');
  productId = prod.lastInsertRowid;

  // Delivered order so reviewer can post a review
  const order = db.prepare(
    "INSERT INTO orders (user_id, customer_name, customer_email, shipping_address, subtotal, total, status) VALUES (?, ?, ?, ?, ?, ?, 'delivered')"
  ).run(reviewerUserId, 'Review Tester', 'reviewtest@test.com', '1 Test Ave', 20.00, 20.00);
  deliveredOrderId = order.lastInsertRowid;
  db.prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, 1, 20.00)").run(deliveredOrderId, productId);
});

// ── GET reviews ───────────────────────────────────────────────────────────────

describe('GET /api/reviews/:productId', () => {
  it('returns empty reviews for new product', async () => {
    const res = await request(app).get(`/api/reviews/${productId}`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('stats');
    expect(res.body).toHaveProperty('reviews');
    expect(Array.isArray(res.body.reviews)).toBe(true);
    expect(res.body.reviews.length).toBe(0);
  });

  it('includes stats with total and average', async () => {
    const res = await request(app).get(`/api/reviews/${productId}`);
    expect(res.body.stats).toHaveProperty('total');
    expect(res.body.stats).toHaveProperty('average');
  });

  it('works for unauthenticated users', async () => {
    const res = await request(app).get(`/api/reviews/${productId}`);
    expect(res.status).toBe(200);
    expect(res.body.userReview).toBeNull();
  });
});

// ── POST review ───────────────────────────────────────────────────────────────

describe('POST /api/reviews/:productId', () => {
  it('allows review if user purchased the product', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ rating: 5, title: 'Great', body: 'Excellent product!' });
    expect(res.status).toBe(201);
    expect(res.body.rating).toBe(5);
    expect(res.body.title).toBe('Great');
    createdReviewId = res.body.id;
  });

  it('returns 409 when user tries to review the same product twice', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ rating: 4, body: 'Again' });
    expect(res.status).toBe(409);
  });

  it('blocks review from non-purchaser', async () => {
    const reg = await request(app).post('/api/auth/register').send({
      name: 'No Buyer', email: 'nobuyer@test.com', password: 'password123',
    });
    const res = await request(app)
      .post(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reg.body.token}`)
      .send({ rating: 3, body: 'Trying to review' });
    expect(res.status).toBe(403);
    expect(res.body.error).toMatch(/purchase/i);
  });

  it('requires authentication', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}`)
      .send({ rating: 4, body: 'Test' });
    expect(res.status).toBe(401);
  });

  it('returns 400 for invalid rating below 1', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ rating: 0, body: 'Zero rating' });
    expect(res.status).toBeGreaterThanOrEqual(400);
  });

  it('returns 400 for rating above 5', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ rating: 10, body: 'Too high' });
    expect(res.status).toBeGreaterThanOrEqual(400);
  });
});

// ── GET reviews after posting ─────────────────────────────────────────────────

describe('GET /api/reviews/:productId (after review)', () => {
  it('returns the posted review', async () => {
    const res = await request(app).get(`/api/reviews/${productId}`);
    expect(res.status).toBe(200);
    expect(res.body.reviews.some(r => r.rating === 5)).toBe(true);
    expect(res.body.stats.total).toBe(1);
    expect(res.body.stats.average).toBe(5);
  });

  it('flags userReview when authenticated reviewer calls it', async () => {
    const res = await request(app)
      .get(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.userReview).not.toBeNull();
    expect(res.body.userReview.rating).toBe(5);
  });
});

// ── PUT update review ─────────────────────────────────────────────────────────

describe('PUT /api/reviews/:productId', () => {
  it('updates own review', async () => {
    const res = await request(app)
      .put(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ rating: 4, title: 'Updated', body: 'Changed my mind.' });
    expect(res.status).toBe(200);
    expect(res.body.rating).toBe(4);
    expect(res.body.title).toBe('Updated');
  });

  it('returns 400 for invalid rating', async () => {
    const res = await request(app)
      .put(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ rating: 6, body: 'Bad rating' });
    expect(res.status).toBe(400);
  });

  it('returns 404 for review not found (user who never reviewed)', async () => {
    const res = await request(app)
      .put(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${voterToken}`)
      .send({ rating: 3, body: 'Not my review' });
    expect(res.status).toBe(404);
  });

  it('requires authentication', async () => {
    const res = await request(app)
      .put(`/api/reviews/${productId}`)
      .send({ rating: 3, body: 'Anon update' });
    expect(res.status).toBe(401);
  });
});

// ── Helpful votes ─────────────────────────────────────────────────────────────

describe('POST /api/reviews/:productId/:reviewId/helpful', () => {
  it('marks a review helpful', async () => {
    // Use voter (different user from reviewer) to vote
    const res = await request(app)
      .post(`/api/reviews/${productId}/${createdReviewId}/helpful`)
      .set('Authorization', `Bearer ${voterToken}`)
      .send({ helpful: true });
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('helpful_count');
    expect(res.body.helpful_count).toBe(1);
  });

  it('toggling helpful again removes the vote', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}/${createdReviewId}/helpful`)
      .set('Authorization', `Bearer ${voterToken}`)
      .send({ helpful: true });
    expect(res.status).toBe(200);
    expect(res.body.helpful_count).toBe(0);
  });

  it('returns 400 when reviewer votes on their own review', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}/${createdReviewId}/helpful`)
      .set('Authorization', `Bearer ${reviewerToken}`)
      .send({ helpful: true });
    expect(res.status).toBe(400);
    expect(res.body.error).toMatch(/own review/i);
  });

  it('returns 404 for unknown review', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}/999999/helpful`)
      .set('Authorization', `Bearer ${voterToken}`)
      .send({ helpful: true });
    expect(res.status).toBe(404);
  });

  it('requires authentication', async () => {
    const res = await request(app)
      .post(`/api/reviews/${productId}/${createdReviewId}/helpful`)
      .send({ helpful: true });
    expect(res.status).toBe(401);
  });
});

// ── DELETE review ─────────────────────────────────────────────────────────────

describe('DELETE /api/reviews/:productId', () => {
  it('deletes own review', async () => {
    const res = await request(app)
      .delete(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`);
    expect(res.status).toBe(200);
    expect(res.body.message).toMatch(/deleted/i);
  });

  it('returns 404 after review is deleted', async () => {
    const res = await request(app)
      .delete(`/api/reviews/${productId}`)
      .set('Authorization', `Bearer ${reviewerToken}`);
    expect(res.status).toBe(404);
  });

  it('requires authentication', async () => {
    const res = await request(app).delete(`/api/reviews/${productId}`);
    expect(res.status).toBe(401);
  });
});
