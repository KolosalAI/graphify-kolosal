import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let token;
let categoryId;

beforeAll(async () => {
  // Register a user to get a token
  const res = await request(app).post('/api/auth/register').send({
    name: 'Product Tester', email: 'prodtest@test.com', password: 'password123',
  });
  token = res.body.token;

  // Create a test category
  const cat = db.prepare("INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)").run('Test Category', 'test-category', 'For testing');
  categoryId = cat.lastInsertRowid;

  // Create test products
  db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Alpha Widget', 'alpha-widget', 'Great widget', 29.99, 50, categoryId, 'https://example.com/img.jpg');
  db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Beta Gadget', 'beta-gadget', 'Nice gadget', 59.99, 10, categoryId, 'https://example.com/img2.jpg');
  db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Cheap Item', 'cheap-item', 'Budget item', 5.99, 100, categoryId, 'https://example.com/img3.jpg');
});

describe('Products API', () => {
  describe('GET /api/products', () => {
    it('returns a paginated list of products', async () => {
      const res = await request(app).get('/api/products');
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('products');
      expect(Array.isArray(res.body.products)).toBe(true);
      expect(res.body).toHaveProperty('pagination');
    });

    it('supports limit parameter', async () => {
      const res = await request(app).get('/api/products?limit=2');
      expect(res.status).toBe(200);
      expect(res.body.products.length).toBeLessThanOrEqual(2);
    });

    it('supports search query', async () => {
      const res = await request(app).get('/api/products?q=Alpha');
      expect(res.status).toBe(200);
      expect(res.body.products.some(p => p.name.includes('Alpha'))).toBe(true);
    });

    it('filters by category', async () => {
      const res = await request(app).get(`/api/products?category=test-category`);
      expect(res.status).toBe(200);
      expect(res.body.products.length).toBeGreaterThan(0);
    });

    it('sorts by price ascending', async () => {
      const res = await request(app).get('/api/products?sort=price_asc');
      expect(res.status).toBe(200);
      const prices = res.body.products.map(p => p.price);
      for (let i = 1; i < prices.length; i++) {
        expect(prices[i]).toBeGreaterThanOrEqual(prices[i - 1]);
      }
    });

    it('sorts by price descending', async () => {
      const res = await request(app).get('/api/products?sort=price_desc');
      expect(res.status).toBe(200);
      const prices = res.body.products.map(p => p.price);
      for (let i = 1; i < prices.length; i++) {
        expect(prices[i]).toBeLessThanOrEqual(prices[i - 1]);
      }
    });

    it('filters by price range', async () => {
      const res = await request(app).get('/api/products?min_price=10&max_price=40');
      expect(res.status).toBe(200);
      res.body.products.forEach(p => {
        expect(p.price).toBeGreaterThanOrEqual(10);
        expect(p.price).toBeLessThanOrEqual(40);
      });
    });

    it('returns pagination metadata', async () => {
      const res = await request(app).get('/api/products?page=1&limit=1');
      expect(res.body.pagination).toMatchObject({
        page: 1,
        limit: 1,
      });
      expect(res.body.pagination).toHaveProperty('total');
      expect(res.body.pagination).toHaveProperty('totalPages');
    });
  });

  describe('GET /api/products/:slug', () => {
    it('returns a product by slug', async () => {
      const res = await request(app).get('/api/products/alpha-widget');
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Alpha Widget');
      expect(res.body.slug).toBe('alpha-widget');
    });

    it('returns 404 for unknown slug', async () => {
      const res = await request(app).get('/api/products/does-not-exist');
      expect(res.status).toBe(404);
    });
  });

  describe('GET /api/products/suggestions', () => {
    it('returns autocomplete suggestions', async () => {
      const res = await request(app).get('/api/products/suggestions?q=Alpha');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('returns empty array for short query', async () => {
      const res = await request(app).get('/api/products/suggestions?q=a');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});

describe('Categories API', () => {
  describe('GET /api/categories', () => {
    it('returns list of categories', async () => {
      const res = await request(app).get('/api/categories');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(c => c.slug === 'test-category')).toBe(true);
    });
  });
});
