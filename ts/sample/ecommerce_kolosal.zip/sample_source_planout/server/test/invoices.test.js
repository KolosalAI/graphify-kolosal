import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let userId;
let otherToken;
let orderId;
let productId;

beforeAll(async () => {
  // Register primary user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Invoice User',
    email: 'invoiceuser@test.com',
    password: 'password123',
  });
  userToken = userRes.body.token;
  userId = userRes.body.user.id;

  // Register a second user who should not have access to user1's order
  const otherRes = await request(app).post('/api/auth/register').send({
    name: 'Invoice Other',
    email: 'invoiceother@test.com',
    password: 'password123',
  });
  otherToken = otherRes.body.token;

  // Seed category and product
  const cat = db.prepare(
    "INSERT OR IGNORE INTO categories (name, slug, description) VALUES ('Invoice Cat', 'invoice-cat', 'For invoice tests')"
  ).run();
  const catId = cat.lastInsertRowid ||
    db.prepare("SELECT id FROM categories WHERE slug='invoice-cat'").get()?.id;

  const prod = db.prepare(`
    INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run('Invoice Product', 'invoice-product', 'For invoice tests', 30.00, 50, catId, 'https://example.com/ip.jpg');
  productId = prod.lastInsertRowid;

  // Create order directly in DB (user1 owns this order)
  const order = db.prepare(`
    INSERT INTO orders (user_id, customer_name, customer_email, shipping_address, subtotal, discount, total, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(userId, 'Invoice User', 'invoiceuser@test.com', '123 Invoice St, City, ST 12345', 30.00, 0, 30.00, 'pending');
  orderId = order.lastInsertRowid;

  db.prepare(`
    INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)
  `).run(orderId, productId, 1, 30.00);
});

describe('Invoices API', () => {
  describe('GET /api/invoices/:orderId — authenticated', () => {
    it('returns a PDF invoice for the user\'s own order', async () => {
      const res = await request(app)
        .get(`/api/invoices/${orderId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toMatch(/application\/pdf/);
    });

    it('returns 404 for a nonexistent order', async () => {
      const res = await request(app)
        .get('/api/invoices/999999')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(404);
      expect(res.body.error).toMatch(/not found/i);
    });

    it('returns 404 when order belongs to a different user', async () => {
      // otherToken user tries to access userId's order — route returns 404 (not 403) to avoid leaking data
      const res = await request(app)
        .get(`/api/invoices/${orderId}`)
        .set('Authorization', `Bearer ${otherToken}`);
      expect(res.status).toBe(404);
    });

    it('returns 401 without authentication', async () => {
      const res = await request(app).get(`/api/invoices/${orderId}`);
      expect(res.status).toBe(401);
    });

    it('returns 401 with an invalid token', async () => {
      const res = await request(app)
        .get(`/api/invoices/${orderId}`)
        .set('Authorization', 'Bearer invalidtoken');
      expect(res.status).toBe(401);
    });

    it('allows admin to retrieve any order\'s invoice', async () => {
      // Promote otherToken user to admin, re-login
      const adminRes = await request(app).post('/api/auth/register').send({
        name: 'Invoice Admin',
        email: 'invoiceadmin@test.com',
        password: 'password123',
      });
      db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminRes.body.user.id);
      const loginRes = await request(app).post('/api/auth/login').send({
        email: 'invoiceadmin@test.com',
        password: 'password123',
      });
      const adminToken = loginRes.body.token;

      const res = await request(app)
        .get(`/api/invoices/${orderId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.headers['content-type']).toMatch(/application\/pdf/);
    });
  });
});
