import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let adminId;
let userToken;
let productId;
let flashSaleId;
let flashSaleItemId;

const futureStart = new Date(Date.now() + 60_000).toISOString();
const futureEnd = new Date(Date.now() + 3_600_000).toISOString();

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Flash User', email: 'flashuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;

  // Admin
  const adminReg = await request(app).post('/api/auth/register').send({
    name: 'Flash Admin', email: 'flashadmin@test.com', password: 'password123',
  });
  adminId = adminReg.body.user.id;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'flashadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Seed category + product
  const cat = db.prepare(
    "INSERT OR IGNORE INTO categories (name, slug) VALUES ('Flash Cat', 'flash-cat')"
  ).run();
  const catId = cat.lastInsertRowid ||
    db.prepare("SELECT id FROM categories WHERE slug='flash-cat'").get()?.id;
  const prod = db.prepare(
    `INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run('Flash Product', 'flash-product', 'Product for flash sale tests', 99.99, 50, catId, 'https://example.com/flash.jpg');
  productId = prod.lastInsertRowid;
});

describe('Flash Sales API', () => {
  describe('GET /api/flash-sales/active (public)', () => {
    it('is publicly accessible', async () => {
      const res = await request(app).get('/api/flash-sales/active');
      expect(res.status).toBe(200);
    });

    it('returns null or an active sale object (not an array)', async () => {
      const res = await request(app).get('/api/flash-sales/active');
      expect(res.status).toBe(200);
      // Either null or an object with items array
      if (res.body !== null) {
        expect(res.body).toHaveProperty('items');
        expect(Array.isArray(res.body.items)).toBe(true);
      }
    });
  });

  describe('GET /api/flash-sales/ (admin)', () => {
    it('returns 401 without authentication', async () => {
      const res = await request(app).get('/api/flash-sales/');
      expect(res.status).toBe(401);
    });

    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .get('/api/flash-sales/')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('admin gets all flash sales → 200 array', async () => {
      const res = await request(app)
        .get('/api/flash-sales/')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });

  describe('POST /api/flash-sales/ (admin create)', () => {
    it('returns 401 without authentication', async () => {
      const res = await request(app)
        .post('/api/flash-sales/')
        .send({ title: 'Test Sale', starts_at: futureStart, ends_at: futureEnd });
      expect(res.status).toBe(401);
    });

    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .post('/api/flash-sales/')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ title: 'Test Sale', starts_at: futureStart, ends_at: futureEnd });
      expect(res.status).toBe(403);
    });

    it('returns 400 when required fields are missing', async () => {
      const res = await request(app)
        .post('/api/flash-sales/')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ title: 'No Dates Sale' });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('returns 400 when ends_at is before starts_at', async () => {
      const res = await request(app)
        .post('/api/flash-sales/')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          title: 'Bad Dates Sale',
          starts_at: futureEnd,
          ends_at: futureStart,
        });
      expect(res.status).toBe(400);
    });

    it('creates a flash sale → 201 with title and dates', async () => {
      const res = await request(app)
        .post('/api/flash-sales/')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ title: 'Summer Flash', starts_at: futureStart, ends_at: futureEnd });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('title', 'Summer Flash');
      expect(res.body).toHaveProperty('starts_at');
      expect(res.body).toHaveProperty('ends_at');
      expect(res.body).toHaveProperty('id');
      flashSaleId = res.body.id;
    });
  });

  describe('GET /api/flash-sales/:id (admin single)', () => {
    it('returns 404 for nonexistent flash sale', async () => {
      const res = await request(app)
        .get('/api/flash-sales/99999')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('admin gets a single flash sale with items array → 200', async () => {
      const res = await request(app)
        .get(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('id', flashSaleId);
      expect(res.body).toHaveProperty('title');
      expect(Array.isArray(res.body.items)).toBe(true);
    });
  });

  describe('PUT /api/flash-sales/:id (admin update)', () => {
    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .put(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ title: 'Updated', starts_at: futureStart, ends_at: futureEnd, active: true });
      expect(res.status).toBe(403);
    });

    it('updates a flash sale → 200 with updated title', async () => {
      const res = await request(app)
        .put(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ title: 'Summer Flash Updated', starts_at: futureStart, ends_at: futureEnd, active: true });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('title', 'Summer Flash Updated');
    });
  });

  describe('PATCH /api/flash-sales/:id/toggle (admin toggle)', () => {
    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .patch(`/api/flash-sales/${flashSaleId}/toggle`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('returns 404 for nonexistent flash sale', async () => {
      const res = await request(app)
        .patch('/api/flash-sales/99999/toggle')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('toggles the active state → 200 with new active value', async () => {
      const before = await request(app)
        .get(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      const wasActive = !!before.body.active;

      const res = await request(app)
        .patch(`/api/flash-sales/${flashSaleId}/toggle`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('id', flashSaleId);
      expect(!!res.body.active).toBe(!wasActive);
    });
  });

  describe('POST /api/flash-sales/:id/items (admin add item)', () => {
    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .post(`/api/flash-sales/${flashSaleId}/items`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ product_id: productId, sale_price: 49.99 });
      expect(res.status).toBe(403);
    });

    it('returns 400 when required fields are missing', async () => {
      const res = await request(app)
        .post(`/api/flash-sales/${flashSaleId}/items`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId });
      expect(res.status).toBe(400);
    });

    it('adds a product to flash sale → 201 with item data', async () => {
      const res = await request(app)
        .post(`/api/flash-sales/${flashSaleId}/items`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId, sale_price: 49.99 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('product_id', productId);
      expect(res.body).toHaveProperty('sale_price', 49.99);
      expect(res.body).toHaveProperty('name');
      flashSaleItemId = res.body.id;
    });

    it('returns 409 when adding same product twice', async () => {
      const res = await request(app)
        .post(`/api/flash-sales/${flashSaleId}/items`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ product_id: productId, sale_price: 39.99 });
      expect(res.status).toBe(409);
    });
  });

  describe('PUT /api/flash-sales/:id/items/:itemId (admin update item)', () => {
    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .put(`/api/flash-sales/${flashSaleId}/items/${flashSaleItemId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ sale_price: 44.99 });
      expect(res.status).toBe(403);
    });

    it('returns 404 for nonexistent item', async () => {
      const res = await request(app)
        .put(`/api/flash-sales/${flashSaleId}/items/99999`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ sale_price: 44.99 });
      expect(res.status).toBe(404);
    });

    it('updates item sale price → 200', async () => {
      const res = await request(app)
        .put(`/api/flash-sales/${flashSaleId}/items/${flashSaleItemId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ sale_price: 44.99 });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('sale_price', 44.99);
    });
  });

  describe('DELETE /api/flash-sales/:id/items/:itemId (admin remove item)', () => {
    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .delete(`/api/flash-sales/${flashSaleId}/items/${flashSaleItemId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('removes an item from flash sale → 200', async () => {
      const res = await request(app)
        .delete(`/api/flash-sales/${flashSaleId}/items/${flashSaleItemId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('message');
    });

    it('returns 404 when item no longer exists', async () => {
      const res = await request(app)
        .delete(`/api/flash-sales/${flashSaleId}/items/${flashSaleItemId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });
  });

  describe('DELETE /api/flash-sales/:id (admin delete)', () => {
    it('returns 403 for non-admin', async () => {
      const res = await request(app)
        .delete(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('deletes a flash sale → 200', async () => {
      const res = await request(app)
        .delete(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('message');
    });

    it('returns 404 for already-deleted flash sale', async () => {
      const res = await request(app)
        .delete(`/api/flash-sales/${flashSaleId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });
  });
});
