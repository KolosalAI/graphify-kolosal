import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';

let userToken;
let adminToken;
let userId;

const adminUser = {
  name: 'Admin User',
  email: 'admin@test.com',
  password: 'password123',
};
const regularUser = {
  name: 'Test User',
  email: 'user@test.com',
  password: 'password123',
};

describe('Auth API', () => {
  describe('POST /api/auth/register', () => {
    it('registers a new user successfully', async () => {
      const res = await request(app).post('/api/auth/register').send(regularUser);
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('token');
      expect(res.body.user.email).toBe(regularUser.email);
      expect(res.body.user).not.toHaveProperty('password');
      userToken = res.body.token;
      userId = res.body.user.id;
    });

    it('rejects registration with duplicate email', async () => {
      const res = await request(app).post('/api/auth/register').send(regularUser);
      expect(res.status).toBe(409);
      expect(res.body.error).toMatch(/already registered/i);
    });

    it('rejects registration with missing fields', async () => {
      const res = await request(app).post('/api/auth/register').send({ email: 'a@b.com' });
      expect(res.status).toBe(400);
    });

    it('rejects registration with short password', async () => {
      const res = await request(app).post('/api/auth/register').send({
        name: 'X', email: 'x@test.com', password: '123',
      });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/6 characters/i);
    });

    it('registers admin user', async () => {
      const res = await request(app).post('/api/auth/register').send(adminUser);
      expect(res.status).toBe(201);
      adminToken = res.body.token;
    });
  });

  describe('POST /api/auth/login', () => {
    it('logs in with correct credentials', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: regularUser.email,
        password: regularUser.password,
      });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('token');
      expect(res.body.user.email).toBe(regularUser.email);
    });

    it('rejects wrong password', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: regularUser.email,
        password: 'wrongpassword',
      });
      expect(res.status).toBe(401);
    });

    it('rejects non-existent email', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: 'nobody@test.com',
        password: 'password123',
      });
      expect(res.status).toBe(401);
    });

    it('rejects missing fields', async () => {
      const res = await request(app).post('/api/auth/login').send({ email: 'a@b.com' });
      expect(res.status).toBe(400);
    });
  });

  describe('GET /api/auth/me', () => {
    it('returns user profile with valid token', async () => {
      const res = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body.email).toBe(regularUser.email);
    });

    it('rejects request without token', async () => {
      const res = await request(app).get('/api/auth/me');
      expect(res.status).toBe(401);
    });

    it('rejects invalid token', async () => {
      const res = await request(app)
        .get('/api/auth/me')
        .set('Authorization', 'Bearer badtoken');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/auth/forgot-password', () => {
    it('returns generic message regardless of whether email exists', async () => {
      const res = await request(app)
        .post('/api/auth/forgot-password')
        .send({ email: regularUser.email });
      expect(res.status).toBe(200);
      expect(res.body.message).toBeDefined();
    });

    it('returns same message for non-existent email', async () => {
      const res = await request(app)
        .post('/api/auth/forgot-password')
        .send({ email: 'ghost@nowhere.com' });
      expect(res.status).toBe(200);
      expect(res.body.message).toBeDefined();
    });

    it('rejects missing email', async () => {
      const res = await request(app).post('/api/auth/forgot-password').send({});
      expect(res.status).toBe(400);
    });
  });

  describe('POST /api/auth/reset-password', () => {
    it('rejects invalid token', async () => {
      const res = await request(app)
        .post('/api/auth/reset-password')
        .send({ token: 'fakefakefake', password: 'newpassword' });
      expect(res.status).toBe(400);
    });

    it('rejects short password', async () => {
      const res = await request(app)
        .post('/api/auth/reset-password')
        .send({ token: 'abc', password: '123' });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/6 characters/i);
    });
  });
});

export { userToken, adminToken, userId, regularUser, adminUser };
