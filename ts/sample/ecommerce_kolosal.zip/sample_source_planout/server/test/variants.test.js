import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let adminId;
let userToken;
let productId;
let variantId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Variants User', email: 'variantsuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;

  // Admin
  const adminReg = await request(app).post('/api/auth/register').send({
    name: 'Variants Admin', email: 'variantsadmin@test.com', password: 'password123',
  });
  adminId = adminReg.body.user.id;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'variantsadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Seed category + product
  const cat = db.prepare(
    "INSERT OR IGNORE INTO categories (name, slug) VALUES ('Variants Cat', 'variants-cat')"
  ).run();
  const catId = cat.lastInsertRowid ||
    db.prepare("SELECT id FROM categories WHERE slug='variants-cat'").get()?.id;
  const prod = db.prepare(
    `INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run('Variants Product', 'variants-product', 'Product for variants tests', 59.99, 75, catId, 'https://example.com/variants.jpg');
  productId = prod.lastInsertRowid;
});

describe('Variants API', () => {
  describe('GET /api/variants/:productId', () => {
    it('is publicly accessible', async () => {
      const res = await request(app).get(`/api/variants/${productId}`);
      expect(res.status).toBe(200);
    });

    it('returns variants array and grouped object for product with no variants', async () => {
      const res = await request(app).get(`/api/variants/${productId}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('variants');
      expect(res.body).toHaveProperty('grouped');
      expect(Array.isArray(res.body.variants)).toBe(true);
      expect(res.body.variants.length).toBe(0);
    });
  });

  describe('POST /api/variants/:productId', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .send({ group_name: 'Color', value: 'Red', price_modifier: 0 });
      expect(res.status).toBe(401);
    });

    it('requires admin → 403 for regular user', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ group_name: 'Color', value: 'Red', price_modifier: 0 });
      expect(res.status).toBe(403);
    });

    it('returns 400 when group_name is missing', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 'Red', price_modifier: 0 });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('returns 400 when value is missing', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ group_name: 'Color', price_modifier: 0 });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('admin creates variant → 201 with product_id, group_name, value', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ group_name: 'Color', value: 'Midnight Black', price_modifier: 0 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('product_id', productId);
      expect(res.body).toHaveProperty('group_name', 'Color');
      expect(res.body).toHaveProperty('value', 'Midnight Black');
      expect(res.body).toHaveProperty('price_modifier', 0);
      variantId = res.body.id;
    });

    it('admin creates variant with price_modifier → 201', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ group_name: 'Color', value: 'Rose Gold', price_modifier: 10.00 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('price_modifier', 10);
    });

    it('admin creates variant in a different group → 201', async () => {
      const res = await request(app)
        .post(`/api/variants/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ group_name: 'Size', value: 'Large', price_modifier: 5.00 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('group_name', 'Size');
    });
  });

  describe('GET /api/variants/:productId (after variants added)', () => {
    it('returns all variants and grouped by group_name', async () => {
      const res = await request(app).get(`/api/variants/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.variants)).toBe(true);
      expect(res.body.variants.length).toBeGreaterThanOrEqual(3);

      // grouped should have Color and Size keys
      expect(res.body.grouped).toHaveProperty('Color');
      expect(res.body.grouped).toHaveProperty('Size');
      expect(Array.isArray(res.body.grouped['Color'])).toBe(true);
      expect(Array.isArray(res.body.grouped['Size'])).toBe(true);
    });

    it('each variant has expected fields', async () => {
      const res = await request(app).get(`/api/variants/${productId}`);
      const v = res.body.variants[0];
      expect(v).toHaveProperty('id');
      expect(v).toHaveProperty('product_id');
      expect(v).toHaveProperty('group_name');
      expect(v).toHaveProperty('value');
      expect(v).toHaveProperty('price_modifier');
    });
  });

  describe('PUT /api/variants/:productId/:id', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .put(`/api/variants/${productId}/${variantId}`)
        .send({ value: 'Space Grey' });
      expect(res.status).toBe(401);
    });

    it('requires admin → 403 for regular user', async () => {
      const res = await request(app)
        .put(`/api/variants/${productId}/${variantId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ value: 'Space Grey' });
      expect(res.status).toBe(403);
    });

    it('returns 404 for nonexistent variant', async () => {
      const res = await request(app)
        .put(`/api/variants/${productId}/99999`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 'Space Grey' });
      expect(res.status).toBe(404);
    });

    it('admin updates variant value → 200 with updated data', async () => {
      const res = await request(app)
        .put(`/api/variants/${productId}/${variantId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 'Space Grey' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('value', 'Space Grey');
      expect(res.body).toHaveProperty('id', variantId);
    });

    it('admin updates price_modifier → 200 with new price_modifier', async () => {
      const res = await request(app)
        .put(`/api/variants/${productId}/${variantId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ price_modifier: 15.00 });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('price_modifier', 15);
    });
  });

  describe('DELETE /api/variants/:productId/:id', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .delete(`/api/variants/${productId}/${variantId}`);
      expect(res.status).toBe(401);
    });

    it('requires admin → 403 for regular user', async () => {
      const res = await request(app)
        .delete(`/api/variants/${productId}/${variantId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('admin removes variant → 200 with success', async () => {
      const res = await request(app)
        .delete(`/api/variants/${productId}/${variantId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('success', true);
    });

    it('variant is no longer returned after deletion', async () => {
      const res = await request(app).get(`/api/variants/${productId}`);
      expect(res.status).toBe(200);
      expect(res.body.variants.some(v => v.id === variantId)).toBe(false);
    });
  });
});
