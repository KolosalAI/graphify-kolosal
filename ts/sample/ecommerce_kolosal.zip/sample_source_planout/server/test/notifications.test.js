import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let token;
let userId;
let notificationId;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({
    name: 'Notif User', email: 'notifuser@test.com', password: 'password123',
  });
  token = res.body.token;
  userId = res.body.user.id;

  // Seed two notifications
  const n1 = db.prepare(
    "INSERT INTO notifications (user_id, type, title, body) VALUES (?, ?, ?, ?)"
  ).run(userId, 'order', 'Order Shipped', 'Your order is on the way!');
  notificationId = n1.lastInsertRowid;

  db.prepare(
    "INSERT INTO notifications (user_id, type, title, body) VALUES (?, ?, ?, ?)"
  ).run(userId, 'promo', 'Weekend Sale', 'Big discounts this weekend!');
});

describe('Notifications API', () => {
  describe('GET /api/notifications', () => {
    it('returns notifications and unread count', async () => {
      const res = await request(app)
        .get('/api/notifications')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('notifications');
      expect(res.body).toHaveProperty('unreadCount');
      expect(Array.isArray(res.body.notifications)).toBe(true);
      expect(res.body.notifications.length).toBeGreaterThanOrEqual(2);
      expect(res.body.unreadCount).toBeGreaterThanOrEqual(2);
    });

    it('respects unread_only filter', async () => {
      const res = await request(app)
        .get('/api/notifications?unread_only=true')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      res.body.notifications.forEach(n => expect(n.read).toBe(0));
    });

    it('respects limit query param', async () => {
      const res = await request(app)
        .get('/api/notifications?limit=1')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.notifications.length).toBeLessThanOrEqual(1);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/notifications');
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/notifications/:id/read', () => {
    it('marks a single notification as read', async () => {
      const res = await request(app)
        .patch(`/api/notifications/${notificationId}/read`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);

      // Verify it's marked read
      const n = db.prepare('SELECT read FROM notifications WHERE id = ?').get(notificationId);
      expect(n.read).toBe(1);
    });

    it('requires authentication', async () => {
      const res = await request(app).patch(`/api/notifications/${notificationId}/read`);
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/notifications/read-all', () => {
    it('marks all notifications as read', async () => {
      const res = await request(app)
        .patch('/api/notifications/read-all')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);

      // Verify unread count is now 0
      const check = await request(app)
        .get('/api/notifications')
        .set('Authorization', `Bearer ${token}`);
      expect(check.body.unreadCount).toBe(0);
    });

    it('requires authentication', async () => {
      const res = await request(app).patch('/api/notifications/read-all');
      expect(res.status).toBe(401);
    });
  });

  describe('DELETE /api/notifications/:id', () => {
    it('deletes a notification', async () => {
      const res = await request(app)
        .delete(`/api/notifications/${notificationId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);

      // Verify it's gone from DB
      const n = db.prepare('SELECT id FROM notifications WHERE id = ?').get(notificationId);
      expect(n).toBeUndefined();
    });

    it('is idempotent (deleting again still returns 200)', async () => {
      const res = await request(app)
        .delete(`/api/notifications/${notificationId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });

    it('requires authentication', async () => {
      const res = await request(app).delete(`/api/notifications/${notificationId}`);
      expect(res.status).toBe(401);
    });
  });
});
