import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let adminId;
let userToken;
let productId;
let specId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Specs User', email: 'specsuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;

  // Admin
  const adminReg = await request(app).post('/api/auth/register').send({
    name: 'Specs Admin', email: 'specsadmin@test.com', password: 'password123',
  });
  adminId = adminReg.body.user.id;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'specsadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Seed category + product
  const cat = db.prepare(
    "INSERT OR IGNORE INTO categories (name, slug) VALUES ('Specs Cat', 'specs-cat')"
  ).run();
  const catId = cat.lastInsertRowid ||
    db.prepare("SELECT id FROM categories WHERE slug='specs-cat'").get()?.id;
  const prod = db.prepare(
    `INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run('Specs Product', 'specs-product', 'Product for specs tests', 79.99, 25, catId, 'https://example.com/specs.jpg');
  productId = prod.lastInsertRowid;
});

describe('Specs API', () => {
  describe('GET /api/specs/:productId', () => {
    it('is publicly accessible', async () => {
      const res = await request(app).get(`/api/specs/${productId}`);
      expect(res.status).toBe(200);
    });

    it('returns empty array for product with no specs', async () => {
      const res = await request(app).get(`/api/specs/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });
  });

  describe('POST /api/specs/:productId', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .post(`/api/specs/${productId}`)
        .send({ spec_key: 'Color', spec_value: 'Red' });
      expect(res.status).toBe(401);
    });

    it('requires admin → 403 for regular user', async () => {
      const res = await request(app)
        .post(`/api/specs/${productId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ spec_key: 'Color', spec_value: 'Red' });
      expect(res.status).toBe(403);
    });

    it('returns 400 when spec_key is missing', async () => {
      const res = await request(app)
        .post(`/api/specs/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_value: 'Red' });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('returns 400 when spec_value is missing', async () => {
      const res = await request(app)
        .post(`/api/specs/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_key: 'Color' });
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('admin creates spec → 201 with spec_key and spec_value', async () => {
      const res = await request(app)
        .post(`/api/specs/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_key: 'Color', spec_value: 'Midnight Black' });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('spec_key', 'Color');
      expect(res.body).toHaveProperty('spec_value', 'Midnight Black');
      expect(res.body).toHaveProperty('product_id', productId);
      specId = res.body.id;
    });

    it('admin can create multiple specs for the same product', async () => {
      const res = await request(app)
        .post(`/api/specs/${productId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_key: 'Weight', spec_value: '1.2 kg', sort_order: 1 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('spec_key', 'Weight');
    });
  });

  describe('GET /api/specs/:productId (after specs added)', () => {
    it('returns all specs for product', async () => {
      const res = await request(app).get(`/api/specs/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBeGreaterThanOrEqual(2);
      expect(res.body.some(s => s.spec_key === 'Color')).toBe(true);
    });
  });

  describe('PUT /api/specs/:productId/:id', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .put(`/api/specs/${productId}/${specId}`)
        .send({ spec_value: 'Ocean Blue' });
      expect(res.status).toBe(401);
    });

    it('requires admin → 403 for regular user', async () => {
      const res = await request(app)
        .put(`/api/specs/${productId}/${specId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ spec_value: 'Ocean Blue' });
      expect(res.status).toBe(403);
    });

    it('returns 404 for nonexistent spec', async () => {
      const res = await request(app)
        .put(`/api/specs/${productId}/99999`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_value: 'Ocean Blue' });
      expect(res.status).toBe(404);
    });

    it('admin updates spec → 200 with updated value', async () => {
      const res = await request(app)
        .put(`/api/specs/${productId}/${specId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_value: 'Ocean Blue' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('spec_value', 'Ocean Blue');
      expect(res.body).toHaveProperty('spec_key', 'Color');
    });

    it('admin updates spec_key → 200 with updated key', async () => {
      const res = await request(app)
        .put(`/api/specs/${productId}/${specId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ spec_key: 'Colour', spec_value: 'Ocean Blue' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('spec_key', 'Colour');
    });
  });

  describe('DELETE /api/specs/:productId/:id', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .delete(`/api/specs/${productId}/${specId}`);
      expect(res.status).toBe(401);
    });

    it('requires admin → 403 for regular user', async () => {
      const res = await request(app)
        .delete(`/api/specs/${productId}/${specId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('admin removes spec → 200 with success', async () => {
      const res = await request(app)
        .delete(`/api/specs/${productId}/${specId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('success', true);
    });

    it('spec is no longer returned after deletion', async () => {
      const res = await request(app).get(`/api/specs/${productId}`);
      expect(res.status).toBe(200);
      expect(res.body.some(s => s.id === specId)).toBe(false);
    });
  });
});
