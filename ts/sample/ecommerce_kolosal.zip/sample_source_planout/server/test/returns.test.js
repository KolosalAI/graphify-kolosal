import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let userId;
let adminToken;
let deliveredOrderId;
let orderItemId;
let returnId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Returns User', email: 'returnsuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;
  userId = userRes.body.user.id;

  // Admin user
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Returns Admin', email: 'returnsadmin@test.com', password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'returnsadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Seed category and product for the order
  db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Returns Cat', 'returns-cat')").run();
  const catId = db.prepare("SELECT id FROM categories WHERE slug='returns-cat'").get()?.id;
  const prod = db.prepare(
    "INSERT INTO products (name, slug, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?)"
  ).run('Returns Product', 'returns-product', 30.00, 100, catId, 'https://example.com/rr.jpg');
  const productId = prod.lastInsertRowid;

  // Create delivered order for user
  const ord = db.prepare(
    "INSERT INTO orders (user_id, customer_name, customer_email, shipping_address, subtotal, total, status) VALUES (?, ?, ?, ?, ?, ?, 'delivered')"
  ).run(userId, 'Returns User', 'returnsuser@test.com', '99 Return Rd', 30.00, 30.00);
  deliveredOrderId = ord.lastInsertRowid;

  const oi = db.prepare(
    "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, 1, 30.00)"
  ).run(deliveredOrderId, productId);
  orderItemId = oi.lastInsertRowid;
});

describe('Returns API', () => {
  describe('GET /api/returns', () => {
    it('returns empty array initially', async () => {
      const res = await request(app)
        .get('/api/returns')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/returns');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/returns', () => {
    it('creates a return request for a delivered order', async () => {
      const res = await request(app)
        .post('/api/returns')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          order_id: deliveredOrderId,
          reason: 'Item is defective',
          items: [{ order_item_id: orderItemId, quantity: 1 }],
        });
      expect(res.status).toBe(201);
      expect(res.body.order_id).toBe(deliveredOrderId);
      expect(res.body.reason).toBe('Item is defective');
      expect(res.body.status).toBe('pending');
      returnId = res.body.id;
    });

    it('prevents duplicate return for same order', async () => {
      const res = await request(app)
        .post('/api/returns')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          order_id: deliveredOrderId,
          reason: 'Another reason',
          items: [{ order_item_id: orderItemId, quantity: 1 }],
        });
      expect(res.status).toBe(400);
    });

    it('returns 400 when order_id is missing', async () => {
      const res = await request(app)
        .post('/api/returns')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ reason: 'No order', items: [{ order_item_id: orderItemId, quantity: 1 }] });
      expect(res.status).toBe(400);
    });

    it('returns 400 when reason is missing', async () => {
      const res = await request(app)
        .post('/api/returns')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ order_id: deliveredOrderId, items: [{ order_item_id: orderItemId, quantity: 1 }] });
      expect(res.status).toBe(400);
    });

    it('returns 400 when items array is empty or missing', async () => {
      const res = await request(app)
        .post('/api/returns')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ order_id: deliveredOrderId, reason: 'No items', items: [] });
      expect(res.status).toBe(400);
    });

    it('returns 404 for non-existent order', async () => {
      const res = await request(app)
        .post('/api/returns')
        .set('Authorization', `Bearer ${userToken}`)
        .send({
          order_id: 999999,
          reason: 'Ghost order',
          items: [{ order_item_id: 1, quantity: 1 }],
        });
      expect(res.status).toBe(404);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .post('/api/returns')
        .send({ order_id: deliveredOrderId, reason: 'Anon return', items: [{ order_item_id: orderItemId, quantity: 1 }] });
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/returns (after creating return)', () => {
    it('returns user own return requests with items', async () => {
      const res = await request(app)
        .get('/api/returns')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body.length).toBe(1);
      expect(res.body[0].id).toBe(returnId);
      expect(Array.isArray(res.body[0].items)).toBe(true);
    });
  });

  describe('GET /api/returns/admin', () => {
    it('returns all returns for admin', async () => {
      const res = await request(app)
        .get('/api/returns/admin')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(r => r.id === returnId)).toBe(true);
    });

    it('supports status filter', async () => {
      const res = await request(app)
        .get('/api/returns/admin?status=pending')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      res.body.forEach(r => expect(r.status).toBe('pending'));
    });

    it('blocks non-admin (returns 403)', async () => {
      const res = await request(app)
        .get('/api/returns/admin')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/returns/admin');
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/returns/:id', () => {
    it('allows admin to approve a return', async () => {
      const res = await request(app)
        .patch(`/api/returns/${returnId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'approved', admin_notes: 'Approved, refund issued.' });
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('approved');
    });

    it('returns 400 for invalid status', async () => {
      const res = await request(app)
        .patch(`/api/returns/${returnId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'pending' });
      expect(res.status).toBe(400);
    });

    it('returns 404 for unknown return', async () => {
      const res = await request(app)
        .patch('/api/returns/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'rejected' });
      expect(res.status).toBe(404);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .patch(`/api/returns/${returnId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ status: 'rejected' });
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .patch(`/api/returns/${returnId}`)
        .send({ status: 'rejected' });
      expect(res.status).toBe(401);
    });
  });
});
