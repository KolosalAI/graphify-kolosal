import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let sellerToken;
let adminToken;
let buyerToken;
let sellerId;
let sellerProductId;
let buyerUserId;
let deliveredOrderId;
let sellerCatId;

beforeAll(async () => {
  // Regular user (will apply as seller)
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Seller Applicant', email: 'sellerapplicant@test.com', password: 'password123',
  });
  userToken = userRes.body.token;

  // Admin user
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Seller Admin', email: 'selleradmin@test.com', password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'selleradmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Approved seller
  const sellerRes = await request(app).post('/api/auth/register').send({
    name: 'Test Seller', email: 'testseller@test.com', password: 'password123',
  });
  const sellerUserId = sellerRes.body.user.id;
  db.prepare("UPDATE users SET role = 'seller' WHERE id = ?").run(sellerUserId);
  db.prepare("INSERT OR IGNORE INTO sellers (user_id, store_name, description, status) VALUES (?, ?, ?, 'approved')").run(sellerUserId, 'Test Store', 'A test store');
  sellerId = db.prepare("SELECT id FROM sellers WHERE user_id = ?").get(sellerUserId)?.id;
  const sellerLogin = await request(app).post('/api/auth/login').send({
    email: 'testseller@test.com', password: 'password123',
  });
  sellerToken = sellerLogin.body.token;

  // Seed category and seller product
  const cat = db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Seller Cat', 'seller-cat')").run();
  sellerCatId = cat.lastInsertRowid || db.prepare("SELECT id FROM categories WHERE slug='seller-cat'").get()?.id;

  const prod = db.prepare(
    "INSERT INTO products (name, slug, description, price, stock, category_id, image_url, seller_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  ).run('Seller Widget', 'seller-widget', 'A seller product', 45.00, 30, sellerCatId, 'https://example.com/sw.jpg', sellerId);
  sellerProductId = prod.lastInsertRowid;

  // Buyer user with a delivered order containing the seller's product (for rating)
  const buyerRes = await request(app).post('/api/auth/register').send({
    name: 'Seller Buyer', email: 'sellerbuyer@test.com', password: 'password123',
  });
  buyerToken = buyerRes.body.token;
  buyerUserId = buyerRes.body.user.id;

  const ord = db.prepare(
    "INSERT INTO orders (user_id, customer_name, customer_email, shipping_address, subtotal, total, status) VALUES (?, ?, ?, ?, ?, ?, 'delivered')"
  ).run(buyerUserId, 'Seller Buyer', 'sellerbuyer@test.com', '5 Buy St', 45.00, 45.00);
  deliveredOrderId = ord.lastInsertRowid;
  db.prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, 1, 45.00)").run(deliveredOrderId, sellerProductId);
});

// ── Apply ─────────────────────────────────────────────────────────────────────

describe('POST /api/sellers/apply', () => {
  it('allows user to apply as seller', async () => {
    const res = await request(app)
      .post('/api/sellers/apply')
      .set('Authorization', `Bearer ${userToken}`)
      .send({ store_name: 'My New Store', description: 'Selling stuff' });
    expect(res.status).toBe(201);
    expect(res.body.store_name).toBe('My New Store');
  });

  it('rejects duplicate application from same user', async () => {
    const res = await request(app)
      .post('/api/sellers/apply')
      .set('Authorization', `Bearer ${userToken}`)
      .send({ store_name: 'Another Store' });
    expect(res.status).toBe(400);
  });

  it('requires store_name', async () => {
    const noStoreRes = await request(app).post('/api/auth/register').send({
      name: 'No Store', email: 'nostore@test.com', password: 'password123',
    });
    const res = await request(app)
      .post('/api/sellers/apply')
      .set('Authorization', `Bearer ${noStoreRes.body.token}`)
      .send({});
    expect(res.status).toBe(400);
  });

  it('requires authentication', async () => {
    const res = await request(app).post('/api/sellers/apply').send({ store_name: 'Ghost Store' });
    expect(res.status).toBe(401);
  });
});

// ── Seller's own products ─────────────────────────────────────────────────────

describe('Seller Products API', () => {
  let newSellerProductId;

  describe('GET /api/sellers/me/products', () => {
    it('returns seller products list', async () => {
      const res = await request(app)
        .get('/api/sellers/me/products')
        .set('Authorization', `Bearer ${sellerToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(p => p.name === 'Seller Widget')).toBe(true);
    });

    it('blocks non-seller (unapproved)', async () => {
      const res = await request(app)
        .get('/api/sellers/me/products')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/sellers/me/products');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/sellers/me/products', () => {
    it('creates a product for the seller', async () => {
      const res = await request(app)
        .post('/api/sellers/me/products')
        .set('Authorization', `Bearer ${sellerToken}`)
        .send({
          name: 'New Seller Item',
          price: 19.99,
          stock: 50,
          category_id: sellerCatId,
          image_url: 'https://example.com/nsi.jpg',
        });
      expect(res.status).toBe(201);
      expect(res.body.name).toBe('New Seller Item');
      expect(res.body.seller_id).toBe(sellerId);
      newSellerProductId = res.body.id;
    });

    it('returns 400 when required fields are missing', async () => {
      const res = await request(app)
        .post('/api/sellers/me/products')
        .set('Authorization', `Bearer ${sellerToken}`)
        .send({ name: 'Missing Price' });
      expect(res.status).toBe(400);
    });

    it('blocks unapproved user from creating product', async () => {
      const res = await request(app)
        .post('/api/sellers/me/products')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Sneak Product', price: 5, stock: 1 });
      expect(res.status).toBe(403);
    });
  });

  describe('PUT /api/sellers/me/products/:id', () => {
    it('updates own product', async () => {
      const res = await request(app)
        .put(`/api/sellers/me/products/${newSellerProductId}`)
        .set('Authorization', `Bearer ${sellerToken}`)
        .send({ name: 'Updated Seller Item', price: 24.99, stock: 40 });
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Updated Seller Item');
    });

    it('returns 404 for product not owned by seller', async () => {
      const res = await request(app)
        .put('/api/sellers/me/products/999999')
        .set('Authorization', `Bearer ${sellerToken}`)
        .send({ name: 'Ghost Product' });
      expect(res.status).toBe(404);
    });

    it('blocks non-seller', async () => {
      const res = await request(app)
        .put(`/api/sellers/me/products/${newSellerProductId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Hijacked Product' });
      expect(res.status).toBe(403);
    });
  });

  describe('DELETE /api/sellers/me/products/:id', () => {
    it('deletes own product', async () => {
      const res = await request(app)
        .delete(`/api/sellers/me/products/${newSellerProductId}`)
        .set('Authorization', `Bearer ${sellerToken}`);
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('returns 404 for unknown product', async () => {
      const res = await request(app)
        .delete('/api/sellers/me/products/999999')
        .set('Authorization', `Bearer ${sellerToken}`);
      expect(res.status).toBe(404);
    });
  });
});

// ── Seller dashboard & analytics ──────────────────────────────────────────────

describe('GET /api/sellers/me/dashboard', () => {
  it('returns seller dashboard info', async () => {
    const res = await request(app)
      .get('/api/sellers/me/dashboard')
      .set('Authorization', `Bearer ${sellerToken}`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('seller');
    expect(res.body).toHaveProperty('totalProducts');
    expect(res.body).toHaveProperty('totalOrders');
    expect(res.body).toHaveProperty('totalRevenue');
  });

  it('blocks non-seller', async () => {
    const res = await request(app)
      .get('/api/sellers/me/dashboard')
      .set('Authorization', `Bearer ${userToken}`);
    expect(res.status).toBe(403);
  });
});

describe('GET /api/sellers/me/analytics', () => {
  it('returns analytics with daily and monthly data', async () => {
    const res = await request(app)
      .get('/api/sellers/me/analytics')
      .set('Authorization', `Bearer ${sellerToken}`);
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('daily');
    expect(res.body).toHaveProperty('monthly');
  });

  it('requires authentication', async () => {
    const res = await request(app).get('/api/sellers/me/analytics');
    expect(res.status).toBe(401);
  });
});

describe('GET /api/sellers/me/orders', () => {
  it('returns orders containing seller products', async () => {
    const res = await request(app)
      .get('/api/sellers/me/orders')
      .set('Authorization', `Bearer ${sellerToken}`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    // The delivered order from our buyer should appear
    const foundOrder = res.body.find(o => o.id === deliveredOrderId);
    expect(foundOrder).toBeDefined();
    expect(Array.isArray(foundOrder.items)).toBe(true);
  });

  it('requires authentication', async () => {
    const res = await request(app).get('/api/sellers/me/orders');
    expect(res.status).toBe(401);
  });
});

// ── Public storefront ─────────────────────────────────────────────────────────

describe('GET /api/sellers/:id', () => {
  it('returns seller storefront by id', async () => {
    const res = await request(app).get(`/api/sellers/${sellerId}`);
    expect(res.status).toBe(200);
    expect(res.body.store_name).toBe('Test Store');
  });

  it('returns 404 for unknown seller', async () => {
    const res = await request(app).get('/api/sellers/999999');
    expect(res.status).toBe(404);
  });
});

describe('GET /api/sellers/:id/products', () => {
  it("returns seller's products publicly", async () => {
    const res = await request(app).get(`/api/sellers/${sellerId}/products`);
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.some(p => p.name === 'Seller Widget')).toBe(true);
  });

  it('returns 404 for unknown seller', async () => {
    const res = await request(app).get('/api/sellers/999999/products');
    expect(res.status).toBe(404);
  });
});

// ── Rating ────────────────────────────────────────────────────────────────────

describe('POST /api/sellers/:sellerId/rate', () => {
  it('rates a seller on a delivered order', async () => {
    const res = await request(app)
      .post(`/api/sellers/${sellerId}/rate`)
      .set('Authorization', `Bearer ${buyerToken}`)
      .send({ order_id: deliveredOrderId, rating: 4, review: 'Great seller!' });
    expect(res.status).toBe(201);
    expect(res.body.rating).toBe(4);
  });

  it('prevents rating the same seller twice for the same order', async () => {
    const res = await request(app)
      .post(`/api/sellers/${sellerId}/rate`)
      .set('Authorization', `Bearer ${buyerToken}`)
      .send({ order_id: deliveredOrderId, rating: 5 });
    expect(res.status).toBe(400);
  });

  it('returns 400 for rating out of range', async () => {
    const res = await request(app)
      .post(`/api/sellers/${sellerId}/rate`)
      .set('Authorization', `Bearer ${userToken}`)
      .send({ order_id: deliveredOrderId, rating: 10 });
    expect(res.status).toBe(400);
  });

  it('returns 400 when order_id is missing', async () => {
    const res = await request(app)
      .post(`/api/sellers/${sellerId}/rate`)
      .set('Authorization', `Bearer ${buyerToken}`)
      .send({ rating: 3 });
    expect(res.status).toBe(400);
  });

  it('requires authentication', async () => {
    const res = await request(app)
      .post(`/api/sellers/${sellerId}/rate`)
      .send({ order_id: deliveredOrderId, rating: 4 });
    expect(res.status).toBe(401);
  });
});

// ── Admin seller management ───────────────────────────────────────────────────

describe('Admin Sellers API', () => {
  describe('GET /api/sellers/admin/all', () => {
    it('allows admin to list all seller applications', async () => {
      const res = await request(app)
        .get('/api/sellers/admin/all')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(s => s.store_name === 'Test Store')).toBe(true);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .get('/api/sellers/admin/all')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/sellers/admin/all');
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/sellers/admin/:id/status', () => {
    it('allows admin to update seller status to approved', async () => {
      const res = await request(app)
        .patch(`/api/sellers/admin/${sellerId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'approved' });
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('approved');
    });

    it('allows admin to suspend a seller', async () => {
      const res = await request(app)
        .patch(`/api/sellers/admin/${sellerId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'suspended' });
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('suspended');

      // Restore for downstream tests
      db.prepare("UPDATE sellers SET status = 'approved' WHERE id = ?").run(sellerId);
      db.prepare("UPDATE users SET role = 'seller' WHERE id = (SELECT user_id FROM sellers WHERE id = ?)").run(sellerId);
    });

    it('sets user role to seller when status is approved', async () => {
      // Register a fresh user, have them apply, then approve
      const newUserRes = await request(app).post('/api/auth/register').send({
        name: 'Role Test Seller', email: 'roletestseller@test.com', password: 'password123',
      });
      const newUserToken = newUserRes.body.token;
      const applyRes = await request(app)
        .post('/api/sellers/apply')
        .set('Authorization', `Bearer ${newUserToken}`)
        .send({ store_name: 'Role Test Store' });
      const newSellerEntryId = applyRes.body.id;

      await request(app)
        .patch(`/api/sellers/admin/${newSellerEntryId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'approved' });

      const meRes = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${newUserToken}`);
      expect(meRes.body.role).toBe('seller');
    });

    it('resets user role to user when seller is suspended', async () => {
      // Register a fresh user, apply, approve, then suspend
      const newUserRes = await request(app).post('/api/auth/register').send({
        name: 'Suspend Role Test', email: 'suspendroletest@test.com', password: 'password123',
      });
      const newUserToken = newUserRes.body.token;
      const applyRes = await request(app)
        .post('/api/sellers/apply')
        .set('Authorization', `Bearer ${newUserToken}`)
        .send({ store_name: 'Suspend Role Store' });
      const newSellerEntryId = applyRes.body.id;

      await request(app)
        .patch(`/api/sellers/admin/${newSellerEntryId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'approved' });
      await request(app)
        .patch(`/api/sellers/admin/${newSellerEntryId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'suspended' });

      const meRes = await request(app)
        .get('/api/auth/me')
        .set('Authorization', `Bearer ${newUserToken}`);
      expect(meRes.body.role).toBe('user');
    });

    it('returns 400 for invalid status', async () => {
      const res = await request(app)
        .patch(`/api/sellers/admin/${sellerId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'rejected' });
      expect(res.status).toBe(400);
    });

    it('returns 404 for unknown seller', async () => {
      const res = await request(app)
        .patch('/api/sellers/admin/999999/status')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'approved' });
      expect(res.status).toBe(404);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .patch(`/api/sellers/admin/${sellerId}/status`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ status: 'approved' });
      expect(res.status).toBe(403);
    });
  });
});
