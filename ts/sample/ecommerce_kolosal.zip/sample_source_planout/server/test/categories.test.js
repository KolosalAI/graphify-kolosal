import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

beforeAll(() => {
  // Seed a known category so we can assert it appears in the list
  db.prepare("INSERT OR IGNORE INTO categories (name, slug, description) VALUES (?, ?, ?)").run(
    'Categories Test Cat', 'categories-test-cat', 'Category for test assertions'
  );
});

describe('Categories API', () => {
  describe('GET /api/categories', () => {
    it('returns an array of categories', async () => {
      const res = await request(app).get('/api/categories');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('includes seeded test category', async () => {
      const res = await request(app).get('/api/categories');
      expect(res.status).toBe(200);
      const found = res.body.find(c => c.slug === 'categories-test-cat');
      expect(found).toBeDefined();
      expect(found.name).toBe('Categories Test Cat');
    });

    it('includes product_count field on each category', async () => {
      const res = await request(app).get('/api/categories');
      expect(res.status).toBe(200);
      res.body.forEach(c => expect(c).toHaveProperty('product_count'));
    });

    it('does not require authentication', async () => {
      const res = await request(app).get('/api/categories');
      expect(res.status).not.toBe(401);
      expect(res.status).toBe(200);
    });

    it('results are ordered by name', async () => {
      const res = await request(app).get('/api/categories');
      expect(res.status).toBe(200);
      const names = res.body.map(c => c.name);
      const sorted = [...names].sort((a, b) => a.localeCompare(b));
      expect(names).toEqual(sorted);
    });
  });
});
