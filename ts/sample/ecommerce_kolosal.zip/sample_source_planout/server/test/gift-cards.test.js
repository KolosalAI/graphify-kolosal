import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let adminToken;
let userToken;
let giftCardCode;
let giftCardId;

beforeAll(async () => {
  // Register a regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'GC User',
    email: 'gcuser@test.com',
    password: 'password123',
  });
  userToken = userRes.body.token;

  // Register and promote admin
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'GC Admin',
    email: 'gcadmin@test.com',
    password: 'password123',
  });
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminRes.body.user.id);
  const loginRes = await request(app).post('/api/auth/login').send({
    email: 'gcadmin@test.com',
    password: 'password123',
  });
  adminToken = loginRes.body.token;

  // Pre-generate a gift card via the admin endpoint so subsequent check/redeem tests have a valid code
  const gcRes = await request(app)
    .post('/api/gift-cards/generate')
    .set('Authorization', `Bearer ${adminToken}`)
    .send({ value: 50 });
  giftCardCode = gcRes.body.code;
  giftCardId = gcRes.body.id;
});

describe('Gift Cards API', () => {
  describe('POST /api/gift-cards/check — public', () => {
    it('returns 400 when code is missing', async () => {
      const res = await request(app).post('/api/gift-cards/check').send({});
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/code/i);
    });

    it('returns 404 for an invalid or unknown code', async () => {
      const res = await request(app)
        .post('/api/gift-cards/check')
        .send({ code: 'GC-INVALID000' });
      expect(res.status).toBe(404);
    });

    it('returns 200 with balance info for a valid code', async () => {
      const res = await request(app)
        .post('/api/gift-cards/check')
        .send({ code: giftCardCode });
      expect(res.status).toBe(200);
      expect(res.body.code).toBe(giftCardCode);
      expect(res.body).toHaveProperty('balance');
      expect(res.body).toHaveProperty('original_value');
      expect(res.body.balance).toBe(50);
      expect(res.body.original_value).toBe(50);
    });

    it('is case-insensitive for the code', async () => {
      const res = await request(app)
        .post('/api/gift-cards/check')
        .send({ code: giftCardCode.toLowerCase() });
      expect(res.status).toBe(200);
      expect(res.body.code).toBe(giftCardCode);
    });

    it('returns 404 for an inactive gift card', async () => {
      // Deactivate the card
      db.prepare('UPDATE gift_cards SET active = 0 WHERE id = ?').run(giftCardId);

      const res = await request(app)
        .post('/api/gift-cards/check')
        .send({ code: giftCardCode });
      expect(res.status).toBe(404);

      // Re-activate for subsequent tests
      db.prepare('UPDATE gift_cards SET active = 1 WHERE id = ?').run(giftCardId);
    });

    it('returns 400 for a card with zero balance', async () => {
      // Drain the balance
      db.prepare('UPDATE gift_cards SET balance = 0 WHERE id = ?').run(giftCardId);

      const res = await request(app)
        .post('/api/gift-cards/check')
        .send({ code: giftCardCode });
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/balance/i);

      // Restore balance
      db.prepare('UPDATE gift_cards SET balance = 50 WHERE id = ?').run(giftCardId);
    });
  });

  describe('POST /api/gift-cards/redeem — public', () => {
    it('returns 400 when code is missing', async () => {
      const res = await request(app).post('/api/gift-cards/redeem').send({});
      expect(res.status).toBe(400);
    });

    it('returns 404 for an invalid code', async () => {
      const res = await request(app)
        .post('/api/gift-cards/redeem')
        .send({ code: 'GC-NOTEXIST' });
      expect(res.status).toBe(404);
    });

    it('returns 200 with gift card info for a valid code', async () => {
      const res = await request(app)
        .post('/api/gift-cards/redeem')
        .send({ code: giftCardCode });
      expect(res.status).toBe(200);
      expect(res.body.code).toBe(giftCardCode);
      expect(res.body.balance).toBeGreaterThan(0);
    });
  });

  describe('POST /api/gift-cards/generate — admin only', () => {
    it('creates a gift card and returns 201 with code and balance', async () => {
      const res = await request(app)
        .post('/api/gift-cards/generate')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 100 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('id');
      expect(res.body).toHaveProperty('code');
      expect(res.body.code).toMatch(/^GC-/);
      expect(res.body.balance).toBe(100);
      expect(res.body.original_value).toBe(100);
    });

    it('creates a gift card with an issued_to field', async () => {
      const res = await request(app)
        .post('/api/gift-cards/generate')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 25, issued_to: 'customer@example.com' });
      expect(res.status).toBe(201);
      expect(res.body.issued_to).toBe('customer@example.com');
    });

    it('returns 400 when value is missing', async () => {
      const res = await request(app)
        .post('/api/gift-cards/generate')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({});
      expect(res.status).toBe(400);
      expect(res.body.error).toMatch(/value/i);
    });

    it('returns 400 when value is zero or negative', async () => {
      const res = await request(app)
        .post('/api/gift-cards/generate')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 0 });
      expect(res.status).toBe(400);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .post('/api/gift-cards/generate')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ value: 50 });
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app)
        .post('/api/gift-cards/generate')
        .send({ value: 50 });
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/gift-cards — admin only', () => {
    it('returns all gift cards as an array', async () => {
      const res = await request(app)
        .get('/api/gift-cards')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBeGreaterThan(0);
    });

    it('each card has expected fields', async () => {
      const res = await request(app)
        .get('/api/gift-cards')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      const card = res.body[0];
      expect(card).toHaveProperty('id');
      expect(card).toHaveProperty('code');
      expect(card).toHaveProperty('balance');
      expect(card).toHaveProperty('original_value');
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .get('/api/gift-cards')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).get('/api/gift-cards');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/gift-cards — admin only (create route)', () => {
    it('creates a gift card and returns 201', async () => {
      const res = await request(app)
        .post('/api/gift-cards')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ value: 75 });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('code');
      expect(res.body.balance).toBe(75);
    });

    it('returns 400 when value is missing', async () => {
      const res = await request(app)
        .post('/api/gift-cards')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({});
      expect(res.status).toBe(400);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .post('/api/gift-cards')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ value: 50 });
      expect(res.status).toBe(403);
    });
  });

  describe('PATCH /api/gift-cards/:id/toggle — admin only', () => {
    it('toggles a gift card active status', async () => {
      const beforeRes = await request(app)
        .get('/api/gift-cards')
        .set('Authorization', `Bearer ${adminToken}`);
      const card = beforeRes.body.find(c => c.id === giftCardId);
      const originalActive = card.active;

      const res = await request(app)
        .patch(`/api/gift-cards/${giftCardId}/toggle`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body.active).toBe(originalActive ? 0 : 1);

      // Toggle back to original state
      await request(app)
        .patch(`/api/gift-cards/${giftCardId}/toggle`)
        .set('Authorization', `Bearer ${adminToken}`);
    });

    it('returns 404 for a nonexistent gift card', async () => {
      const res = await request(app)
        .patch('/api/gift-cards/999999/toggle')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('rejects non-admin with 403', async () => {
      const res = await request(app)
        .patch(`/api/gift-cards/${giftCardId}/toggle`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('rejects unauthenticated request with 401', async () => {
      const res = await request(app).patch(`/api/gift-cards/${giftCardId}/toggle`);
      expect(res.status).toBe(401);
    });
  });
});
