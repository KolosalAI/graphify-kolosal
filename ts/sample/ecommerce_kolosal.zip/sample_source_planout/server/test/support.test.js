import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let adminToken;
let ticketId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Support User', email: 'supportuser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;

  // Admin user
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Support Admin', email: 'supportadmin@test.com', password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'supportadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;
});

describe('Support Tickets API', () => {
  describe('GET /api/support', () => {
    it('returns empty array initially', async () => {
      const res = await request(app)
        .get('/api/support')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/support');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/support', () => {
    it('creates a support ticket', async () => {
      const res = await request(app)
        .post('/api/support')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ subject: 'Order issue', message: 'My order is missing.' });
      expect(res.status).toBe(201);
      expect(res.body.subject).toBe('Order issue');
      expect(res.body.status).toBe('open');
      expect(Array.isArray(res.body.messages)).toBe(true);
      expect(res.body.messages.length).toBe(1);
      ticketId = res.body.id;
    });

    it('returns 400 when subject is missing', async () => {
      const res = await request(app)
        .post('/api/support')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ message: 'No subject here' });
      expect(res.status).toBe(400);
    });

    it('returns 400 when message is missing', async () => {
      const res = await request(app)
        .post('/api/support')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ subject: 'No message here' });
      expect(res.status).toBe(400);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .post('/api/support')
        .send({ subject: 'Anon ticket', message: 'Hello?' });
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/support/:id', () => {
    it('returns a single ticket with messages', async () => {
      const res = await request(app)
        .get(`/api/support/${ticketId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body.id).toBe(ticketId);
      expect(res.body.subject).toBe('Order issue');
      expect(Array.isArray(res.body.messages)).toBe(true);
    });

    it('returns 404 for unknown ticket', async () => {
      const res = await request(app)
        .get('/api/support/999999')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(404);
    });

    it('blocks a different user from reading another user ticket', async () => {
      const otherRes = await request(app).post('/api/auth/register').send({
        name: 'Other Support User', email: 'othersupport@test.com', password: 'password123',
      });
      const res = await request(app)
        .get(`/api/support/${ticketId}`)
        .set('Authorization', `Bearer ${otherRes.body.token}`);
      expect(res.status).toBe(403);
    });

    it('allows admin to read any ticket', async () => {
      const res = await request(app)
        .get(`/api/support/${ticketId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    it('requires authentication', async () => {
      const res = await request(app).get(`/api/support/${ticketId}`);
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/support/:id/message', () => {
    it('sends a message on the ticket (user)', async () => {
      const res = await request(app)
        .post(`/api/support/${ticketId}/message`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ body: 'Still waiting for help.' });
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBeGreaterThanOrEqual(2);
    });

    it('sends a message as admin (sets ticket to in_progress)', async () => {
      const res = await request(app)
        .post(`/api/support/${ticketId}/message`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ body: 'We are looking into this.' });
      expect(res.status).toBe(200);

      // Ticket should now be in_progress
      const ticket = await request(app)
        .get(`/api/support/${ticketId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(ticket.body.status).toBe('in_progress');
    });

    it('returns 400 when message body is missing', async () => {
      const res = await request(app)
        .post(`/api/support/${ticketId}/message`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({});
      expect(res.status).toBe(400);
    });

    it('returns 404 for unknown ticket', async () => {
      const res = await request(app)
        .post('/api/support/999999/message')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ body: 'Hello?' });
      expect(res.status).toBe(404);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .post(`/api/support/${ticketId}/message`)
        .send({ body: 'Ghost' });
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/support/:id/status', () => {
    it('allows user to close their own ticket', async () => {
      const res = await request(app)
        .patch(`/api/support/${ticketId}/status`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ status: 'closed' });
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('closed');
    });

    it('allows admin to reopen ticket', async () => {
      const res = await request(app)
        .patch(`/api/support/${ticketId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'open' });
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('open');
    });

    it('returns 400 for invalid status', async () => {
      const res = await request(app)
        .patch(`/api/support/${ticketId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'resolved' });
      expect(res.status).toBe(400);
    });

    it('returns 404 for unknown ticket', async () => {
      const res = await request(app)
        .patch('/api/support/999999/status')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'closed' });
      expect(res.status).toBe(404);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .patch(`/api/support/${ticketId}/status`)
        .send({ status: 'closed' });
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/support/admin/all', () => {
    it('returns all tickets for admin', async () => {
      const res = await request(app)
        .get('/api/support/admin/all')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(t => t.subject === 'Order issue')).toBe(true);
    });

    it('supports status filter', async () => {
      const res = await request(app)
        .get('/api/support/admin/all?status=open')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      res.body.forEach(t => expect(t.status).toBe('open'));
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .get('/api/support/admin/all')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/support/admin/all');
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/support (after creating tickets)', () => {
    it('returns user own tickets list with messages', async () => {
      const res = await request(app)
        .get('/api/support')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body.length).toBeGreaterThan(0);
      const ticket = res.body.find(t => t.id === ticketId);
      expect(ticket).toBeDefined();
      expect(Array.isArray(ticket.messages)).toBe(true);
    });
  });
});
