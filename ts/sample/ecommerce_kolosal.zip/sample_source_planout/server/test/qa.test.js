import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let userId;
let adminToken;
let adminId;
let productId;
let questionId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'QA User', email: 'qauser@test.com', password: 'password123',
  });
  userToken = userRes.body.token;
  userId = userRes.body.user.id;

  // Second user (to test ownership constraints)
  const user2Res = await request(app).post('/api/auth/register').send({
    name: 'QA User Two', email: 'qauser2@test.com', password: 'password123',
  });
  // Store globally for later tests
  globalThis._qaUser2Token = user2Res.body.token;

  // Admin user
  const adminReg = await request(app).post('/api/auth/register').send({
    name: 'QA Admin', email: 'qaadmin@test.com', password: 'password123',
  });
  adminId = adminReg.body.user.id;
  db.prepare("UPDATE users SET role='admin' WHERE id=?").run(adminId);
  const adminLogin = await request(app).post('/api/auth/login').send({
    email: 'qaadmin@test.com', password: 'password123',
  });
  adminToken = adminLogin.body.token;

  // Seed category + product
  const cat = db.prepare(
    "INSERT OR IGNORE INTO categories (name, slug) VALUES ('QA Cat', 'qa-cat')"
  ).run();
  const catId = cat.lastInsertRowid ||
    db.prepare("SELECT id FROM categories WHERE slug='qa-cat'").get()?.id;
  const prod = db.prepare(
    `INSERT INTO products (name, slug, description, price, stock, category_id, image_url)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run('QA Product', 'qa-product', 'Product for Q&A tests', 49.99, 100, catId, 'https://example.com/qa.jpg');
  productId = prod.lastInsertRowid;
});

describe('Q&A API', () => {
  describe('GET /api/qa/:productId', () => {
    it('returns empty array for product with no questions', async () => {
      const res = await request(app).get(`/api/qa/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('is accessible without authentication', async () => {
      const res = await request(app).get(`/api/qa/${productId}`);
      expect(res.status).toBe(200);
    });
  });

  describe('POST /api/qa/:productId', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}`)
        .send({ question: 'Is this product waterproof?' });
      expect(res.status).toBe(401);
    });

    it('returns 400 when question text is missing', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({});
      expect(res.status).toBe(400);
    });

    it('returns 400 when question is empty string', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ question: '   ' });
      expect(res.status).toBe(400);
    });

    it('creates a question → 201 with question and asker_name', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ question: 'Is this product waterproof?' });
      expect(res.status).toBe(201);
      expect(res.body).toHaveProperty('question', 'Is this product waterproof?');
      expect(res.body).toHaveProperty('asker_name', 'QA User');
      questionId = res.body.id;
    });
  });

  describe('GET /api/qa/:productId (after question posted)', () => {
    it('returns the posted question in the array', async () => {
      const res = await request(app).get(`/api/qa/${productId}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.some(q => q.id === questionId)).toBe(true);
    });
  });

  describe('PATCH /api/qa/:productId/:id/answer', () => {
    it('returns 403 when a regular user tries to answer', async () => {
      const res = await request(app)
        .patch(`/api/qa/${productId}/${questionId}/answer`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ answer: 'Yes it is!' });
      expect(res.status).toBe(403);
    });

    it('returns 404 for nonexistent question', async () => {
      const res = await request(app)
        .patch(`/api/qa/${productId}/99999/answer`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ answer: 'Some answer' });
      expect(res.status).toBe(404);
    });

    it('returns 400 when answer text is missing', async () => {
      const res = await request(app)
        .patch(`/api/qa/${productId}/${questionId}/answer`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({});
      expect(res.status).toBe(400);
    });

    it('admin can answer a question → 200 with answer and answerer_name', async () => {
      const res = await request(app)
        .patch(`/api/qa/${productId}/${questionId}/answer`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ answer: 'Yes, this product is fully waterproof.' });
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('answer', 'Yes, this product is fully waterproof.');
      expect(res.body).toHaveProperty('answerer_name', 'QA Admin');
    });
  });

  describe('POST /api/qa/:productId/:id/helpful', () => {
    it('requires authentication → 401', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}/${questionId}/helpful`);
      expect(res.status).toBe(401);
    });

    it('marks a question helpful → 200 with helpful_count: 1', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}/${questionId}/helpful`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('helpful_count', 1);
    });

    it('returns 400 when marking helpful a second time (duplicate)', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}/${questionId}/helpful`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(400);
      expect(res.body).toHaveProperty('error');
    });

    it('another user can also mark helpful → helpful_count increments', async () => {
      const res = await request(app)
        .post(`/api/qa/${productId}/${questionId}/helpful`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body.helpful_count).toBeGreaterThanOrEqual(2);
    });
  });

  describe('DELETE /api/qa/:productId/:id', () => {
    let otherQuestionId;

    beforeAll(async () => {
      // Post a question as user2 to test ownership
      const res = await request(app)
        .post(`/api/qa/${productId}`)
        .set('Authorization', `Bearer ${globalThis._qaUser2Token}`)
        .send({ question: "Does it come with a manual?" });
      otherQuestionId = res.body.id;
    });

    it('requires authentication → 401', async () => {
      const res = await request(app)
        .delete(`/api/qa/${productId}/${questionId}`);
      expect(res.status).toBe(401);
    });

    it('returns 403 when non-owner tries to delete another user question', async () => {
      const res = await request(app)
        .delete(`/api/qa/${productId}/${otherQuestionId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('owner can delete their own question → 200', async () => {
      const res = await request(app)
        .delete(`/api/qa/${productId}/${questionId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('success', true);
    });

    it('returns 404 for already-deleted question', async () => {
      const res = await request(app)
        .delete(`/api/qa/${productId}/${questionId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(404);
    });

    it('admin can delete any question → 200', async () => {
      const res = await request(app)
        .delete(`/api/qa/${productId}/${otherQuestionId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('success', true);
    });
  });
});
