import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let userToken;
let adminToken;
let targetUserId;
let adminOrderId;
let adminCategoryId;
let adminProductId;

beforeAll(async () => {
  // Regular user
  const userRes = await request(app).post('/api/auth/register').send({
    name: 'Admin Target', email: 'admintarget@test.com', password: 'password123',
  });
  userToken = userRes.body.token;
  targetUserId = userRes.body.user.id;

  // Admin user
  const adminRes = await request(app).post('/api/auth/register').send({
    name: 'Super Admin', email: 'superadmin@test.com', password: 'password123',
  });
  const adminId = adminRes.body.user.id;
  db.prepare("UPDATE users SET role = 'admin' WHERE id = ?").run(adminId);
  const loginRes = await request(app).post('/api/auth/login').send({
    email: 'superadmin@test.com', password: 'password123',
  });
  adminToken = loginRes.body.token;

  // Create an order for order-status update tests
  const ord = db.prepare(
    "INSERT INTO orders (user_id, customer_name, customer_email, shipping_address, subtotal, total, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')"
  ).run(targetUserId, 'Admin Target', 'admintarget@test.com', '1 Admin St', 50.00, 50.00);
  adminOrderId = ord.lastInsertRowid;
});

// ── Categories ────────────────────────────────────────────────────────────────

describe('Admin Categories API', () => {
  describe('GET /api/admin/categories', () => {
    it('returns category list for admin', async () => {
      const res = await request(app)
        .get('/api/admin/categories')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .get('/api/admin/categories')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/admin/categories');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/admin/categories', () => {
    it('creates a category', async () => {
      const res = await request(app)
        .post('/api/admin/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Admin Test Cat', slug: 'admin-test-cat', description: 'For admin tests' });
      expect(res.status).toBe(201);
      expect(res.body.name).toBe('Admin Test Cat');
      adminCategoryId = res.body.id;
    });

    it('returns 409 on duplicate slug', async () => {
      const res = await request(app)
        .post('/api/admin/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Admin Test Cat Dupe', slug: 'admin-test-cat' });
      expect(res.status).toBe(409);
    });

    it('returns 400 when name/slug missing', async () => {
      const res = await request(app)
        .post('/api/admin/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'No Slug' });
      expect(res.status).toBe(400);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .post('/api/admin/categories')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Unauthorized Cat', slug: 'unauth-cat' });
      expect(res.status).toBe(403);
    });
  });

  describe('PUT /api/admin/categories/:id', () => {
    it('updates a category', async () => {
      const res = await request(app)
        .put(`/api/admin/categories/${adminCategoryId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Admin Test Cat Updated', slug: 'admin-test-cat', description: 'Updated' });
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Admin Test Cat Updated');
    });

    it('returns 404 for unknown category', async () => {
      const res = await request(app)
        .put('/api/admin/categories/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'X', slug: 'x' });
      expect(res.status).toBe(404);
    });
  });
});

// ── Products ──────────────────────────────────────────────────────────────────

describe('Admin Products API', () => {
  describe('GET /api/admin/products', () => {
    it('returns products with pagination for admin', async () => {
      const res = await request(app)
        .get('/api/admin/products')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('products');
      expect(res.body).toHaveProperty('pagination');
      expect(Array.isArray(res.body.products)).toBe(true);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .get('/api/admin/products')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/admin/products');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/admin/products', () => {
    it('creates a product', async () => {
      const res = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Admin New Product',
          slug: 'admin-new-prod',
          description: 'A test product',
          price: 29.99,
          stock: 100,
          category_id: adminCategoryId,
          image_url: 'https://example.com/admin-prod.jpg',
        });
      expect(res.status).toBe(201);
      expect(res.body.name).toBe('Admin New Product');
      expect(res.body.price).toBe(29.99);
      adminProductId = res.body.id;
    });

    it('returns 409 on duplicate slug', async () => {
      const res = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Dup Prod', slug: 'admin-new-prod', price: 10 });
      expect(res.status).toBe(409);
    });

    it('returns 400 when required fields are missing', async () => {
      const res = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ description: 'No name or price' });
      expect(res.status).toBe(400);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Sneak Prod', slug: 'sneak-prod', price: 5 });
      expect(res.status).toBe(403);
    });
  });

  describe('PUT /api/admin/products/:id', () => {
    it('updates a product', async () => {
      const res = await request(app)
        .put(`/api/admin/products/${adminProductId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({
          name: 'Admin Updated Product',
          slug: 'admin-new-prod',
          description: 'Updated desc',
          price: 39.99,
          stock: 80,
          category_id: adminCategoryId,
          image_url: 'https://example.com/admin-prod.jpg',
        });
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Admin Updated Product');
      expect(res.body.price).toBe(39.99);
    });

    it('returns 404 for unknown product', async () => {
      const res = await request(app)
        .put('/api/admin/products/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Ghost', slug: 'ghost', price: 1 });
      expect(res.status).toBe(404);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .put(`/api/admin/products/${adminProductId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ name: 'Hack', slug: 'hack', price: 1 });
      expect(res.status).toBe(403);
    });
  });

  describe('DELETE /api/admin/products/:id', () => {
    it('deletes a product', async () => {
      // Create a product specifically for deletion
      const createRes = await request(app)
        .post('/api/admin/products')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'To Delete Prod', slug: 'admin-delete-prod', price: 5, stock: 1, category_id: adminCategoryId, image_url: 'x' });
      const deleteId = createRes.body.id;

      const res = await request(app)
        .delete(`/api/admin/products/${deleteId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    it('returns 404 for unknown product', async () => {
      const res = await request(app)
        .delete('/api/admin/products/999999')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .delete(`/api/admin/products/${adminProductId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });

  describe('DELETE /api/admin/categories/:id', () => {
    it('deletes a category (and nulls product category_id)', async () => {
      // Create a temporary category to delete
      const catRes = await request(app)
        .post('/api/admin/categories')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ name: 'Temp Delete Cat', slug: 'temp-delete-cat' });
      const tempCatId = catRes.body.id;

      const res = await request(app)
        .delete(`/api/admin/categories/${tempCatId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    it('returns 404 for unknown category', async () => {
      const res = await request(app)
        .delete('/api/admin/categories/999999')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });
  });
});

// ── Orders ────────────────────────────────────────────────────────────────────

describe('Admin Orders API', () => {
  describe('GET /api/admin/orders', () => {
    it('returns all orders with pagination for admin', async () => {
      const res = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('orders');
      expect(res.body).toHaveProperty('pagination');
      expect(Array.isArray(res.body.orders)).toBe(true);
    });

    it('filters by status query param', async () => {
      const res = await request(app)
        .get('/api/admin/orders?status=pending')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      res.body.orders.forEach(o => expect(o.status).toBe('pending'));
    });

    it('blocks regular users', async () => {
      const res = await request(app)
        .get('/api/admin/orders')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/admin/orders');
      expect(res.status).toBe(401);
    });
  });

  describe('PUT /api/admin/orders/:id/status', () => {
    it('updates order status', async () => {
      const res = await request(app)
        .put(`/api/admin/orders/${adminOrderId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'confirmed' });
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('confirmed');
    });

    it('returns 400 for invalid status', async () => {
      const res = await request(app)
        .put(`/api/admin/orders/${adminOrderId}/status`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'flying' });
      expect(res.status).toBe(400);
    });

    it('returns 404 for unknown order', async () => {
      const res = await request(app)
        .put('/api/admin/orders/999999/status')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ status: 'shipped' });
      expect(res.status).toBe(404);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .put(`/api/admin/orders/${adminOrderId}/status`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ status: 'delivered' });
      expect(res.status).toBe(403);
    });
  });
});

// ── Stats & Analytics ─────────────────────────────────────────────────────────

describe('Admin Stats & Analytics API', () => {
  describe('GET /api/admin/stats', () => {
    it('returns stats object with expected keys', async () => {
      const res = await request(app)
        .get('/api/admin/stats')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('totalProducts');
      expect(res.body).toHaveProperty('totalOrders');
      expect(res.body).toHaveProperty('totalRevenue');
      expect(res.body).toHaveProperty('totalUsers');
      expect(Array.isArray(res.body.recentOrders)).toBe(true);
      expect(Array.isArray(res.body.ordersByStatus)).toBe(true);
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .get('/api/admin/stats')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });

  describe('GET /api/admin/analytics', () => {
    it('returns analytics data with expected keys', async () => {
      const res = await request(app)
        .get('/api/admin/analytics')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('dailyRevenue');
      expect(res.body).toHaveProperty('topProducts');
      expect(res.body).toHaveProperty('monthlyRevenue');
    });

    it('blocks non-admin', async () => {
      const res = await request(app)
        .get('/api/admin/analytics')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });
});

// ── User Management ───────────────────────────────────────────────────────────

describe('Admin Users API', () => {
  describe('GET /api/admin/users', () => {
    it('returns paginated user list for admin', async () => {
      const res = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body).toHaveProperty('users');
      expect(Array.isArray(res.body.users)).toBe(true);
    });

    it('supports search query', async () => {
      const res = await request(app)
        .get('/api/admin/users?search=Admin+Target')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
      expect(res.body.users.some(u => u.name === 'Admin Target')).toBe(true);
    });

    it('blocks regular users', async () => {
      const res = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/admin/users');
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/admin/users/:id', () => {
    it('allows admin to update user role', async () => {
      const res = await request(app)
        .patch(`/api/admin/users/${targetUserId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ role: 'seller' });
      expect(res.status).toBe(200);
      expect(res.body.role).toBe('seller');
    });

    it('allows admin to update subscription_plan', async () => {
      const res = await request(app)
        .patch(`/api/admin/users/${targetUserId}`)
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ subscription_plan: 'prime' });
      expect(res.status).toBe(200);
      expect(res.body.subscription_plan).toBe('prime');
    });

    it('returns 404 for unknown user', async () => {
      const res = await request(app)
        .patch('/api/admin/users/999999')
        .set('Authorization', `Bearer ${adminToken}`)
        .send({ role: 'customer' });
      expect(res.status).toBe(404);
    });

    it('blocks non-admin from updating users', async () => {
      const res = await request(app)
        .patch(`/api/admin/users/${targetUserId}`)
        .set('Authorization', `Bearer ${userToken}`)
        .send({ role: 'admin' });
      expect(res.status).toBe(403);
    });
  });

  describe('DELETE /api/admin/users/:id', () => {
    it('allows admin to delete a user', async () => {
      const reg = await request(app).post('/api/auth/register').send({
        name: 'To Delete', email: 'todelete@test.com', password: 'password123',
      });
      const deleteId = reg.body.user.id;
      const res = await request(app)
        .delete(`/api/admin/users/${deleteId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(200);
    });

    it('returns 400 when admin tries to delete own account', async () => {
      const meRes = await request(app)
        .get('/api/admin/users')
        .set('Authorization', `Bearer ${adminToken}`);
      const adminId = meRes.body.users.find(u => u.email === 'superadmin@test.com')?.id;

      const res = await request(app)
        .delete(`/api/admin/users/${adminId}`)
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(400);
    });

    it('returns 404 for unknown user', async () => {
      const res = await request(app)
        .delete('/api/admin/users/999999')
        .set('Authorization', `Bearer ${adminToken}`);
      expect(res.status).toBe(404);
    });

    it('blocks non-admin from deleting users', async () => {
      const res = await request(app)
        .delete(`/api/admin/users/${targetUserId}`)
        .set('Authorization', `Bearer ${userToken}`);
      expect(res.status).toBe(403);
    });
  });
});
