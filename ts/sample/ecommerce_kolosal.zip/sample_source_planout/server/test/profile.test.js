import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';

let token;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({
    name: 'Profile Tester', email: 'profiletest@test.com', password: 'password123',
  });
  token = res.body.token;
});

describe('Profile API', () => {
  describe('GET /api/profile', () => {
    it('returns user profile', async () => {
      const res = await request(app)
        .get('/api/profile')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.email).toBe('profiletest@test.com');
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/profile');
      expect(res.status).toBe(401);
    });
  });

  describe('PUT /api/profile', () => {
    it('updates display name', async () => {
      const res = await request(app)
        .put('/api/profile')
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'Updated Name', email: 'profiletest@test.com' });
      expect(res.status).toBe(200);
      expect(res.body.name).toBe('Updated Name');
    });
  });

  describe('PUT /api/profile/password', () => {
    it('changes password with correct current password', async () => {
      const res = await request(app)
        .put('/api/profile/password')
        .set('Authorization', `Bearer ${token}`)
        .send({ current_password: 'password123', new_password: 'newpass456' });
      expect(res.status).toBe(200);
    });

    it('rejects wrong current password', async () => {
      const res = await request(app)
        .put('/api/profile/password')
        .set('Authorization', `Bearer ${token}`)
        .send({ current_password: 'wrongpassword', new_password: 'newpass789' });
      expect(res.status).toBe(401);
    });

    it('rejects short new password', async () => {
      const res = await request(app)
        .put('/api/profile/password')
        .set('Authorization', `Bearer ${token}`)
        .send({ current_password: 'newpass456', new_password: '123' });
      expect(res.status).toBe(400);
    });
  });
});

describe('Notifications API', () => {
  describe('GET /api/notifications', () => {
    it('returns notifications list', async () => {
      const res = await request(app)
        .get('/api/notifications')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body.notifications)).toBe(true);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/notifications');
      expect(res.status).toBe(401);
    });
  });
});

describe('Subscriptions API', () => {
  describe('GET /api/subscriptions/plans', () => {
    it('returns subscription plans', async () => {
      const res = await request(app).get('/api/subscriptions/plans');
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});

describe('Loyalty API', () => {
  describe('GET /api/loyalty', () => {
    it('returns loyalty points info', async () => {
      const res = await request(app)
        .get('/api/loyalty')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/loyalty');
      expect(res.status).toBe(401);
    });
  });
});

describe('Support API', () => {
  describe('POST /api/support', () => {
    it('creates a support ticket', async () => {
      const res = await request(app)
        .post('/api/support')
        .set('Authorization', `Bearer ${token}`)
        .send({ subject: 'Test Issue', message: 'Something is broken', category: 'general' });
      expect(res.status).toBe(201);
    });

    it('requires authentication', async () => {
      const res = await request(app)
        .post('/api/support')
        .send({ subject: 'X', message: 'Y' });
      expect(res.status).toBe(401);
    });
  });

  describe('GET /api/support', () => {
    it('returns user support tickets', async () => {
      const res = await request(app)
        .get('/api/support')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
    });
  });
});
