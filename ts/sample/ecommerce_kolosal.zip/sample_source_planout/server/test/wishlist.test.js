import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import app from '../src/app.js';
import db from '../src/db/index.js';

let token;
let userId;
let productId;

beforeAll(async () => {
  const res = await request(app).post('/api/auth/register').send({
    name: 'Wishlist Tester', email: 'wishtest@test.com', password: 'password123',
  });
  token = res.body.token;
  userId = res.body.user.id;

  const cat = db.prepare("INSERT OR IGNORE INTO categories (name, slug) VALUES ('Wish Cat', 'wish-cat')").run();
  const catId = cat.lastInsertRowid || db.prepare("SELECT id FROM categories WHERE slug='wish-cat'").get()?.id;
  const prod = db.prepare(`INSERT INTO products (name, slug, description, price, stock, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?, ?)`).run('Wishlist Product', 'wishlist-product', 'For wishlist', 35.00, 20, catId, 'https://example.com/wl.jpg');
  productId = prod.lastInsertRowid;
});

describe('Wishlist API', () => {
  describe('GET /api/wishlist', () => {
    it('returns empty wishlist initially', async () => {
      const res = await request(app)
        .get('/api/wishlist')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(Array.isArray(res.body)).toBe(true);
      expect(res.body.length).toBe(0);
    });

    it('requires authentication', async () => {
      const res = await request(app).get('/api/wishlist');
      expect(res.status).toBe(401);
    });
  });

  describe('POST /api/wishlist/:productId', () => {
    it('adds a product to wishlist', async () => {
      const res = await request(app)
        .post(`/api/wishlist/${productId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(201);
    });

    it('rejects duplicate wishlist entry', async () => {
      const res = await request(app)
        .post(`/api/wishlist/${productId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBeGreaterThanOrEqual(400);
    });
  });

  describe('GET /api/wishlist (after add)', () => {
    it('returns wishlist with added product', async () => {
      const res = await request(app)
        .get('/api/wishlist')
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
      expect(res.body.some(item => item.product_id === productId)).toBe(true);
    });
  });

  describe('DELETE /api/wishlist/:productId', () => {
    it('removes product from wishlist', async () => {
      const res = await request(app)
        .delete(`/api/wishlist/${productId}`)
        .set('Authorization', `Bearer ${token}`);
      expect(res.status).toBe(200);
    });

    it('wishlist is empty after removal', async () => {
      const res = await request(app)
        .get('/api/wishlist')
        .set('Authorization', `Bearer ${token}`);
      expect(res.body.some(item => item.id === productId)).toBe(false);
    });
  });
});
