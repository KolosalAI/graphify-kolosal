// Run before any test file is loaded — use in-memory SQLite for tests
process.env.DB_PATH = ':memory:';
