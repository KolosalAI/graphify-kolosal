// DEMO MODE — auth disabled. All requests are treated as the demo user (Jane).
import db from '../db/index.js';

function getDemoUser() {
  const jane = db.prepare(
    "SELECT id, name, email, subscription_plan, loyalty_points_balance FROM users WHERE email = 'jane@example.com'"
  ).get();
  if (!jane) throw new Error('Demo user not found — run the seed first: node server/src/db/seed.js');
  return { ...jane, role: 'admin' };
}

const DEMO_USER = getDemoUser();

export function generateToken(_user) {
  return 'demo-token';
}

export function authenticate(req, _res, next) {
  req.user = DEMO_USER;
  next();
}

export function optionalAuth(req, _res, next) {
  req.user = DEMO_USER;
  next();
}

export function requireAdmin(_req, _res, next) {
  next();
}
