import { DealRepository } from '../repositories/DealRepository.js';

export const DealService = {
  getActiveDeals() {
    return DealRepository.findActive();
  },

  getAllDeals() {
    return DealRepository.findAll();
  },

  createDeal({ product_id, sale_price, starts_at, ends_at }) {
    if (!product_id || !sale_price || !starts_at || !ends_at) {
      const e = new Error('product_id, sale_price, starts_at, ends_at required');
      e.status = 400;
      throw e;
    }
    return DealRepository.create({ product_id, sale_price, starts_at, ends_at });
  },

  updateDeal(id, fields) {
    const deal = DealRepository.findById(id);
    if (!deal) {
      const e = new Error('Deal not found');
      e.status = 404;
      throw e;
    }
    return DealRepository.update(id, fields);
  },

  deleteDeal(id) {
    DealRepository.deleteById(id);
    return { success: true };
  },
};
