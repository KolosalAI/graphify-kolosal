import { ProductRepository } from '../repositories/ProductRepository.js';

export const SpecService = {
  getProductSpecs(productId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    return ProductRepository.getSpecs(productId);
  },

  createSpec(productId, specData) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const { spec_key, spec_value, sort_order = 0 } = specData;

    if (!spec_key || !spec_value) {
      throw new Error('Spec key and value are required');
    }

    return ProductRepository.createSpec({
      product_id: productId,
      spec_key,
      spec_value,
      sort_order,
    });
  },

  updateSpec(productId, specId, specData) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const existing = ProductRepository.getSpecById(specId, productId);
    if (!existing) {
      const error = new Error('Spec not found');
      error.status = 404;
      throw error;
    }

    return ProductRepository.updateSpec(specId, specData);
  },

  deleteSpec(productId, specId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const existing = ProductRepository.getSpecById(specId, productId);
    if (!existing) {
      const error = new Error('Spec not found');
      error.status = 404;
      throw error;
    }

    ProductRepository.deleteSpec(specId, productId);
    return { success: true };
  },
};