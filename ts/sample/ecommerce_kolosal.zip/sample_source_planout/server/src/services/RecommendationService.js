import { RecommendationRepository } from '../repositories/RecommendationRepository.js';
import { ProductRepository } from '../repositories/ProductRepository.js';

export const RecommendationService = {
  getAlsoBought(productId) {
    const products = RecommendationRepository.getAlsoBought(productId);
    if (products.length > 0) return products;
    const product = ProductRepository.findById(productId);
    if (!product) return [];
    return RecommendationRepository.getRelatedByCategory(product.category_id, productId);
  },

  getAlsoViewed(productId) {
    const product = ProductRepository.findById(productId);
    if (!product) return [];
    return RecommendationRepository.getAlsoViewed(product.category_id, productId);
  },
};
