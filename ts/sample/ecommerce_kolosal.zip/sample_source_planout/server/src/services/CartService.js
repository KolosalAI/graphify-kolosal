import { CartRepository } from '../repositories/CartRepository.js';
import { ProductRepository } from '../repositories/ProductRepository.js';

export const CartService = {
  getCart(userId) {
    return CartRepository.getCartWithProducts(userId);
  },

  syncCart(userId, items) {
    if (!Array.isArray(items)) {
      throw new Error('Items must be an array');
    }

    CartRepository.syncItems(userId, items);
    return CartRepository.getCartWithProducts(userId);
  },

  addOrUpdateItem(userId, productId, quantity = 1) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    if (quantity <= 0) {
      CartRepository.removeItem(userId, productId);
    } else {
      CartRepository.upsertItem(userId, productId, quantity);
    }

    return CartRepository.getCartWithProducts(userId);
  },

  removeItem(userId, productId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    CartRepository.removeItem(userId, productId);
    return CartRepository.getCartWithProducts(userId);
  },

  clearCart(userId) {
    CartRepository.clearCart(userId);
    return { message: 'Cart cleared' };
  },
};