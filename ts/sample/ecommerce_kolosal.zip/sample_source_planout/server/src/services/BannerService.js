import { BannerRepository } from '../repositories/BannerRepository.js';

export const BannerService = {
  getActiveBanners() {
    return BannerRepository.findActive();
  },

  getAllBanners() {
    return BannerRepository.findAll();
  },

  createBanner({ title, subtitle, image_url, link, bg_color, sort_order, active }) {
    if (!title || !image_url) {
      const e = new Error('title and image_url are required.');
      e.status = 400;
      throw e;
    }
    return BannerRepository.create({ title, subtitle, image_url, link, bg_color, sort_order, active });
  },

  updateBanner(id, bannerData) {
    const existing = BannerRepository.findById(id);
    if (!existing) {
      const e = new Error('Banner not found');
      e.status = 404;
      throw e;
    }
    return BannerRepository.update(id, bannerData);
  },

  deleteBanner(id) {
    const existing = BannerRepository.findById(id);
    if (!existing) {
      const e = new Error('Banner not found');
      e.status = 404;
      throw e;
    }
    BannerRepository.deleteById(id);
    return { message: 'Banner deleted' };
  },

  toggleBanner(id) {
    const existing = BannerRepository.findById(id);
    if (!existing) {
      const e = new Error('Banner not found');
      e.status = 404;
      throw e;
    }
    return BannerRepository.toggleActive(id);
  },
};
