import { ProductRepository } from '../repositories/ProductRepository.js';

export const ProductService = {
  searchProducts({ search, category, page = 1, limit = 12, sort, min_price, max_price, in_stock, brand, min_rating }) {
    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(50, Math.max(1, parseInt(limit) || 12));
    const offset = (pageNum - 1) * limitNum;

    // Build where clause and parameters
    const { whereClause, params } = this.buildWhereClause({
      search, category, brand, min_price, max_price, in_stock
    });

    // Build order clause
    const orderBy = this.buildOrderClause(sort);

    // Build having clause for rating filter
    const havingClause = min_rating ? `HAVING avg_rating >= ${parseFloat(min_rating)}` : '';

    // Get total count
    const total = ProductRepository.countAll({ whereClause, params, havingClause });

    // Get products
    const products = ProductRepository.findAll({ 
      whereClause: whereClause + (havingClause ? ' GROUP BY p.id ' + havingClause : ''), 
      params, 
      orderBy, 
      limitNum, 
      offset 
    });

    // Get price range
    const priceRange = ProductRepository.getPriceRange({ whereClause, params });

    // Get brands for filter UI
    const brands = ProductRepository.getBrands({ whereClause, params });

    return {
      products,
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
      priceRange,
      brands,
    };
  },

  buildWhereClause({ search, category, brand, min_price, max_price, in_stock }) {
    const where = ['1=1'];
    const params = [];

    if (search) {
      where.push('(p.name LIKE ? OR p.description LIKE ? OR p.brand LIKE ?)');
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }
    if (category) {
      where.push('c.slug = ?');
      params.push(category);
    }
    if (brand) {
      where.push('p.brand = ?');
      params.push(brand);
    }
    if (min_price) {
      where.push('p.price >= ?');
      params.push(parseFloat(min_price));
    }
    if (max_price) {
      where.push('p.price <= ?');
      params.push(parseFloat(max_price));
    }
    if (in_stock === 'true') {
      where.push('p.stock > 0');
    }

    return { whereClause: where.join(' AND '), params };
  },

  buildOrderClause(sort) {
    switch (sort) {
      case 'price_asc':   return 'p.price ASC';
      case 'price_desc':  return 'p.price DESC';
      case 'name_asc':    return 'p.name ASC';
      case 'name_desc':   return 'p.name DESC';
      case 'top_rated':
      case 'rating_desc': return 'avg_rating DESC';
      case 'newest':      return 'p.created_at DESC';
      case 'oldest':      return 'p.created_at ASC';
      default:            return 'p.created_at DESC';
    }
  },

  getSearchSuggestions(query) {
    if (!query || query.length < 2) {
      return [];
    }
    return ProductRepository.getSuggestions(query);
  },

  getProductDetails(slug, userId = null, sessionId = null) {
    const product = ProductRepository.findBySlug(slug);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    // Track product view
    if (userId || sessionId) {
      ProductRepository.trackView(product.id, userId, sessionId);
    }

    // Get additional product data
    const images = ProductRepository.getImages(product.id);
    const variants = ProductRepository.getVariants(product.id);
    const specs = ProductRepository.getSpecs(product.id);
    const ratingDist = ProductRepository.getRatingDist(product.id);
    const alsoViewed = ProductRepository.getAlsoViewed(product.id);
    const related = ProductRepository.getRelated(product.category_id, product.id);

    // Group variants by group name
    const variantsGrouped = {};
    for (const variant of variants) {
      if (!variantsGrouped[variant.group_name]) {
        variantsGrouped[variant.group_name] = [];
      }
      variantsGrouped[variant.group_name].push(variant);
    }

    return {
      ...product,
      images,
      variants,
      variantsGrouped,
      specs,
      ratingDist,
      alsoViewed,
      related,
    };
  },

  addPriceWatch(userId, productId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    ProductRepository.addPriceWatch(userId, product.id);
    return { success: true, watched_price: product.price };
  },

  // Admin methods
  createProduct(productData) {
    const { name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible } = productData;
    
    if (!name || !slug || price === undefined || stock === undefined) {
      throw new Error('Name, slug, price, and stock are required');
    }

    return ProductRepository.create({
      name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible
    });
  },

  updateProduct(id, productData) {
    const existing = ProductRepository.findById(id);
    if (!existing) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const { name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible } = productData;
    return ProductRepository.update(id, {
      name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible
    });
  },

  deleteProduct(id) {
    const existing = ProductRepository.findById(id);
    if (!existing) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    return ProductRepository.deleteById(id);
  },

  updateProductImages(productId, images) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    ProductRepository.deleteImages(productId);
    if (images && images.length > 0) {
      ProductRepository.addImages(productId, images);
    }

    return { success: true };
  },

  getAllProductsAdmin({ page = 1, limit = 20 }) {
    const pageNum = Math.max(1, parseInt(page));
    const limitNum = Math.min(100, Math.max(1, parseInt(limit) || 20));
    const offset = (pageNum - 1) * limitNum;

    return ProductRepository.findAllAdmin({ limit: limitNum, offset });
  },
};