import { CategoryRepository } from '../repositories/CategoryRepository.js';

export const CategoryService = {
  getAllCategories() {
    return CategoryRepository.findAll();
  },

  createCategory({ name, slug, description }) {
    if (!name || !slug) {
      throw new Error('Name and slug are required');
    }

    const existing = CategoryRepository.findBySlug(slug);
    if (existing) {
      throw new Error('Category with this slug already exists');
    }

    return CategoryRepository.create({ name, slug, description });
  },

  updateCategory(id, { name, slug, description }) {
    const existing = CategoryRepository.getById(id);
    if (!existing) {
      const error = new Error('Category not found');
      error.status = 404;
      throw error;
    }

    if (!name || !slug) {
      throw new Error('Name and slug are required');
    }

    return CategoryRepository.update(id, { name, slug, description });
  },

  deleteCategory(id) {
    const existing = CategoryRepository.getById(id);
    if (!existing) {
      const error = new Error('Category not found');
      error.status = 404;
      throw error;
    }

    return CategoryRepository.deleteById(id);
  },
};