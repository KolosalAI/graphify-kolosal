import { ReviewRepository } from '../repositories/ReviewRepository.js';
import { ProductRepository } from '../repositories/ProductRepository.js';

export const ReviewService = {
  getProductReviews(productId, sort = 'newest', userId = null) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const stats = ReviewRepository.getStats(productId);
    
    let orderBy = 'r.created_at DESC';
    if (sort === 'helpful') orderBy = 'r.helpful_count DESC, r.created_at DESC';
    if (sort === 'rating_high') orderBy = 'r.rating DESC';
    if (sort === 'rating_low') orderBy = 'r.rating ASC';

    const reviews = ReviewRepository.findByProduct(productId, orderBy);
    const userHelpfulVotes = userId ? ReviewRepository.getUserHelpfulVotes(userId) : [];

    return {
      stats,
      reviews: reviews.map(review => ({
        ...review,
        user_voted_helpful: userHelpfulVotes.includes(review.id),
      })),
    };
  },

  getUserReview(productId, userId) {
    return ReviewRepository.findByProductAndUser(productId, userId);
  },

  createReview({ productId, userId, rating, title, body }) {
    if (!rating || rating < 1 || rating > 5) {
      const error = new Error('Rating must be between 1 and 5');
      error.status = 400;
      throw error;
    }

    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    // Check if user purchased the product
    const purchase = ReviewRepository.checkPurchase(productId, userId);
    if (!purchase) {
      const error = new Error('You must purchase this product before leaving a review');
      error.status = 403;
      throw error;
    }

    // Check if review already exists
    const existing = ReviewRepository.findByProductAndUser(productId, userId);
    if (existing) {
      const error = new Error('You have already reviewed this product');
      error.status = 409;
      throw error;
    }

    try {
      const review = ReviewRepository.create({ productId, userId, rating, title, body });
      return review;
    } catch (err) {
      if (err.message.includes('UNIQUE')) {
        const error = new Error('You have already reviewed this product');
        error.status = 409;
        throw error;
      }
      throw err;
    }
  },

  updateReview({ productId, userId, rating, title, body }) {
    if (!rating || rating < 1 || rating > 5) {
      const error = new Error('Rating must be between 1 and 5');
      error.status = 400;
      throw error;
    }

    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const changes = ReviewRepository.update({ productId, userId, rating, title, body });
    if (changes === 0) {
      const error = new Error('Review not found');
      error.status = 404;
      throw error;
    }

    const review = ReviewRepository.findByProductAndUserWithName(productId, userId);
    return review;
  },

  deleteReview(productId, userId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const existing = ReviewRepository.findByProductAndUser(productId, userId);
    if (!existing) {
      const error = new Error('Review not found');
      error.status = 404;
      throw error;
    }

    ReviewRepository.deleteByProductAndUser(productId, userId);
    return { message: 'Review deleted successfully' };
  },

  voteReviewHelpful(productId, reviewId, userId, helpful) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const review = ReviewRepository.findById(reviewId, productId);
    if (!review) {
      const error = new Error('Review not found');
      error.status = 404;
      throw error;
    }

    if (review.user_id === userId) {
      throw new Error('You cannot vote on your own review');
    }

    const result = ReviewRepository.voteHelpful(userId, reviewId, helpful);
    return {
      message: helpful ? 'Marked as helpful' : 'Marked as not helpful',
      helpful_count: result.helpful_count,
    };
  },
};