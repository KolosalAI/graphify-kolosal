import { ProductRepository } from '../repositories/ProductRepository.js';

export const VariantService = {
  getProductVariants(productId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    return ProductRepository.getVariants(productId);
  },

  createVariant(productId, variantData) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const { group_name, value, price_modifier = 0, stock = 0, sku, sort_order = 0 } = variantData;

    if (!group_name || !value) {
      throw new Error('Group name and value are required');
    }

    return ProductRepository.createVariant({
      product_id: productId,
      group_name,
      value,
      price_modifier,
      stock,
      sku,
      sort_order,
    });
  },

  updateVariant(productId, variantId, variantData) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const existing = ProductRepository.getVariantById(variantId, productId);
    if (!existing) {
      const error = new Error('Variant not found');
      error.status = 404;
      throw error;
    }

    return ProductRepository.updateVariant(variantId, variantData);
  },

  deleteVariant(productId, variantId) {
    const product = ProductRepository.findById(productId);
    if (!product) {
      const error = new Error('Product not found');
      error.status = 404;
      throw error;
    }

    const existing = ProductRepository.getVariantById(variantId, productId);
    if (!existing) {
      const error = new Error('Variant not found');
      error.status = 404;
      throw error;
    }

    ProductRepository.deleteVariant(variantId, productId);
    return { success: true };
  },
};