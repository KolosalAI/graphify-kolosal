import { FlashSaleRepository } from '../repositories/FlashSaleRepository.js';
import { ProductRepository } from '../repositories/ProductRepository.js';

export const FlashSaleService = {
  getActiveSaleWithItems() {
    const sale = FlashSaleRepository.getActive();
    if (!sale) return null;
    const items = FlashSaleRepository.getActiveItems(sale.id);
    return { ...sale, items };
  },

  getAllFlashSales() {
    return FlashSaleRepository.findAll();
  },

  getSaleWithItems(id) {
    const sale = FlashSaleRepository.findById(id);
    if (!sale) {
      const e = new Error('Flash sale not found');
      e.status = 404;
      throw e;
    }
    const items = FlashSaleRepository.getItems(id);
    return { ...sale, items };
  },

  createSale({ title, starts_at, ends_at, active }) {
    if (!title || !starts_at || !ends_at) {
      const e = new Error('title, starts_at, and ends_at are required.');
      e.status = 400;
      throw e;
    }
    if (new Date(ends_at) <= new Date(starts_at)) {
      const e = new Error('ends_at must be after starts_at.');
      e.status = 400;
      throw e;
    }
    return FlashSaleRepository.create({ title, starts_at, ends_at, active });
  },

  updateSale(id, { title, starts_at, ends_at, active }) {
    const existing = FlashSaleRepository.findById(id);
    if (!existing) {
      const e = new Error('Flash sale not found');
      e.status = 404;
      throw e;
    }
    if (new Date(ends_at) <= new Date(starts_at)) {
      const e = new Error('ends_at must be after starts_at.');
      e.status = 400;
      throw e;
    }
    return FlashSaleRepository.update(id, { title, starts_at, ends_at, active });
  },

  toggleSale(id) {
    const existing = FlashSaleRepository.findById(id);
    if (!existing) {
      const e = new Error('Flash sale not found');
      e.status = 404;
      throw e;
    }
    return FlashSaleRepository.toggleActive(id);
  },

  deleteSale(id) {
    const existing = FlashSaleRepository.findById(id);
    if (!existing) {
      const e = new Error('Flash sale not found');
      e.status = 404;
      throw e;
    }
    return FlashSaleRepository.deleteById(id);
  },

  addItem(saleId, { product_id, sale_price, quantity_limit }) {
    const sale = FlashSaleRepository.findById(saleId);
    if (!sale) {
      const e = new Error('Flash sale not found');
      e.status = 404;
      throw e;
    }
    if (!product_id || sale_price == null) {
      const e = new Error('product_id and sale_price are required.');
      e.status = 400;
      throw e;
    }
    const product = ProductRepository.findById(product_id);
    if (!product) {
      const e = new Error('Product not found');
      e.status = 404;
      throw e;
    }
    if (sale_price >= product.price) {
      const e = new Error('sale_price must be less than the original price.');
      e.status = 400;
      throw e;
    }
    try {
      return FlashSaleRepository.addItem({ flash_sale_id: saleId, product_id, sale_price, quantity_limit });
    } catch (err) {
      if (err.message.includes('UNIQUE')) {
        const e = new Error('Product is already in this flash sale.');
        e.status = 409;
        throw e;
      }
      throw err;
    }
  },

  updateItem(saleId, itemId, { sale_price, quantity_limit }) {
    const item = FlashSaleRepository.getItemById(itemId, saleId);
    if (!item) {
      const e = new Error('Item not found');
      e.status = 404;
      throw e;
    }
    const product = ProductRepository.findById(item.product_id);
    if (sale_price >= product.price) {
      const e = new Error('sale_price must be less than the original price.');
      e.status = 400;
      throw e;
    }
    return FlashSaleRepository.updateItem(itemId, { sale_price, quantity_limit });
  },

  removeItem(saleId, itemId) {
    const result = FlashSaleRepository.deleteItem(itemId, saleId);
    if (result.changes === 0) {
      const e = new Error('Item not found');
      e.status = 404;
      throw e;
    }
    return { message: 'Item removed' };
  },
};
