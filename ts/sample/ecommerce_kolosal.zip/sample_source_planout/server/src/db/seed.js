import bcrypt from 'bcryptjs';
import db from './index.js';

// --- Clear existing data ---
const tables = [
  'deals_of_day', 'flash_sale_items', 'flash_sales', 'wishlists',
  'order_items', 'orders', 'product_images', 'product_variants',
  'product_specs', 'reviews', 'products', 'categories',
  'loyalty_points', 'addresses', 'gift_cards', 'subscriptions',
  'notifications', 'banners', 'coupons', 'users',
];
for (const t of tables) {
  try { db.prepare(`DELETE FROM ${t}`).run(); } catch (_) {}
}
try { db.prepare("DELETE FROM sqlite_sequence").run(); } catch (_) {}

// --- Users ---
const adminPass = bcrypt.hashSync('admin123', 10);
const userPass  = bcrypt.hashSync('user123', 10);

const insertUser = db.prepare(
  'INSERT INTO users (name, email, password, role, subscription_plan, loyalty_points_balance, referral_code) VALUES (?, ?, ?, ?, ?, ?, ?)'
);

const adminId = insertUser.run('Admin User', 'admin@shopkolosal.com', adminPass, 'admin',    null,    0,   'ADMIN001').lastInsertRowid;
const janeId  = insertUser.run('Jane Smith',  'jane@example.com',     userPass,  'admin',   'prime', 850, 'JANE2024').lastInsertRowid;
const bobId   = insertUser.run('Bob Wilson',  'bob@example.com',      userPass,  'customer', null,   120, 'BOB2024').lastInsertRowid;

// Prime subscription for Jane
db.prepare('INSERT INTO subscriptions (user_id, plan, billing_cycle, status) VALUES (?, ?, ?, ?)').run(janeId, 'prime', 'monthly', 'active');

// Loyalty points history
const insertLP = db.prepare('INSERT INTO loyalty_points (user_id, points, reason) VALUES (?, ?, ?)');
insertLP.run(janeId, 500, 'Welcome bonus');
insertLP.run(janeId, 200, 'Purchase reward: order #1');
insertLP.run(janeId, 150, 'Purchase reward: order #2');
insertLP.run(bobId,  120, 'Welcome bonus');

// Gift cards
const insertGC = db.prepare('INSERT INTO gift_cards (code, original_value, balance, active) VALUES (?, ?, ?, ?)');
insertGC.run('DEMO50', 50, 50, 1);
insertGC.run('DEMO20', 20, 20, 1);

// Addresses for Jane
const insertAddr = db.prepare(
  'INSERT INTO addresses (user_id, full_name, line1, city, state, postal_code, country, phone, is_default) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
);
insertAddr.run(janeId, 'Jane Smith', '123 Maple St',  'Portland',      'OR', '97201', 'US', '503-555-0100', 1);
insertAddr.run(janeId, 'Jane Smith', '456 Oak Ave',   'Seattle',       'WA', '98101', 'US', '206-555-0200', 0);
insertAddr.run(janeId, 'Jane Smith', '789 Pine Rd',   'San Francisco', 'CA', '94102', 'US', '415-555-0300', 0);

console.log('Users, subscriptions, loyalty, gift cards, addresses seeded.');

// --- Categories ---
const insertCategory = db.prepare('INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)');
const catData = [
  ['Electronics',       'electronics',     'Gadgets, devices, and electronic accessories'],
  ['Clothing',          'clothing',        'Apparel and fashion items'],
  ['Home & Kitchen',    'home-kitchen',    'Furniture, appliances, and kitchen essentials'],
  ['Books',             'books',           'Physical and digital books across every genre'],
  ['Sports & Outdoors', 'sports-outdoors', 'Sports equipment and outdoor adventure gear'],
];
const catIds = {};
db.transaction(() => {
  for (const [n, s, d] of catData) {
    catIds[s] = insertCategory.run(n, s, d).lastInsertRowid;
  }
})();

// --- Products ---
// [name, slug, description, price, image_url, stock, catSlug, badge, [extra_images]]
const products = [
  // ── Electronics (30) ──────────────────────────────────────────────────
  ['Wireless Bluetooth Headphones',    'wireless-bluetooth-headphones',       'Premium noise-canceling headphones with 30-hour battery life. Advanced ANC, memory foam cushions, multi-device connectivity.',                                  79.99,  'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500',  45,  'electronics', 'Best Seller', ['https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800','https://images.unsplash.com/photo-1487215078519-e21cc028cb29?w=800']],
  ['Smart Watch Pro',                  'smart-watch-pro',                     'Feature-rich smartwatch with heart rate monitoring, GPS, and 7-day battery. Water resistant to 50m, always-on AMOLED.',                                         199.99, 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500',  30,  'electronics', 'Hot Deal',   ['https://images.unsplash.com/photo-1546868871-af0de0ae72be?w=800','https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800']],
  ['USB-C Hub Adapter',                'usb-c-hub-adapter',                   '7-in-1 USB-C hub with HDMI, USB 3.0, SD card reader, and 65W PD charging. Slim aluminum alloy design.',                                                         34.99,  'https://images.unsplash.com/photo-1625842268584-8f3296236571?w=500', 100,  'electronics',  null,         []],
  ['Mechanical Keyboard',              'mechanical-keyboard',                  'RGB mechanical keyboard with Cherry MX switches and aluminum frame. Per-key RGB with 16.8M colors.',                                                              129.99, 'https://images.unsplash.com/photo-1541140532154-b024d1c0c8a4?w=500',  25,  'electronics', 'New',        ['https://images.unsplash.com/photo-1595225476474-87563907a212?w=800']],
  ['Portable Bluetooth Speaker',       'portable-bluetooth-speaker',          'Waterproof 360° portable speaker with 12-hour playtime. IPX7 rated, built-in mic, dual stereo pairing.',                                                          49.99,  'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500',  60,  'electronics',  null,         []],
  ['Gaming Laptop Pro 15"',            'gaming-laptop-pro-15',                'Powerful gaming laptop with RTX 4060, 16GB DDR5 RAM, 512GB NVMe SSD, and 144Hz IPS display. Handles all modern titles at high settings.',                       1199.99,'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=500',   12,  'electronics', 'Hot Deal',   ['https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=800']],
  ['Wireless Noise-Canceling Earbuds', 'wireless-noise-canceling-earbuds',    'True wireless earbuds with ANC, 28-hour total battery, and IPX5 water resistance. Transparency mode, wireless charging case.',                                   79.99,  'https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=500',  55,  'electronics', 'Best Seller', []],
  ['27" 4K IPS Monitor',               '4k-monitor-27',                       '27-inch 4K UHD monitor with 144Hz refresh rate, HDR400, and USB-C 65W delivery. IPS panel with 99% sRGB coverage.',                                             449.99, 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=500',  18,  'electronics',  null,         []],
  ['Wireless Gaming Mouse',            'wireless-gaming-mouse',               'Ultra-lightweight wireless gaming mouse with 25K DPI sensor, 70-hour battery, and 6 programmable buttons.',                                                        59.99,  'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=500',  40,  'electronics', 'New',        []],
  ['4K Webcam with Ring Light',        'webcam-4k-ring-light',                '4K 30fps webcam with built-in ring light, dual noise-canceling mics, and auto-focus. Plug-and-play.',                                                              89.99,  'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=500',  35,  'electronics',  null,         []],
  ['20000mAh Portable Charger',        'portable-charger-20000mah',           '65W PD portable power bank with 3 output ports. Charges a laptop once, phone 4+ times. LED battery indicator.',                                                   49.99,  'https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=500',  80,  'electronics',  null,         []],
  ['Smart Home Hub',                   'smart-home-hub',                      'Universal smart home hub supporting Zigbee, Z-Wave, Wi-Fi, and Bluetooth. Compatible with Alexa, Google Home, and Apple HomeKit.',                               79.99,  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500',   30,  'electronics',  null,         []],
  ['4K Action Camera',                 '4k-action-camera',                    'Waterproof action camera shooting 4K 60fps with 6-axis stabilization. Includes 2 batteries, mounting kit, and 64GB card.',                                        149.99, 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=500',  22,  'electronics', 'Hot Deal',   []],
  ['Sport Wireless Earphones',         'sport-wireless-earphones',            'IPX7 sport earphones with 8-hour battery and secure ear hooks. Powerful bass, ambient sound mode.',                                                                34.99,  'https://images.unsplash.com/photo-1585386959984-a4155224a1ad?w=500',  70,  'electronics',  null,         []],
  ['10" Android Tablet',               '10-android-tablet',                   'Android 14 tablet with 10.4" 2K display, 6GB RAM, 128GB storage, and 7000mAh battery. Quad speakers with Dolby Atmos.',                                          199.99, 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=500',   25,  'electronics',  null,         []],
  ['3-in-1 Wireless Charging Station', 'wireless-charging-station-3in1',      'Charge phone, earbuds, and smartwatch simultaneously. 15W fast wireless charging, non-slip surface.',                                                               39.99,  'https://images.unsplash.com/photo-1626160399843-a0c5481e1e77?w=500',  50,  'electronics', 'New',        []],
  ['Mini Portable Projector',          'mini-portable-projector',             '1080p native resolution mini projector with 350 ANSI lumens, built-in speaker, and auto keystone correction.',                                                     129.99, 'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=500',  15,  'electronics',  null,         []],
  ['Smart Plug 4-Pack',                'smart-plug-4pack',                    'Wi-Fi smart plugs with energy monitoring and scheduling. Voice control via Alexa and Google. No hub required.',                                                     29.99,  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500',   90,  'electronics',  null,         []],
  ['Digital Drawing Tablet',           'digital-drawing-tablet',              '10x6" drawing tablet with 8192 pressure levels and battery-free pen. Works with Photoshop, Illustrator, Clip Studio.',                                             69.99,  'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500',  28,  'electronics',  null,         []],
  ['Aluminum Laptop Stand',            'aluminum-laptop-stand',               'Adjustable 6-angle aluminum laptop stand. Foldable and portable, fits 10–17" laptops. Heat dissipation design.',                                                   34.99,  'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=500',  60,  'electronics',  null,         []],
  ['Smart LED Bulbs 4-Pack',           'smart-led-bulbs-4pack',               'Wi-Fi RGB smart bulbs with 16 million colors, 800lm brightness, and tunable white. Works with Alexa and Google.',                                                 34.99,  'https://images.unsplash.com/photo-1565814329452-e1efa11c5b89?w=500',  75,  'electronics',  null,         []],
  ['10" Digital Photo Frame',          'digital-photo-frame-10',              'Wi-Fi connected 10" IPS digital photo frame with 16GB storage. Share photos remotely via the companion app.',                                                       89.99,  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500',   20,  'electronics',  null,         []],
  ['Wireless Keyboard & Mouse Combo',  'wireless-keyboard-mouse-combo',       'Silent 2.4GHz wireless keyboard and mouse combo. Ergonomic design, 1000 DPI adjustable, 24-month battery life.',                                                   44.99,  'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=500',  45,  'electronics',  null,         []],
  ['Bookshelf Computer Speakers',      'bookshelf-computer-speakers',         '40W RMS bookshelf speakers with Bluetooth 5.0, optical, RCA, and 3.5mm inputs. Wood enclosure, warm detailed sound.',                                              59.99,  'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=500',   18,  'electronics',  null,         []],
  ['Blue Light Blocking Glasses',      'blue-light-blocking-glasses',         'Anti-glare blue light glasses with UV400 protection. Lightweight TR90 frame, unisex design.',                                                                       22.99,  'https://images.unsplash.com/photo-1574258495973-f010dfbb5371?w=500', 100,  'electronics',  null,         []],
  ['Cable Management Kit 100pc',       'cable-management-kit',                '100-piece cable management set with velcro ties, cable clips, sleeves, and labels.',                                                                                16.99,  'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=500', 120,  'electronics',  null,         []],
  ['256GB SD Card UHS-I',              'sd-card-256gb-uhsi',                  'High-speed 256GB microSDXC card with 100MB/s read speed. Includes adapter. A2 rated for app performance.',                                                         24.99,  'https://images.unsplash.com/photo-1618424181497-157f25b6ddd5?w=500', 150,  'electronics',  null,         []],
  ['8K HDMI 2.1 Cable 6ft',            'hdmi-cable-8k-6ft',                   'Certified 8K HDMI 2.1 cable supporting 48Gbps bandwidth, 8K@60Hz and 4K@120Hz. Braided nylon.',                                                                    19.99,  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500',  200,  'electronics',  null,         []],
  ['Memory Foam Keyboard Wrist Rest',  'keyboard-wrist-rest-foam',            'Memory foam wrist rest with non-slip base. Full-length design fits standard and tenkeyless keyboards.',                                                              14.99,  'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=500',  90,  'electronics',  null,         []],
  ['Screen Cleaning Kit',              'screen-cleaning-kit',                 'LCD screen cleaning kit with 500ml spray, 3 microfiber cloths, and brush. Safe for all screens.',                                                                    12.99,  'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=500',  180,  'electronics',  null,         []],

  // ── Clothing (30) ────────────────────────────────────────────────────
  ['Classic Denim Jacket',             'classic-denim-jacket',                'Timeless selvedge denim jacket with relaxed fit, brass buttons, and interior pocket.',                                                                               59.99,  'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=500',  40,  'clothing', 'Best Seller', ['https://images.unsplash.com/photo-1551537482-f2075a1d41f2?w=800']],
  ['Organic Cotton Crew T-Shirt',      'cotton-crew-tshirt',                  'Ultra-soft 100% organic cotton tee. Pre-shrunk, reinforced stitching, available in 12 colors.',                                                                      19.99,  'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500', 200,  'clothing',  null,         []],
  ['Running Sneakers',                 'running-sneakers',                    'Lightweight engineered knit running shoes with responsive foam cushioning and 3D-printed overlays.',                                                                  89.99,  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',   55,  'clothing', 'Hot Deal',   ['https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800']],
  ['Merino Wool Beanie',               'wool-beanie',                         'Double-layered merino wool beanie with soft fleece lining. Keeps you warm without the itch.',                                                                         24.99,  'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=500',  80,  'clothing', 'New',        []],
  ['Slim Fit Chino Pants',             'slim-fit-chinos',                     '4-way stretch slim chinos. Wrinkle-resistant, 5 pockets, available in khaki, navy, olive, and black.',                                                                44.99,  'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500',  65,  'clothing',  null,         []],
  ['Lightweight Puffer Jacket',        'puffer-jacket-lightweight',           'Water-resistant packable puffer jacket with 600-fill down. Compresses into its own pocket. Warm to 20°F.',                                                             89.99,  'https://images.unsplash.com/photo-1547949003-9792a18a2601?w=500',   35,  'clothing', 'Best Seller', []],
  ['Genuine Leather Belt',             'leather-belt-genuine',                '1.3" full-grain leather belt with brushed silver buckle. Hand-stitched edges, brown and black.',                                                                       29.99,  'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=500',   90,  'clothing',  null,         []],
  ['High-Waist Compression Leggings', 'compression-leggings-high-waist',     '4-way stretch high-waist leggings with hidden pocket and squat-proof fabric. 25" and 28" inseam.',                                                                     34.99,  'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=500',  80,  'clothing',  null,         []],
  ['Classic Oxford Shirt',             'oxford-shirt-classic',                '100% ring-spun cotton Oxford shirt with button-down collar. Relaxed fit, wash and wear.',                                                                              39.99,  'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=500',  60,  'clothing',  null,         []],
  ['Canvas Low-Top Sneakers',          'canvas-lowtop-sneakers',              'Vulcanized canvas low-tops with rubber sole and cushioned insole. 8 colorways, unisex sizing.',                                                                        45.99,  'https://images.unsplash.com/photo-1463100099107-aa0980c362e6?w=500',  70,  'clothing',  null,         []],
  ['Merino Wool Socks 5-Pack',         'merino-wool-socks-5pack',             'Anti-odor moisture-wicking merino wool socks with cushioned footbed. Machine washable. Crew length.',                                                                  24.99,  'https://images.unsplash.com/photo-1586350977771-b3b0abd50c82?w=500', 120,  'clothing',  null,         []],
  ['Structured Baseball Cap',          'baseball-cap-structured',             '6-panel 100% cotton twill cap with pre-curved brim. Metal strap closure, one size fits most.',                                                                         19.99,  'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?w=500', 100,  'clothing',  null,         []],
  ['Pullover Fleece Hoodie',           'hoodie-fleece-pullover',              'Heavyweight 380gsm fleece hoodie with kangaroo pocket and lined hood. Pre-shrunk, presoftened.',                                                                        54.99,  'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=500',   55,  'clothing',  null,         []],
  ['Quick-Dry Swim Shorts',            'swim-shorts-quick-dry',               '4-way stretch swim trunks with inner mesh liner, zip back pocket, and quick-dry finish. 15" outseam.',                                                                 29.99,  'https://images.unsplash.com/photo-1520390138845-fd2d229dd553?w=500',  80,  'clothing',  null,         []],
  ['Athletic Tank Tops 3-Pack',        'athletic-tank-top-3pack',             'Moisture-wicking tagless athletic tanks with racerback design. Soft hand feel, great for gym or casual.',                                                               22.99,  'https://images.unsplash.com/photo-1530143584546-02191bc84eb5?w=500', 100,  'clothing',  null,         []],
  ['Chunky Knit Winter Scarf',         'winter-scarf-chunky-knit',            'Oversized 70" chunky-knit scarf in acrylic blend. Fringe ends, 6 neutral colors.',                                                                                      19.99,  'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?w=500',  70,  'clothing', 'New',        []],
  ['Waterproof Work Boots',            'work-boots-waterproof',               'Steel-toe waterproof work boots with slip-resistant rubber outsole. Electrical hazard rated.',                                                                          119.99, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',   30,  'clothing',  null,         []],
  ['UV-Protect Polo Shirt',            'polo-shirt-uv-protect',               'UPF 50+ pique polo with moisture management. Classic fit, 3-button placket, 8 colors.',                                                                                34.99,  'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=500',  75,  'clothing',  null,         []],
  ['Tapered Jogger Pants',             'jogger-pants-tapered',                'French terry joggers with tapered leg, drawstring waist, and side pockets. Home or street ready.',                                                                      39.99,  'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500',  60,  'clothing',  null,         []],
  ['Packable Rain Jacket',             'rain-jacket-packable',                'Lightweight packable rain jacket with fully taped seams, adjustable hood, and pit vents.',                                                                              79.99,  'https://images.unsplash.com/photo-1547949003-9792a18a2601?w=500',   40,  'clothing',  null,         []],
  ['Mid-Rise Denim Shorts',            'denim-shorts-mid-rise',               'Vintage-wash mid-rise denim shorts with frayed hem. 5" inseam, 5-pocket styling.',                                                                                      34.99,  'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500',  55,  'clothing',  null,         []],
  ['Block Heel Ankle Boots',           'ankle-boots-block-heel',              'Faux leather block-heel ankle boots with side zip. 2.5" heel, cushioned footbed, runs true to size.',                                                                   59.99,  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',   35,  'clothing',  null,         []],
  ['High-Impact Sports Bra',           'sports-bra-high-impact',              'Moisture-wicking padded sports bra with criss-cross back. High-impact support, 4-way stretch.',                                                                          29.99,  'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=500',  70,  'clothing',  null,         []],
  ['Vintage Graphic T-Shirt',          'graphic-tee-vintage',                 'Soft ring-spun cotton tee with retro screen-print graphic. Pre-distressed for a worn-in look.',                                                                          24.99,  'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500',  90,  'clothing',  null,         []],
  ['Utility Cargo Pants',              'cargo-pants-utility',                 'Ripstop cotton cargo pants with 8 pockets and reinforced knees. Gusseted crotch for full mobility.',                                                                      54.99,  'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=500',  40,  'clothing',  null,         []],
  ['Open-Front Knit Cardigan',         'cardigan-knit-open-front',            'Lightweight oversized open-front cardigan in a textured knit. Easy layer for any season.',                                                                                44.99,  'https://images.unsplash.com/photo-1576871337632-b9aef4c17ab9?w=500',  50,  'clothing',  null,         []],
  ['Slim Leather Bifold Wallet',       'leather-wallet-slim-bifold',          'RFID-blocking slim genuine leather wallet with 6 card slots, ID window, and cash compartment.',                                                                           24.99,  'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=500',  100,  'clothing',  null,         []],
  ['Polarized Aviator Sunglasses',     'sunglasses-polarized-aviator',        'UV400 polarized aviator sunglasses with spring hinges. Scratch-resistant lens, lightweight metal frame.',                                                                  34.99,  'https://images.unsplash.com/photo-1473496169904-658ba7574b0d?w=500',  80,  'clothing',  null,         []],
  ['Touchscreen Winter Gloves',        'winter-gloves-touchscreen',           'Thinsulate-lined touchscreen-compatible gloves. Grippy palm, adjustable cuff, water-resistant shell.',                                                                      17.99,  'https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?w=500',  90,  'clothing', 'New',        []],
  ['7" Athletic Running Shorts',       'athletic-shorts-7in',                 '7" running shorts with built-in liner and reflective details. Side pockets, secure zip back pocket.',                                                                      24.99,  'https://images.unsplash.com/photo-1506629082955-511b1aa562c8?w=500',  85,  'clothing',  null,         []],

  // ── Home & Kitchen (25) ──────────────────────────────────────────────
  ['Stainless Steel Water Bottle',     'stainless-steel-water-bottle',        'Double-walled 32oz insulated bottle. Keeps drinks cold 24h or hot 12h. BPA-free, leak-proof lid.',                                                                        29.99,  'https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500', 120,  'home-kitchen',  null,        ['https://images.unsplash.com/photo-1523362628745-0c100150b504?w=800']],
  ['Ceramic Coffee Mug Set',           'ceramic-coffee-mug-set',              'Set of 4 handcrafted 12oz ceramic mugs in earthy tones. Microwave and dishwasher safe.',                                                                                    39.99,  'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=500',  35,  'home-kitchen', 'New',        []],
  ['10-Piece Non-Stick Cookware Set',  'non-stick-cookware-set',              'Titanium-reinforced non-stick 10-piece set. Oven safe to 500°F, dishwasher safe, includes glass lids.',                                                                    149.99, 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=500',   20,  'home-kitchen',  null,        ['https://images.unsplash.com/photo-1584990347449-a4c9f24c56f1?w=800']],
  ['LED Desk Lamp',                    'led-desk-lamp',                       'Adjustable 5-brightness LED desk lamp with USB-A charging port, touch control, and memory function.',                                                                        44.99,  'https://images.unsplash.com/photo-1507473885765-e6ed057ab6fe?w=500',  50,  'home-kitchen', 'Best Seller', []],
  ['HEPA Air Purifier',                'air-purifier-hepa',                   'True HEPA air purifier covering 500 sq ft. CADR 230, whisper-quiet 24dB, auto mode, timer.',                                                                                129.99, 'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=500',  22,  'home-kitchen',  null,        []],
  ['12-Cup Programmable Coffee Maker', 'coffee-maker-12cup',                  'Drip coffee maker with built-in burr grinder, 24h programmable timer, and brew-strength control.',                                                                           79.99,  'https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?w=500',  30,  'home-kitchen', 'Best Seller', []],
  ['5.5Qt Tilt-Head Stand Mixer',      'stand-mixer-5qt',                     'Powerful 5.5-quart stand mixer with 10 speeds, tilt-head design, and 3 attachments: hook, beater, whisk.',                                                                  199.99, 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500',  15,  'home-kitchen',  null,        []],
  ['Bamboo Cutting Board Set 3pc',     'bamboo-cutting-board-set',            '3-piece bamboo cutting board set with juice grooves and hanging holes. Naturally antimicrobial.',                                                                              29.99,  'https://images.unsplash.com/photo-1541014741259-de529411b96a?w=500',  65,  'home-kitchen',  null,        []],
  ['Professional Chef Knife Set 6pc',  'knife-set-6pc-chef',                  '6-piece high-carbon German steel knife set with block. Full-tang forged blades, triple-riveted handles.',                                                                     89.99,  'https://images.unsplash.com/photo-1593618998160-e34014e67546?w=500',  25,  'home-kitchen', 'Hot Deal',   []],
  ['Sherpa Fleece Throw Blanket',      'throw-blanket-sherpa-fleece',         'Ultra-soft 60x80" sherpa fleece throw. Double-sided — smooth one side, plush sherpa the other. 6 colors.',                                                                    34.99,  'https://images.unsplash.com/photo-1540518614846-7eded433c457?w=500',  55,  'home-kitchen',  null,        []],
  ['Foldable Storage Ottoman',         'storage-ottoman-foldable',            '30x15x15" foldable storage ottoman. Supports 220lbs, removable tray top, hidden storage inside.',                                                                              49.99,  'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500',   20,  'home-kitchen',  null,        []],
  ['Bamboo Desk Organizer',            'bamboo-desk-organizer',               '5-compartment bamboo desk organizer with pen holder and phone slot. Sustainable, smooth finish.',                                                                              22.99,  'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=500',  70,  'home-kitchen',  null,        []],
  ['Soy Wax Scented Candle Set 3pc',   'scented-candle-set-soy-3pc',          '3-pack soy wax candles with cotton wicks. 50-hour burn each. Scents: lavender, vanilla, cedarwood.',                                                                         32.99,  'https://images.unsplash.com/photo-1602523961358-f9f03dd557db?w=500',  45,  'home-kitchen', 'New',        []],
  ['Variable Temperature Kettle',      'electric-kettle-variable-temp',       '1.7L gooseneck electric kettle with 6 preset temperatures and keep-warm mode. Ideal for pour-over.',                                                                           54.99,  'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=500',  35,  'home-kitchen',  null,        []],
  ['Glass Food Storage Set 10pc',      'glass-food-storage-set-10pc',         '10-piece borosilicate glass containers with leakproof snap-lock lids. Oven, microwave, dishwasher safe.',                                                                      44.99,  'https://images.unsplash.com/photo-1612965110667-4175024b0dcc?w=500',  40,  'home-kitchen',  null,        []],
  ['Egyptian Cotton Towel Set 6pc',    'bath-towel-set-egyptian-cotton',      '6-piece 600gsm Egyptian cotton towel set. 2 bath, 2 hand, 2 washcloth. Quick-dry, ultra-soft.',                                                                               49.99,  'https://images.unsplash.com/photo-1600369671271-d80f9a0ab29e?w=500',  30,  'home-kitchen',  null,        []],
  ['Modern Minimalist Wall Clock',     'wall-clock-minimalist',               '12" silent-sweep wall clock with matte aluminum frame. No tick — perfect for bedrooms and offices.',                                                                            24.99,  'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=500',  50,  'home-kitchen',  null,        []],
  ['Arc Floor Lamp',                   'floor-lamp-arc',                      '72" arc floor lamp with 3-way dimmer, linen shade, and brushed nickel finish. E26 bulb included.',                                                                              89.99,  'https://images.unsplash.com/photo-1507473885765-e6ed057ab6fe?w=500',  18,  'home-kitchen',  null,        []],
  ['Linen Throw Pillow Covers 4pc',    'throw-pillow-covers-linen-4pc',       'Set of 4 18x18" linen blend pillow covers with hidden zip closure. Neutral tones for any decor.',                                                                              19.99,  'https://images.unsplash.com/photo-1540518614846-7eded433c457?w=500',  80,  'home-kitchen',  null,        []],
  ['Mandoline Vegetable Chopper',      'vegetable-chopper-mandoline',         'Adjustable mandoline with 12 blades, safety hand guard, and collection container. Uniform slices fast.',                                                                        34.99,  'https://images.unsplash.com/photo-1612965110667-4175024b0dcc?w=500',  40,  'home-kitchen',  null,        []],
  ['Pre-Seasoned Cast Iron Skillet',   'cast-iron-skillet-preseasoned',       '10.25" pre-seasoned cast iron skillet. Oven safe to 500°F, works on all cooktops including induction.',                                                                         39.99,  'https://images.unsplash.com/photo-1612965110667-4175024b0dcc?w=500',  30,  'home-kitchen', 'Best Seller', []],
  ['High-Pressure Rainfall Shower',    'shower-head-rainfall-9in',            '9" chrome rainfall shower head with 120 anti-clog nozzles and adjustable arm. Tool-free install.',                                                                              39.99,  'https://images.unsplash.com/photo-1600369671271-d80f9a0ab29e?w=500',  35,  'home-kitchen',  null,        []],
  ['Silicone Toilet Brush Set',        'toilet-brush-set-silicone',           'No-drip silicone toilet brush with holder. Hygienic storage, flexible head reaches under rim.',                                                                                17.99,  'https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=500',  60,  'home-kitchen',  null,        []],
  ['Waterproof Fabric Shower Curtain', 'shower-curtain-waterproof',           '72x72" mildew-resistant fabric shower curtain with rust-proof metal rings. Machine washable.',                                                                                  24.99,  'https://images.unsplash.com/photo-1600369671271-d80f9a0ab29e?w=500',  45,  'home-kitchen',  null,        []],
  ['Photo Frames Set 5pc',             'photo-frames-set-5pc',                'Gallery wall photo frame set, mixed sizes (4x6, 5x7, 8x10). Black finish, wall and tabletop.',                                                                                 29.99,  'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=500',  40,  'home-kitchen',  null,        []],

  // ── Books (20) ──────────────────────────────────────────────────────
  ['The Art of Programming',           'art-of-programming',                  'A comprehensive guide to software development principles and best practices. Algorithms, design patterns, clean code.',                                                          39.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   70,  'books',  null,         []],
  ['Mindful Living',                   'mindful-living',                      'Practical techniques for a more balanced and intentional life. Guided meditations and daily exercises.',                                                                          16.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  90,  'books', 'Best Seller', []],
  ['World Atlas 2025',                 'world-atlas-2025',                    'Updated full-color atlas with detailed maps, demographics, and satellite imagery. Essential reference.',                                                                           54.99,  'https://images.unsplash.com/photo-1524578271613-d550eacf6090?w=500',  15,  'books', 'New',        []],
  ['Deep Work',                        'deep-work-cal-newport',               "Cal Newport's guide to focused success. Rules for cultivating deep work habits that produce high-value results.",                                                                  16.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  80,  'books', 'Best Seller', []],
  ['Atomic Habits',                    'atomic-habits-james-clear',           "James Clear's proven framework for building good habits. Small changes, remarkable results.",                                                                                      18.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',  100,  'books', 'Best Seller', []],
  ['Sapiens: A Brief History',         'sapiens-yuval-harari',                "Yuval Noah Harari's sweeping narrative of humankind from the Stone Age to the modern era.",                                                                                       17.99,  'https://images.unsplash.com/photo-1524578271613-d550eacf6090?w=500',  75,  'books',  null,         []],
  ['Clean Code',                       'clean-code-robert-martin',            "Robert C. Martin's definitive guide to writing maintainable, readable code. Essential for every developer.",                                                                       39.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   50,  'books',  null,         []],
  ['Dune',                             'dune-frank-herbert',                  "Frank Herbert's epic science fiction masterpiece. A desert planet, political intrigue, and Paul Atreides.",                                                                        15.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  60,  'books',  null,         []],
  ['Complete Cooking for Beginners',   'cooking-for-beginners-complete',      'Step-by-step guide to mastering home cooking. 200+ recipes with full-color photos and techniques.',                                                                                24.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  45,  'books',  null,         []],
  ['Financial Freedom',                'financial-freedom-grant-sabatier',    "Grant Sabatier's roadmap to retiring early. Maximize savings, build income streams. FIRE movement bible.",                                                                         16.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   55,  'books',  null,         []],
  ['Yoga for Everyone',                'yoga-for-everyone-dianne-bondy',      "Dianne Bondy's inclusive yoga guide with 50 poses for all body types. Beautifully illustrated.",                                                                                    21.99,  'https://images.unsplash.com/photo-1524578271613-d550eacf6090?w=500',  40,  'books',  null,         []],
  ['Digital Photography Manual',       'digital-photography-manual',          'Comprehensive manual covering exposure, composition, lighting, and post-processing for all cameras.',                                                                               29.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  30,  'books',  null,         []],
  ['A Brief History of Time',          'brief-history-of-time-hawking',       "Stephen Hawking's landmark exploration of the universe from the Big Bang to black holes.",                                                                                          15.99,  'https://images.unsplash.com/photo-1524578271613-d550eacf6090?w=500',  65,  'books',  null,         []],
  ['The Design of Everyday Things',    'design-of-everyday-things',           "Don Norman's classic on user-centered design. Essential reading for designers and engineers.",                                                                                       22.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   40,  'books',  null,         []],
  ['Learning Python 5th Edition',      'learning-python-5th-edition',         "Mark Lutz's comprehensive 1600-page Python reference. Covers Python 3 from basics to advanced OOP.",                                                                                59.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   25,  'books',  null,         []],
  ['Thinking, Fast and Slow',          'thinking-fast-and-slow-kahneman',     "Daniel Kahneman's exploration of two thinking systems that drive decisions. Groundbreaking behavioral economics.",                                                                   17.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  70,  'books',  null,         []],
  ['Zero to One',                      'zero-to-one-peter-thiel',             "Peter Thiel's contrarian thinking on startups. Build companies that create new things rather than copying.",                                                                        15.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   60,  'books',  null,         []],
  ['Made to Stick',                    'made-to-stick-heath-brothers',        "Chip and Dan Heath's framework for making ideas memorable. Why some ideas survive and others die.",                                                                                  16.99,  'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500',  55,  'books',  null,         []],
  ['The House Plant Expert',           'house-plant-expert-hessayon',         "Dr. Hessayon's definitive guide to caring for over 200 house plant species. Full-color photography.",                                                                               14.99,  'https://images.unsplash.com/photo-1524578271613-d550eacf6090?w=500',  35,  'books',  null,         []],
  ['The Creative Gene',                'creative-gene-hideo-kojima',          "Hideo Kojima's personal exploration of films, music, and books that shaped his creative vision.",                                                                                    26.99,  'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500',   20,  'books', 'New',        []],

  // ── Sports & Outdoors (20) ───────────────────────────────────────────
  ['Yoga Mat Premium',                 'yoga-mat-premium',                    'Extra-thick 6mm eco-friendly yoga mat with alignment guides and non-slip surface. Includes carrying strap.',                                                                        34.99,  'https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=500',  65,  'sports-outdoors', 'Best Seller', ['https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=800']],
  ['4-Person Camping Tent',            'camping-tent-4-person',               'Waterproof 4-person dome tent with easy color-coded setup. Rainfly, ground stakes, carry bag. 3000mm HH.',                                                                         119.99, 'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=500',  18,  'sports-outdoors',  null,        ['https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=800']],
  ['Mountain Bike Helmet',             'mountain-bike-helmet',                'Lightweight ventilated MIPS-certified helmet. Adjustable dial fit, removable visor, 18 vents.',                                                                                       64.99,  'https://images.unsplash.com/photo-1557803175-2f8c4a53c4e3?w=500',   40,  'sports-outdoors', 'New',        []],
  ['Resistance Bands Set 5pc',         'resistance-bands-5pc-set',            'Set of 5 fabric loop resistance bands, 10–150lbs. Non-slip, includes carry bag and exercise guide.',                                                                                 19.99,  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500', 100,  'sports-outdoors',  null,        []],
  ['High-Density Foam Roller',         'foam-roller-high-density',            '18" high-density EVA foam roller with trigger point grid texture. Myofascial release and muscle recovery.',                                                                          24.99,  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500',  75,  'sports-outdoors',  null,        []],
  ['Speed Jump Rope',                  'jump-rope-speed',                     'Precision speed jump rope with aircraft-grade steel cable and sealed ball bearings. Adjustable length.',                                                                              14.99,  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500', 120,  'sports-outdoors',  null,        []],
  ['Doorframe Pull-Up Bar',            'pull-up-bar-doorframe',               'No-screws doorframe pull-up bar. 300lb capacity, foam grips, fits doors 24–36" wide. Multi-grip.',                                                                                   29.99,  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500',  60,  'sports-outdoors',  null,        []],
  ['Adjustable Dumbbell Set',          'dumbbell-set-adjustable-52lb',        'Adjustable 5–52.5lb dumbbells. Dial-select mechanism replaces 15 pairs. Compact footprint.',                                                                                        199.99, 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=500',  10,  'sports-outdoors', 'Hot Deal',   []],
  ['2L Hydration Running Backpack',    'hydration-backpack-2l',               '10L running backpack with 2L water bladder, adjustable sternum strap, and reflective trim.',                                                                                          54.99,  'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=500',  30,  'sports-outdoors',  null,        []],
  ['Carbon Fiber Trekking Poles 2pc',  'trekking-poles-carbon-fiber',         'Lightweight collapsible carbon fiber trekking poles with cork grips and rubber tips. Folds to 15".',                                                                                  49.99,  'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=500',  25,  'sports-outdoors',  null,        []],
  ['20°F Mummy Sleeping Bag',          'sleeping-bag-20f-mummy',              '20°F rated mummy sleeping bag with 800-fill duck down and YKK zipper. Packs to 8" diameter.',                                                                                        79.99,  'https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=500',  22,  'sports-outdoors',  null,        []],
  ['Anti-Fog Swim Goggles',            'swim-goggles-anti-fog',               'UV400 anti-fog mirrored swim goggles with replaceable nose bridges. Leak-proof silicone seal.',                                                                                       14.99,  'https://images.unsplash.com/photo-1519315901367-f34ff9154487?w=500',  90,  'sports-outdoors',  null,        []],
  ['Portable Beach Volleyball Set',    'volleyball-set-portable',             'Complete beach volleyball set with net (32x3ft), ball, pump, and stakes. Sets up in 5 minutes.',                                                                                      49.99,  'https://images.unsplash.com/photo-1547347298-4074fc3086f0?w=500',   20,  'sports-outdoors',  null,        []],
  ['12oz Boxing Training Gloves',      'boxing-gloves-12oz',                  'Full-grain leather 12oz training gloves with multi-layer foam. Wrist wrap, pre-curved design.',                                                                                       44.99,  'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500',   35,  'sports-outdoors',  null,        []],
  ['Sports Gym Bag 40L',               'gym-bag-40l',                         'Durable 40L gym bag with separate wet/dry compartments, shoe pocket, and water bottle sleeve.',                                                                                       39.99,  'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=500',  50,  'sports-outdoors',  null,        []],
  ['7mm Compression Knee Sleeves 2pc', 'knee-sleeves-compression-7mm',        '7mm neoprene compression knee sleeves for lifting and running. Warmth, stability, and pain relief.',                                                                                   29.99,  'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=500',  70,  'sports-outdoors',  null,        []],
  ['Padded Cycling Gloves',            'cycling-gloves-padded',               'Breathable half-finger cycling gloves with gel palm padding and silicone grip. Machine washable.',                                                                                     19.99,  'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=500',  65,  'sports-outdoors',  null,        []],
  ['Climbing Chalk Bag',               'climbing-chalk-bag',                  'Drawstring chalk bag with zip pocket and removable belt. Fits most chalk blocks, secure closure.',                                                                                     17.99,  'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=500',   55,  'sports-outdoors',  null,        []],
  ['Ultimate Frisbee Disc 175g',       'frisbee-disc-ultimate-175g',          'Tournament-grade 175g ultimate frisbee with straight-flight mold. WFDF certified, 8 colors.',                                                                                          12.99,  'https://images.unsplash.com/photo-1547347298-4074fc3086f0?w=500',  100,  'sports-outdoors',  null,        []],
  ['Complete 31" Skateboard',          'skateboard-complete-31in',            '31" maple deck complete skateboard with 52mm wheels, ABEC-7 bearings, and 5.25" aluminum trucks.',                                                                                     69.99,  'https://images.unsplash.com/photo-1547347298-4074fc3086f0?w=500',   22,  'sports-outdoors',  null,        []],
];

const insertProduct = db.prepare(
  'INSERT INTO products (name, slug, description, price, image_url, stock, category_id, badge) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
);
const insertImage = db.prepare(
  'INSERT INTO product_images (product_id, image_url, sort_order) VALUES (?, ?, ?)'
);

const productIds = {};
db.transaction(() => {
  for (const [name, slug, desc, price, img, stock, catSlug, badge, images] of products) {
    const id = insertProduct.run(name, slug, desc, price, img, stock, catIds[catSlug], badge ?? null).lastInsertRowid;
    productIds[slug] = id;
    (images || []).forEach((url, i) => insertImage.run(id, url, i));
  }
})();
console.log(`Seeded ${products.length} products across ${catData.length} categories`);

// --- Orders ---
const insertOrder = db.prepare(
  'INSERT INTO orders (user_id, customer_name, customer_email, shipping_address, subtotal, discount, total, status, shipping_cost, tax_amount) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
);
const insertOrderItem = db.prepare(
  'INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)'
);
db.transaction(() => {
  const o1 = insertOrder.run(janeId, 'Jane Smith', 'jane@example.com', '123 Maple St, Portland, OR 97201',    279.98, 0,     309.96, 'delivered', 0,    29.98);
  insertOrderItem.run(o1.lastInsertRowid, productIds['wireless-bluetooth-headphones'], 1, 79.99);
  insertOrderItem.run(o1.lastInsertRowid, productIds['smart-watch-pro'], 1, 199.99);

  const o2 = insertOrder.run(janeId, 'Jane Smith', 'jane@example.com', '123 Maple St, Portland, OR 97201',    89.99,  0,     102.75, 'shipped',   5.99, 6.77);
  insertOrderItem.run(o2.lastInsertRowid, productIds['running-sneakers'], 1, 89.99);

  const o3 = insertOrder.run(janeId, 'Jane Smith', 'jane@example.com', '456 Oak Ave, Seattle, WA 98101',      59.98,  0,     70.43,  'pending',   5.99, 4.46);
  insertOrderItem.run(o3.lastInsertRowid, productIds['stainless-steel-water-bottle'], 2, 29.99);

  const o4 = insertOrder.run(janeId, 'Jane Smith', 'jane@example.com', '123 Maple St, Portland, OR 97201',   104.98,  10.50, 107.74, 'confirmed', 0,    7.27);
  insertOrderItem.run(o4.lastInsertRowid, productIds['yoga-mat-premium'], 1, 34.99);
  insertOrderItem.run(o4.lastInsertRowid, productIds['resistance-bands-5pc-set'], 1, 19.99);
  insertOrderItem.run(o4.lastInsertRowid, productIds['foam-roller-high-density'], 1, 24.99);
  insertOrderItem.run(o4.lastInsertRowid, productIds['jump-rope-speed'], 1, 14.99);

  const o5 = insertOrder.run(janeId, 'Jane Smith', 'jane@example.com', '789 Pine Rd, San Francisco, CA 94102', 199.99, 40.00, 179.39, 'delivered', 0,   19.40);
  insertOrderItem.run(o5.lastInsertRowid, productIds['gaming-laptop-pro-15'], 1, 1199.99);

  const o6cancelled = insertOrder.run(janeId, 'Jane Smith', 'jane@example.com', '789 Pine Rd, San Francisco, CA 94102', 44.99, 0, 44.99, 'cancelled', 5.99, 0);
  insertOrderItem.run(o6cancelled.lastInsertRowid, productIds['sport-wireless-earphones'], 1, 34.99);

  const o7 = insertOrder.run(bobId,  'Bob Wilson',  'bob@example.com',  '456 Oak Ave, Seattle, WA 98101',      169.98, 0,     191.38, 'confirmed', 5.99, 15.41);
  insertOrderItem.run(o7.lastInsertRowid, productIds['mechanical-keyboard'], 1, 129.99);
  insertOrderItem.run(o7.lastInsertRowid, productIds['ceramic-coffee-mug-set'], 1, 39.99);

  const o8 = insertOrder.run(bobId,  'Bob Wilson',  'bob@example.com',  '456 Oak Ave, Seattle, WA 98101',      119.99, 0,     135.83, 'delivered', 5.99, 9.85);
  insertOrderItem.run(o8.lastInsertRowid, productIds['camping-tent-4-person'], 1, 119.99);
})();

// --- Wishlists ---
const insertWishlist = db.prepare('INSERT OR IGNORE INTO wishlists (user_id, product_id) VALUES (?, ?)');
db.transaction(() => {
  ['mechanical-keyboard','camping-tent-4-person','yoga-mat-premium','gaming-laptop-pro-15','4k-monitor-27']
    .forEach(s => insertWishlist.run(janeId, productIds[s]));
  ['smart-watch-pro','classic-denim-jacket','dumbbell-set-adjustable-52lb']
    .forEach(s => { if (productIds[s]) insertWishlist.run(bobId, productIds[s]); });
})();

// --- Product Variants (sample for first 10 electronics) ---
const insertVariant = db.prepare(
  'INSERT INTO product_variants (product_id, group_name, value, price_modifier, stock, sort_order) VALUES (?, ?, ?, ?, ?, ?)'
);
const variantData = [
  [productIds['wireless-bluetooth-headphones'], [['Color','Black',0,20,0],['Color','White',0,15,1],['Color','Navy',0,10,2]]],
  [productIds['smart-watch-pro'],               [['Size','41mm',0,15,0],['Size','45mm',20,15,1]]],
  [productIds['mechanical-keyboard'],           [['Switch','Cherry MX Red',0,12,0],['Switch','Cherry MX Brown',0,8,1],['Switch','Cherry MX Blue',-10,5,2]]],
  [productIds['portable-bluetooth-speaker'],    [['Color','Black',0,25,0],['Color','Blue',0,20,1],['Color','Red',0,15,2]]],
  [productIds['gaming-laptop-pro-15'],          [['RAM','16GB',0,6,0],['RAM','32GB',200,4,1]]],
  [productIds['wireless-noise-canceling-earbuds'],[['Color','White',0,25,0],['Color','Black',0,20,1]]],
  [productIds['wireless-gaming-mouse'],         [['Color','Black',0,20,0],['Color','White',5,10,1]]],
  [productIds['10-android-tablet'],             [['Storage','64GB',0,12,0],['Storage','128GB',50,8,1],['Storage','256GB',100,5,2]]],
  [productIds['digital-drawing-tablet'],        [['Size','Small (6x4")',-20,15,0],['Size','Medium (10x6")',0,8,1],['Size','Large (13x8")',40,5,2]]],
  [productIds['sport-wireless-earphones'],      [['Color','Black',0,35,0],['Color','White',0,25,1],['Color','Red',0,10,2]]],
];
db.transaction(() => {
  for (const [pid, variants] of variantData) {
    for (const [group, val, mod, stock, ord] of variants) {
      insertVariant.run(pid, group, val, mod, stock, ord);
    }
  }
})();

// --- Product Specs (sample for first 10 electronics) ---
const insertSpec = db.prepare(
  'INSERT INTO product_specs (product_id, spec_key, spec_value, sort_order) VALUES (?, ?, ?, ?)'
);
const specData = [
  [productIds['wireless-bluetooth-headphones'], [['Driver Size','40mm',0],['Frequency Response','20Hz-20kHz',1],['Battery Life','30 hours',2],['Connectivity','Bluetooth 5.2',3],['Weight','250g',4]]],
  [productIds['smart-watch-pro'],              [['Display','1.4" AMOLED',0],['Battery Life','7 days',1],['Water Resistance','5ATM (50m)',2],['GPS','Built-in',3],['Heart Rate','Continuous 24/7',4]]],
  [productIds['mechanical-keyboard'],          [['Layout','TKL (87 keys)',0],['Switches','Cherry MX',1],['Backlight','Per-key RGB',2],['Polling Rate','1000Hz',3],['Weight','850g',4]]],
  [productIds['portable-bluetooth-speaker'],   [['Output Power','20W RMS',0],['Battery Life','12 hours',1],['Water Resistance','IPX7',2],['Connectivity','Bluetooth 5.0',3],['Weight','540g',4]]],
  [productIds['gaming-laptop-pro-15'],         [['CPU','Intel Core i7-13700H',0],['GPU','NVIDIA RTX 4060 8GB',1],['Display','15.6" 144Hz IPS',2],['RAM','16GB DDR5',3],['Storage','512GB NVMe SSD',4],['Weight','2.1kg',5]]],
  [productIds['wireless-noise-canceling-earbuds'],[['Battery Life','7h + 21h case',0],['ANC','-30dB',1],['Driver','11mm dynamic',2],['Water Resistance','IPX5',3],['Charging','USB-C + Wireless',4]]],
  [productIds['wireless-gaming-mouse'],        [['DPI','100-25,600',0],['Battery','70 hours',1],['Weight','89g',2],['Buttons','6 programmable',3],['Polling Rate','1000Hz',4]]],
  [productIds['10-android-tablet'],            [['Display','10.4" 2K IPS',0],['Processor','Octa-core 2.0GHz',1],['RAM','6GB',2],['Battery','7000mAh',3],['OS','Android 14',4]]],
  [productIds['digital-drawing-tablet'],       [['Active Area','10" x 6"',0],['Pressure Levels','8192',1],['Resolution','5080 LPI',2],['Report Rate','266 RPS',3],['Pen Battery','None (EMR)',4]]],
  [productIds['sport-wireless-earphones'],     [['Battery Life','8h + 24h case',0],['Driver','10mm dynamic',1],['Water Resistance','IPX7',2],['Connectivity','Bluetooth 5.0',3],['Weight','5g per bud',4]]],
];
db.transaction(() => {
  for (const [pid, specs] of specData) {
    for (const [key, val, ord] of specs) {
      insertSpec.run(pid, key, val, ord);
    }
  }
})();

// --- Reviews ---
const insertReview = db.prepare(
  'INSERT OR IGNORE INTO reviews (product_id, user_id, rating, title, body) VALUES (?, ?, ?, ?, ?)'
);
db.transaction(() => {
  insertReview.run(productIds['wireless-bluetooth-headphones'], janeId, 5, 'Incredible sound quality!',         'These headphones are amazing. ANC is top-notch and battery lasts all day.');
  insertReview.run(productIds['wireless-bluetooth-headphones'], bobId,  4, 'Great headphones',                  'Very comfortable. ANC could be stronger but overall satisfied.');
  insertReview.run(productIds['smart-watch-pro'],               janeId, 5, 'Best smartwatch I\'ve owned',       'GPS is accurate, heart rate reliable, display beautiful. 7 days battery is real!');
  insertReview.run(productIds['running-sneakers'],              janeId, 4, 'Comfortable for long runs',         'Lightweight and breathable. Good cushioning. Sizing runs a bit small.');
  insertReview.run(productIds['running-sneakers'],              bobId,  5, 'Perfect fit',                       'Great grip and responsive. Will buy again.');
  insertReview.run(productIds['camping-tent-4-person'],         bobId,  5, 'Solid tent for the price',          'Easy setup in under 10 minutes. Kept us dry in heavy rain.');
  insertReview.run(productIds['mechanical-keyboard'],           bobId,  4, 'Great typing experience',           'Cherry MX switches feel amazing. RGB vibrant. Loud for office, perfect at home.');
  insertReview.run(productIds['yoga-mat-premium'],              janeId, 5, 'Best yoga mat ever',                'Thick, non-slip, alignment guides super helpful. Easy to clean.');
  insertReview.run(productIds['stainless-steel-water-bottle'],  janeId, 5, 'Keeps drinks cold all day',         'Cold 24 hours is accurate even in hot weather. Great quality.');
  insertReview.run(productIds['non-stick-cookware-set'],        bobId,  3, 'Decent but handle gets hot',        'Food does not stick and cleanup is easy. Handles get warm on high heat.');
  insertReview.run(productIds['atomic-habits-james-clear'],     janeId, 5, 'Life changing read',                'The 1% better every day concept genuinely changed my approach to self-improvement.');
  insertReview.run(productIds['gaming-laptop-pro-15'],          bobId,  5, 'Runs everything smoothly',          'RTX 4060 handles all my games at high settings. Build quality excellent.');
  insertReview.run(productIds['dumbbell-set-adjustable-52lb'],  janeId, 5, 'Replaced my entire rack',           'Dial system is quick and reliable. Worth every penny for a home gym.');
  insertReview.run(productIds['deep-work-cal-newport'],     janeId, 5, 'Changed how I work',          'The deep work concept completely reshaped my daily schedule. More focused, less distracted.');
  insertReview.run(productIds['atomic-habits-james-clear'], bobId,  5, 'Must read',                   'Simple, actionable, and backed by science. Already building three new habits.');
  insertReview.run(productIds['camping-tent-4-person'],     janeId, 4, 'Great for families',          'Roomy and well-ventilated. Stakes hold well. Rainfly could be a bit longer.');
  insertReview.run(productIds['mountain-bike-helmet'],      bobId,  5, 'Safe and comfortable',        'MIPS really works — had a light fall and felt nothing. Visor is great for sun.');
  insertReview.run(productIds['dumbbell-set-adjustable-52lb'], bobId, 5, 'Best home gym purchase',   'Dial system is quick, no fumbling between sets. Space-efficient and solid build.');
  insertReview.run(productIds['coffee-maker-12cup'],        janeId, 4, 'Great coffee every morning', 'Built-in grinder is convenient. Programming is simple. Could be quieter though.');
  insertReview.run(productIds['knife-set-6pc-chef'],        bobId,  5, 'Sharp and balanced',          'German steel holds an edge well. The block looks great on the counter too.');
})();

// --- Coupons ---
const insertCoupon = db.prepare(
  'INSERT INTO coupons (code, type, value, min_order, max_uses, expires_at) VALUES (?, ?, ?, ?, ?, ?)'
);
db.transaction(() => {
  insertCoupon.run('WELCOME10', 'percentage', 10,  0,   100, null);
  insertCoupon.run('SAVE20',    'percentage', 20,  50,   50, null);
  insertCoupon.run('FLAT15',    'fixed',      15,  30,  null, null);
  insertCoupon.run('SUMMER25',  'percentage', 25,  100, 200, '2027-12-31 23:59:59');
  insertCoupon.run('DEMO10',    'percentage', 10,  0,   999, '2028-12-31 23:59:59');
})();

// --- Banners ---
const insertBanner = db.prepare(
  'INSERT INTO banners (title, subtitle, image_url, link, bg_color, sort_order) VALUES (?, ?, ?, ?, ?, ?)'
);
db.transaction(() => {
  insertBanner.run('Mega Sale — Up to 50% Off',   'Shop top electronics at unbeatable prices this week only!',     'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=1200', '/search?category=electronics', '#1a1a2e', 0);
  insertBanner.run('New Arrivals in Fashion',      'Discover the latest styles. Free shipping on orders over $50.', 'https://images.unsplash.com/photo-1445205170230-053b83016050?w=1200', '/search?category=clothing',    '#0f3460', 1);
  insertBanner.run('Home & Kitchen Essentials',    'Upgrade your space with premium cookware and decor.',           'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=1200', '/search?category=home-kitchen','#16213e', 2);
})();

// --- Flash Sale (10 items, 8 hours) ---
const now      = new Date();
const saleStart = new Date(now.getTime() - 60 * 60 * 1000).toISOString();
const saleEnd   = new Date(now.getTime() + 8 * 60 * 60 * 1000).toISOString();
const insertFS  = db.prepare('INSERT INTO flash_sales (title, starts_at, ends_at, active) VALUES (?, ?, ?, ?)');
const insertFSI = db.prepare(
  'INSERT INTO flash_sale_items (flash_sale_id, product_id, sale_price, quantity_limit, sold) VALUES (?, ?, ?, ?, ?)'
);
db.transaction(() => {
  const sid = insertFS.run('Flash Sale — Today Only!', saleStart, saleEnd, 1).lastInsertRowid;
  insertFSI.run(sid, productIds['wireless-bluetooth-headphones'],    49.99, 20,  7);
  insertFSI.run(sid, productIds['smart-watch-pro'],                 139.99, 15,  5);
  insertFSI.run(sid, productIds['running-sneakers'],                 59.99, 25, 12);
  insertFSI.run(sid, productIds['mechanical-keyboard'],              89.99, 10,  3);
  insertFSI.run(sid, productIds['yoga-mat-premium'],                 19.99, 30, 18);
  insertFSI.run(sid, productIds['portable-bluetooth-speaker'],       29.99, 20,  9);
  insertFSI.run(sid, productIds['gaming-laptop-pro-15'],            899.99,  5,  1);
  insertFSI.run(sid, productIds['4k-monitor-27'],                   319.99,  8,  2);
  insertFSI.run(sid, productIds['dumbbell-set-adjustable-52lb'],    149.99,  5,  0);
  insertFSI.run(sid, productIds['wireless-noise-canceling-earbuds'], 49.99, 20,  4);
})();

// --- Deals of the Day (4 items) ---
const dayStart  = new Date(); dayStart.setHours(0, 0, 0, 0);
const dayEnd    = new Date(); dayEnd.setHours(23, 59, 59, 999);
const insertDeal = db.prepare(
  'INSERT INTO deals_of_day (product_id, sale_price, starts_at, ends_at, active) VALUES (?, ?, ?, ?, ?)'
);
db.transaction(() => {
  insertDeal.run(productIds['coffee-maker-12cup'],    54.99, dayStart.toISOString(), dayEnd.toISOString(), 1);
  insertDeal.run(productIds['stand-mixer-5qt'],      149.99, dayStart.toISOString(), dayEnd.toISOString(), 1);
  insertDeal.run(productIds['knife-set-6pc-chef'],    59.99, dayStart.toISOString(), dayEnd.toISOString(), 1);
  insertDeal.run(productIds['air-purifier-hepa'],     89.99, dayStart.toISOString(), dayEnd.toISOString(), 1);
})();

console.log('Orders, wishlists, reviews, coupons, banners, flash sale (10), deals (4) seeded.');
console.log('Demo user: jane@example.com | role: admin | Prime | 850 loyalty points');
console.log('Gift cards: DEMO50 ($50 balance), DEMO20 ($20 balance)');
process.exit(0);
