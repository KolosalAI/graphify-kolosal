import db from '../db/index.js';

export const ProductRepository = {
  findById(id) {
    return db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  },

  findBySlug(slug) {
    return db.prepare(`
      SELECT p.*, c.name as category_name, c.slug as category_slug,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating,
             COUNT(r.id) as review_count,
             COALESCE((SELECT pi.image_url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.sort_order LIMIT 1), p.image_url) as image_url
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE p.slug = ?
      GROUP BY p.id
    `).get(slug);
  },

  findAll({ whereClause, params, orderBy, limitNum, offset }) {
    return db.prepare(`
      SELECT p.*, c.name as category_name, c.slug as category_slug,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating,
             COUNT(r.id) as review_count,
             COALESCE((SELECT pi.image_url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.sort_order LIMIT 1), p.image_url) as image_url
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE ${whereClause}
      GROUP BY p.id
      ${limitNum !== undefined ? `ORDER BY ${orderBy} LIMIT ? OFFSET ?` : ''}
    `).all(...params, ...(limitNum !== undefined ? [limitNum, offset] : []));
  },

  countAll({ whereClause, params, havingClause = '' }) {
    return db.prepare(`
      SELECT COUNT(*) as count FROM (
        SELECT p.id, COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN reviews r ON r.product_id = p.id
        WHERE ${whereClause}
        GROUP BY p.id
        ${havingClause}
      )
    `).get(...params).count;
  },

  getPriceRange({ whereClause, params }) {
    return db.prepare(`
      SELECT MIN(price) as min, MAX(price) as max FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE ${whereClause}
    `).get(...params);
  },

  getBrands({ whereClause, params }) {
    return db.prepare(`
      SELECT DISTINCT p.brand FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE ${whereClause} AND p.brand IS NOT NULL
      ORDER BY p.brand
    `).all(...params).map(r => r.brand);
  },

  getSuggestions(q) {
    return db.prepare(`
      SELECT p.id, p.name, p.slug, p.price,
             COALESCE((SELECT pi.image_url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.sort_order LIMIT 1), p.image_url) as image_url
      FROM products p WHERE p.name LIKE ? LIMIT 6
    `).all(`%${q}%`);
  },

  getImages(productId) {
    return db.prepare('SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order').all(productId);
  },

  getRatingDist(productId) {
    return db.prepare('SELECT rating, COUNT(*) as count FROM reviews WHERE product_id = ? GROUP BY rating ORDER BY rating DESC').all(productId);
  },

  getAlsoViewed(productId) {
    return db.prepare(`
      SELECT p.id, p.name, p.slug, p.price, p.image_url,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating,
             COUNT(DISTINCT r.id) as review_count,
             COUNT(*) as view_overlap
      FROM product_views pv
      JOIN product_views pv2 ON (pv2.user_id = pv.user_id OR pv2.session_id = pv.session_id)
        AND (pv2.user_id IS NOT NULL OR pv2.session_id IS NOT NULL)
      JOIN products p ON p.id = pv2.product_id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE pv.product_id = ? AND pv2.product_id != ?
      GROUP BY p.id
      ORDER BY view_overlap DESC
      LIMIT 6
    `).all(productId, productId);
  },

  getRelated(categoryId, productId) {
    return db.prepare(`
      SELECT p.*, c.name as category_name, c.slug as category_slug,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating,
             COUNT(r.id) as review_count
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE p.category_id = ? AND p.id != ?
      GROUP BY p.id
      ORDER BY RANDOM()
      LIMIT 4
    `).all(categoryId, productId);
  },

  trackView(productId, userId, sessionId) {
    try {
      db.prepare('INSERT INTO product_views (product_id, user_id, session_id) VALUES (?, ?, ?)').run(productId, userId, sessionId);
    } catch (_) {}
  },

  addPriceWatch(userId, productId) {
    try {
      db.prepare('INSERT INTO price_watches (user_id, product_id) VALUES (?, ?)').run(userId, productId);
    } catch (_) {}
  },

  getPriceWatchers(productId, newPrice) {
    return db.prepare('SELECT user_id FROM price_watches WHERE product_id = ? AND (target_price IS NULL OR target_price >= ?)').all(productId, newPrice);
  },

  create({ name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible, seller_id = null }) {
    const result = db.prepare(
      'INSERT INTO products (name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible, seller_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(name, slug, description || '', price, image_url || '', stock || 0, category_id || null, brand || null, badge || null, is_prime_eligible ? 1 : 0, seller_id || null);
    return this.findById(result.lastInsertRowid);
  },

  update(id, { name, slug, description, price, image_url, stock, category_id, brand, badge, is_prime_eligible }) {
    db.prepare(`
      UPDATE products SET name = ?, slug = ?, description = ?, price = ?, image_url = ?, stock = ?, category_id = ?, brand = ?, badge = ?, is_prime_eligible = ?
      WHERE id = ?
    `).run(name, slug, description, price, image_url, stock, category_id || null, brand || null, badge || null, is_prime_eligible ? 1 : 0, id);
    return this.findById(id);
  },

  updatePartial(id, fields) {
    const existing = this.findById(id);
    if (!existing) return null;
    db.prepare(
      'UPDATE products SET name=?, description=?, price=?, stock=?, category_id=?, image_url=?, brand=? WHERE id=?'
    ).run(
      fields.name ?? existing.name,
      fields.description ?? existing.description,
      fields.price ?? existing.price,
      fields.stock ?? existing.stock,
      fields.category_id ?? existing.category_id,
      fields.image_url ?? existing.image_url,
      fields.brand ?? existing.brand,
      id
    );
    return this.findById(id);
  },

  deleteById(id) {
    return db.prepare('DELETE FROM products WHERE id = ?').run(id);
  },

  deleteImages(productId) {
    return db.prepare('DELETE FROM product_images WHERE product_id = ?').run(productId);
  },

  addImages(productId, images) {
    const insertImg = db.prepare('INSERT INTO product_images (product_id, image_url, sort_order) VALUES (?, ?, ?)');
    images.forEach((url, i) => insertImg.run(productId, url, i));
  },

  updateStock(productId, delta) {
    return db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(delta, productId);
  },

  getLowStock() {
    return db.prepare(`
      SELECT p.*, c.name as category_name FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.stock <= 5 ORDER BY p.stock ASC
    `).all();
  },

  findAllAdmin({ limit, offset }) {
    const total = db.prepare('SELECT COUNT(*) as count FROM products').get().count;
    const products = db.prepare(`
      SELECT p.*, c.name as category_name
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.id DESC
      LIMIT ? OFFSET ?
    `).all(limit, offset);
    return { products, total };
  },

  // Variants
  getVariants(productId) {
    return db.prepare('SELECT * FROM product_variants WHERE product_id = ? ORDER BY group_name, sort_order').all(productId);
  },

  getVariantById(id, productId) {
    return db.prepare('SELECT * FROM product_variants WHERE id = ? AND product_id = ?').get(id, productId);
  },

  createVariant({ product_id, group_name, value, price_modifier = 0, stock = 0, sku, sort_order = 0 }) {
    const result = db.prepare(
      'INSERT INTO product_variants (product_id, group_name, value, price_modifier, stock, sku, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run(product_id, group_name, value, price_modifier, stock, sku || null, sort_order);
    return db.prepare('SELECT * FROM product_variants WHERE id = ?').get(result.lastInsertRowid);
  },

  updateVariant(id, fields) {
    const variant = db.prepare('SELECT * FROM product_variants WHERE id = ?').get(id);
    if (!variant) return null;
    db.prepare(
      'UPDATE product_variants SET group_name=?, value=?, price_modifier=?, stock=?, sku=?, sort_order=? WHERE id=?'
    ).run(
      fields.group_name ?? variant.group_name,
      fields.value ?? variant.value,
      fields.price_modifier ?? variant.price_modifier,
      fields.stock ?? variant.stock,
      fields.sku ?? variant.sku,
      fields.sort_order ?? variant.sort_order,
      id
    );
    return db.prepare('SELECT * FROM product_variants WHERE id = ?').get(id);
  },

  deleteVariant(id, productId) {
    return db.prepare('DELETE FROM product_variants WHERE id = ? AND product_id = ?').run(id, productId);
  },

  // Specs
  getSpecs(productId) {
    return db.prepare('SELECT * FROM product_specs WHERE product_id = ? ORDER BY sort_order').all(productId);
  },

  getSpecById(id, productId) {
    return db.prepare('SELECT * FROM product_specs WHERE id = ? AND product_id = ?').get(id, productId);
  },

  createSpec({ product_id, spec_key, spec_value, sort_order = 0 }) {
    const result = db.prepare(
      'INSERT INTO product_specs (product_id, spec_key, spec_value, sort_order) VALUES (?, ?, ?, ?)'
    ).run(product_id, spec_key, spec_value, sort_order);
    return db.prepare('SELECT * FROM product_specs WHERE id = ?').get(result.lastInsertRowid);
  },

  updateSpec(id, fields) {
    const spec = db.prepare('SELECT * FROM product_specs WHERE id = ?').get(id);
    if (!spec) return null;
    db.prepare('UPDATE product_specs SET spec_key=?, spec_value=?, sort_order=? WHERE id=?').run(
      fields.spec_key ?? spec.spec_key,
      fields.spec_value ?? spec.spec_value,
      fields.sort_order ?? spec.sort_order,
      id
    );
    return db.prepare('SELECT * FROM product_specs WHERE id = ?').get(id);
  },

  deleteSpec(id, productId) {
    return db.prepare('DELETE FROM product_specs WHERE id = ? AND product_id = ?').run(id, productId);
  },
};
