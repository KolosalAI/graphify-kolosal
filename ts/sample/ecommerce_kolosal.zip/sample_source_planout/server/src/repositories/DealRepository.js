import db from '../db/index.js';

export const DealRepository = {
  findActive() {
    const now = new Date().toISOString();
    return db.prepare(`
      SELECT d.*, p.name, p.slug, p.image_url, p.price as original_price,
             c.name as category_name,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating, COUNT(r.id) as review_count
      FROM deals_of_day d
      JOIN products p ON d.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE d.active = 1 AND d.starts_at <= ? AND d.ends_at >= ?
      GROUP BY d.id
      ORDER BY d.ends_at ASC
    `).all(now, now);
  },

  findAll() {
    return db.prepare(`
      SELECT d.*, p.name, p.price as original_price
      FROM deals_of_day d JOIN products p ON d.product_id = p.id
      ORDER BY d.id DESC
    `).all();
  },

  findById(id) {
    return db.prepare('SELECT * FROM deals_of_day WHERE id = ?').get(id);
  },

  create({ product_id, sale_price, starts_at, ends_at }) {
    const result = db.prepare(
      'INSERT INTO deals_of_day (product_id, sale_price, starts_at, ends_at) VALUES (?, ?, ?, ?)'
    ).run(product_id, sale_price, starts_at, ends_at);
    return db.prepare(`
      SELECT d.*, p.name, p.price as original_price
      FROM deals_of_day d JOIN products p ON d.product_id = p.id WHERE d.id = ?
    `).get(result.lastInsertRowid);
  },

  update(id, fields) {
    const deal = this.findById(id);
    if (!deal) return null;
    db.prepare(
      'UPDATE deals_of_day SET sale_price=?, starts_at=?, ends_at=?, active=? WHERE id=?'
    ).run(
      fields.sale_price ?? deal.sale_price,
      fields.starts_at ?? deal.starts_at,
      fields.ends_at ?? deal.ends_at,
      fields.active ?? deal.active,
      id
    );
    return this.findById(id);
  },

  deleteById(id) {
    return db.prepare('DELETE FROM deals_of_day WHERE id = ?').run(id);
  },
};
