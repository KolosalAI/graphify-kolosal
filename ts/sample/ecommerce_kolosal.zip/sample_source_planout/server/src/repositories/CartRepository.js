import db from '../db/index.js';

export const CartRepository = {
  getCartWithProducts(userId) {
    return db.prepare(`
      SELECT ci.product_id as id, ci.quantity, p.name, p.price, p.image_url, p.slug, p.stock
      FROM cart_items ci
      JOIN products p ON ci.product_id = p.id
      WHERE ci.user_id = ?
      ORDER BY ci.updated_at DESC
    `).all(userId);
  },

  upsertItem(userId, productId, quantity) {
    return db.prepare(`
      INSERT INTO cart_items (user_id, product_id, quantity, updated_at)
      VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(user_id, product_id) DO UPDATE SET quantity = excluded.quantity, updated_at = excluded.updated_at
    `).run(userId, productId, quantity);
  },

  removeItem(userId, productId) {
    return db.prepare('DELETE FROM cart_items WHERE user_id = ? AND product_id = ?').run(userId, productId);
  },

  clearCart(userId) {
    return db.prepare('DELETE FROM cart_items WHERE user_id = ?').run(userId);
  },

  syncItems(userId, items) {
    const upsert = db.prepare(`
      INSERT INTO cart_items (user_id, product_id, quantity, updated_at)
      VALUES (?, ?, ?, datetime('now'))
      ON CONFLICT(user_id, product_id) DO UPDATE SET quantity = excluded.quantity, updated_at = excluded.updated_at
    `);
    db.transaction(() => {
      for (const item of items) {
        if (item.id && item.quantity > 0) {
          upsert.run(userId, item.id, item.quantity);
        }
      }
    })();
  },
};
