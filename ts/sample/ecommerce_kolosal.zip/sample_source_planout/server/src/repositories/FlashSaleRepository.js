import db from '../db/index.js';

export const FlashSaleRepository = {
  getActive() {
    const now = new Date().toISOString();
    return db.prepare(`
      SELECT * FROM flash_sales
      WHERE active = 1 AND starts_at <= ? AND ends_at >= ?
      ORDER BY starts_at DESC LIMIT 1
    `).get(now, now);
  },

  getActiveItems(saleId) {
    return db.prepare(`
      SELECT fsi.*, p.name, p.slug, p.image_url, p.price as original_price,
             c.name as category_name,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating,
             COUNT(r.id) as review_count
      FROM flash_sale_items fsi
      JOIN products p ON fsi.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE fsi.flash_sale_id = ?
      GROUP BY fsi.id
      ORDER BY fsi.id
    `).all(saleId);
  },

  findAll() {
    const sales = db.prepare('SELECT * FROM flash_sales ORDER BY starts_at DESC').all();
    const itemCounts = db.prepare('SELECT flash_sale_id, COUNT(*) as count FROM flash_sale_items GROUP BY flash_sale_id').all();
    const countMap = Object.fromEntries(itemCounts.map(r => [r.flash_sale_id, r.count]));
    return sales.map(s => ({ ...s, item_count: countMap[s.id] || 0 }));
  },

  findById(id) {
    return db.prepare('SELECT * FROM flash_sales WHERE id = ?').get(id);
  },

  getItems(saleId) {
    return db.prepare(`
      SELECT fsi.*, p.name, p.slug, p.image_url, p.price as original_price
      FROM flash_sale_items fsi
      JOIN products p ON fsi.product_id = p.id
      WHERE fsi.flash_sale_id = ?
      ORDER BY fsi.id
    `).all(saleId);
  },

  create({ title, starts_at, ends_at, active }) {
    const result = db.prepare('INSERT INTO flash_sales (title, starts_at, ends_at, active) VALUES (?, ?, ?, ?)').run(
      title, starts_at, ends_at, active !== undefined ? (active ? 1 : 0) : 1
    );
    return this.findById(result.lastInsertRowid);
  },

  update(id, { title, starts_at, ends_at, active }) {
    db.prepare('UPDATE flash_sales SET title = ?, starts_at = ?, ends_at = ?, active = ? WHERE id = ?').run(title, starts_at, ends_at, active ? 1 : 0, id);
    return this.findById(id);
  },

  toggleActive(id) {
    const sale = this.findById(id);
    if (!sale) return null;
    db.prepare('UPDATE flash_sales SET active = ? WHERE id = ?').run(sale.active ? 0 : 1, id);
    return { id, active: !sale.active };
  },

  deleteById(id) {
    return db.prepare('DELETE FROM flash_sales WHERE id = ?').run(id);
  },

  getItemById(itemId, flashSaleId) {
    return db.prepare('SELECT * FROM flash_sale_items WHERE id = ? AND flash_sale_id = ?').get(itemId, flashSaleId);
  },

  addItem({ flash_sale_id, product_id, sale_price, quantity_limit }) {
    const result = db.prepare(
      'INSERT INTO flash_sale_items (flash_sale_id, product_id, sale_price, quantity_limit, sold) VALUES (?, ?, ?, ?, 0)'
    ).run(flash_sale_id, product_id, sale_price, quantity_limit || null);
    return db.prepare(`
      SELECT fsi.*, p.name, p.slug, p.image_url, p.price as original_price
      FROM flash_sale_items fsi JOIN products p ON fsi.product_id = p.id
      WHERE fsi.id = ?
    `).get(result.lastInsertRowid);
  },

  updateItem(itemId, { sale_price, quantity_limit }) {
    db.prepare('UPDATE flash_sale_items SET sale_price = ?, quantity_limit = ? WHERE id = ?').run(sale_price, quantity_limit || null, itemId);
    return db.prepare(`
      SELECT fsi.*, p.name, p.slug, p.image_url, p.price as original_price
      FROM flash_sale_items fsi JOIN products p ON fsi.product_id = p.id
      WHERE fsi.id = ?
    `).get(itemId);
  },

  deleteItem(itemId, flashSaleId) {
    return db.prepare('DELETE FROM flash_sale_items WHERE id = ? AND flash_sale_id = ?').run(itemId, flashSaleId);
  },
};
