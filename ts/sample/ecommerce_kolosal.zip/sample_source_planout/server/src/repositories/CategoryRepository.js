import db from '../db/index.js';

export const CategoryRepository = {
  findAll() {
    return db.prepare(`
      SELECT c.*, COUNT(p.id) as product_count
      FROM categories c
      LEFT JOIN products p ON p.category_id = c.id
      GROUP BY c.id
      ORDER BY c.name
    `).all();
  },

  findById(id) {
    return db.prepare('SELECT id FROM categories WHERE id = ?').get(id);
  },

  getById(id) {
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  },

  findBySlug(slug) {
    return db.prepare('SELECT * FROM categories WHERE slug = ?').get(slug);
  },

  create({ name, slug, description }) {
    const result = db.prepare('INSERT INTO categories (name, slug, description) VALUES (?, ?, ?)').run(name, slug, description || '');
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(result.lastInsertRowid);
  },

  update(id, { name, slug, description }) {
    db.prepare('UPDATE categories SET name = ?, slug = ?, description = ? WHERE id = ?').run(name, slug, description, id);
    return db.prepare('SELECT * FROM categories WHERE id = ?').get(id);
  },

  deleteById(id) {
    db.prepare('UPDATE products SET category_id = NULL WHERE category_id = ?').run(id);
    return db.prepare('DELETE FROM categories WHERE id = ?').run(id);
  },
};
