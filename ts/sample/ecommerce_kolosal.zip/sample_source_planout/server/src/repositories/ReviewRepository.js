import db from '../db/index.js';

export const ReviewRepository = {
  getStats(productId) {
    return db.prepare(`
      SELECT
        COUNT(*) as total,
        ROUND(AVG(rating), 1) as average,
        SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five,
        SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four,
        SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three,
        SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two,
        SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one
      FROM reviews WHERE product_id = ?
    `).get(productId);
  },

  findByProduct(productId, orderBy) {
    return db.prepare(`
      SELECT r.*, u.name as user_name
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.product_id = ?
      ORDER BY ${orderBy}
    `).all(productId);
  },

  findByProductAndUser(productId, userId) {
    return db.prepare('SELECT * FROM reviews WHERE product_id = ? AND user_id = ?').get(productId, userId);
  },

  findByProductAndUserWithName(productId, userId) {
    return db.prepare(`
      SELECT r.*, u.name as user_name
      FROM reviews r
      JOIN users u ON r.user_id = u.id
      WHERE r.product_id = ? AND r.user_id = ?
    `).get(productId, userId);
  },

  findById(id, productId) {
    return db.prepare('SELECT * FROM reviews WHERE id = ? AND product_id = ?').get(id, productId);
  },

  getUserHelpfulVotes(userId) {
    return db.prepare('SELECT review_id FROM review_helpful WHERE user_id = ?').all(userId).map(r => r.review_id);
  },

  checkPurchase(productId, userId) {
    return db.prepare(`
      SELECT oi.id FROM order_items oi
      JOIN orders o ON oi.order_id = o.id
      WHERE oi.product_id = ? AND o.user_id = ? AND o.status NOT IN ('cancelled','pending')
    `).get(productId, userId);
  },

  create({ productId, userId, rating, title, body }) {
    const result = db.prepare(
      'INSERT INTO reviews (product_id, user_id, rating, title, body, verified_purchase) VALUES (?, ?, ?, ?, ?, 1)'
    ).run(productId, userId, rating, title || null, body || null);
    return db.prepare(`
      SELECT r.*, u.name as user_name FROM reviews r
      JOIN users u ON r.user_id = u.id WHERE r.id = ?
    `).get(result.lastInsertRowid);
  },

  update({ productId, userId, rating, title, body }) {
    const result = db.prepare(
      'UPDATE reviews SET rating = ?, title = ?, body = ? WHERE product_id = ? AND user_id = ?'
    ).run(rating, title || null, body || null, productId, userId);
    return result.changes;
  },

  deleteByProductAndUser(productId, userId) {
    return db.prepare('DELETE FROM reviews WHERE product_id = ? AND user_id = ?').run(productId, userId);
  },

  findHelpfulVote(userId, reviewId) {
    return db.prepare('SELECT * FROM review_helpful WHERE user_id = ? AND review_id = ?').get(userId, reviewId);
  },

  voteHelpful(userId, reviewId, helpful) {
    return db.transaction(() => {
      const existing = db.prepare('SELECT * FROM review_helpful WHERE user_id = ? AND review_id = ?').get(userId, reviewId);
      if (existing) {
        if (existing.helpful === (helpful ? 1 : 0)) {
          db.prepare('DELETE FROM review_helpful WHERE user_id = ? AND review_id = ?').run(userId, reviewId);
          db.prepare('UPDATE reviews SET helpful_count = MAX(0, helpful_count - 1) WHERE id = ?').run(reviewId);
        } else {
          db.prepare('UPDATE review_helpful SET helpful = ? WHERE user_id = ? AND review_id = ?').run(helpful ? 1 : 0, userId, reviewId);
        }
      } else {
        db.prepare('INSERT INTO review_helpful (user_id, review_id, helpful) VALUES (?, ?, ?)').run(userId, reviewId, helpful ? 1 : 0);
        if (helpful) {
          db.prepare('UPDATE reviews SET helpful_count = helpful_count + 1 WHERE id = ?').run(reviewId);
        }
      }
      return db.prepare('SELECT helpful_count FROM reviews WHERE id = ?').get(reviewId);
    })();
  },
};
