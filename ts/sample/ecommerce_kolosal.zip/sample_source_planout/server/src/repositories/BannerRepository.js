import db from '../db/index.js';

export const BannerRepository = {
  findActive() {
    return db.prepare('SELECT * FROM banners WHERE active = 1 ORDER BY sort_order ASC').all();
  },

  findAll() {
    return db.prepare('SELECT * FROM banners ORDER BY sort_order ASC').all();
  },

  findById(id) {
    return db.prepare('SELECT id FROM banners WHERE id = ?').get(id);
  },

  getById(id) {
    return db.prepare('SELECT * FROM banners WHERE id = ?').get(id);
  },

  create({ title, subtitle, image_url, link, bg_color, sort_order, active }) {
    const result = db.prepare(`
      INSERT INTO banners (title, subtitle, image_url, link, bg_color, sort_order, active)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(title, subtitle || null, image_url, link || null, bg_color || '#2563eb', sort_order ?? 0, active !== undefined ? (active ? 1 : 0) : 1);
    return this.getById(result.lastInsertRowid);
  },

  update(id, { title, subtitle, image_url, link, bg_color, sort_order, active }) {
    db.prepare(`
      UPDATE banners SET title = ?, subtitle = ?, image_url = ?, link = ?, bg_color = ?, sort_order = ?, active = ?
      WHERE id = ?
    `).run(title, subtitle || null, image_url, link || null, bg_color, sort_order ?? 0, active ? 1 : 0, id);
    return this.getById(id);
  },

  toggleActive(id) {
    const banner = this.getById(id);
    if (!banner) return null;
    db.prepare('UPDATE banners SET active = ? WHERE id = ?').run(banner.active ? 0 : 1, id);
    return { id, active: !banner.active };
  },

  deleteById(id) {
    return db.prepare('DELETE FROM banners WHERE id = ?').run(id);
  },
};
