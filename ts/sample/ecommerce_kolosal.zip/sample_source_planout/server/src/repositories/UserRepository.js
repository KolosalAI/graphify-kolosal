import db from '../db/index.js';

export const UserRepository = {
  findById(id) {
    return db.prepare('SELECT id, name, email, role, subscription_plan, loyalty_points_balance, referral_code, created_at FROM users WHERE id = ?').get(id);
  },

  findByEmail(email) {
    return db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  },

  findByEmailExcludingId(email, id) {
    return db.prepare('SELECT id FROM users WHERE email = ? AND id != ?').get(email, id);
  },

  create({ name, email, hashedPassword }) {
    const result = db.prepare('INSERT INTO users (name, email, password) VALUES (?, ?, ?)').run(name, email, hashedPassword);
    return this.findById(result.lastInsertRowid);
  },

  updateProfile(id, { name, email }) {
    db.prepare('UPDATE users SET name = ?, email = ? WHERE id = ?').run(name, email, id);
    return db.prepare('SELECT id, name, email, role, created_at FROM users WHERE id = ?').get(id);
  },

  updatePassword(id, hashedPassword) {
    return db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, id);
  },

  updateRole(id, role) {
    return db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
  },

  updateSubscriptionPlan(id, plan) {
    return db.prepare('UPDATE users SET subscription_plan = ? WHERE id = ?').run(plan, id);
  },

  updateReferralCode(id, code) {
    return db.prepare('UPDATE users SET referral_code = ? WHERE id = ?').run(code, id);
  },

  addLoyaltyPoints(id, points) {
    return db.prepare('UPDATE users SET loyalty_points_balance = loyalty_points_balance + ? WHERE id = ?').run(points, id);
  },

  deductLoyaltyPoints(id, points) {
    return db.prepare('UPDATE users SET loyalty_points_balance = loyalty_points_balance - ? WHERE id = ?').run(points, id);
  },

  getLoyaltyBalance(id) {
    return db.prepare('SELECT loyalty_points_balance FROM users WHERE id = ?').get(id);
  },

  getProfileStats(id) {
    return {
      orderCount: db.prepare('SELECT COUNT(*) as count FROM orders WHERE user_id = ?').get(id).count,
      wishlistCount: db.prepare('SELECT COUNT(*) as count FROM wishlists WHERE user_id = ?').get(id).count,
      reviewCount: db.prepare('SELECT COUNT(*) as count FROM reviews WHERE user_id = ?').get(id).count,
    };
  },

  findAll({ search = '', limit = 20, offset = 0 }) {
    const like = `%${search}%`;
    const total = db.prepare('SELECT COUNT(*) as count FROM users WHERE name LIKE ? OR email LIKE ?').get(like, like).count;
    const users = db.prepare(`
      SELECT id, name, email, role, subscription_plan, loyalty_points_balance, referral_code, created_at
      FROM users WHERE name LIKE ? OR email LIKE ?
      ORDER BY created_at DESC LIMIT ? OFFSET ?
    `).all(like, like, limit, offset);
    return { users, total };
  },

  deleteById(id) {
    return db.prepare('DELETE FROM users WHERE id = ?').run(id);
  },

  updateAdmin(id, { role, subscription_plan }) {
    if (role) db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
    if (subscription_plan !== undefined) db.prepare('UPDATE users SET subscription_plan = ? WHERE id = ?').run(subscription_plan, id);
    return db.prepare('SELECT id, name, email, role, subscription_plan, loyalty_points_balance, created_at FROM users WHERE id = ?').get(id);
  },

  // Password reset tokens
  getPasswordResetToken(token) {
    return db.prepare('SELECT * FROM password_reset_tokens WHERE token = ? AND used = 0').get(token);
  },

  deletePasswordResetTokens(userId) {
    return db.prepare('DELETE FROM password_reset_tokens WHERE user_id = ?').run(userId);
  },

  createPasswordResetToken(userId, token, expiresAt) {
    return db.prepare('INSERT INTO password_reset_tokens (user_id, token, expires_at) VALUES (?, ?, ?)').run(userId, token, expiresAt);
  },

  markPasswordResetTokenUsed(id) {
    return db.prepare('UPDATE password_reset_tokens SET used = 1 WHERE id = ?').run(id);
  },

  resetPasswordTransaction(userId, hashedPassword, tokenId) {
    return db.transaction(() => {
      db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, userId);
      db.prepare('UPDATE password_reset_tokens SET used = 1 WHERE id = ?').run(tokenId);
    })();
  },
};
