import db from '../db/index.js';

export const RecommendationRepository = {
  getAlsoBought(productId) {
    return db.prepare(`
      SELECT p.*, c.name as category_name,
             COALESCE(ROUND(AVG(rv.rating), 1), 0) as avg_rating, COUNT(rv.id) as review_count,
             COUNT(oi2.id) as co_purchase_count
      FROM order_items oi1
      JOIN order_items oi2 ON oi1.order_id = oi2.order_id AND oi2.product_id != oi1.product_id
      JOIN products p ON oi2.product_id = p.id
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews rv ON rv.product_id = p.id
      WHERE oi1.product_id = ?
      GROUP BY p.id
      ORDER BY co_purchase_count DESC
      LIMIT 8
    `).all(productId);
  },

  getRelatedByCategory(categoryId, excludeId) {
    return db.prepare(`
      SELECT p.*, c.name as category_name,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating, COUNT(r.id) as review_count
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE p.category_id = ? AND p.id != ?
      GROUP BY p.id ORDER BY avg_rating DESC LIMIT 8
    `).all(categoryId, excludeId);
  },

  getAlsoViewed(categoryId, excludeId) {
    return db.prepare(`
      SELECT p.*, c.name as category_name,
             COALESCE(ROUND(AVG(r.rating), 1), 0) as avg_rating, COUNT(r.id) as review_count
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      LEFT JOIN reviews r ON r.product_id = p.id
      WHERE p.category_id = ? AND p.id != ?
      GROUP BY p.id
      ORDER BY avg_rating DESC, review_count DESC
      LIMIT 8
    `).all(categoryId, excludeId);
  },
};
