import { Router } from 'express';
import { ProductService } from '../services/ProductService.js';
import { authenticate, optionalAuth } from '../middleware/auth.js';

const router = Router();

router.get('/', optionalAuth, (req, res) => {
  try {
    const result = ProductService.searchProducts(req.query);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/suggestions', (req, res) => {
  try {
    const suggestions = ProductService.getSearchSuggestions(req.query.q);
    res.json(suggestions);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/:slug', optionalAuth, (req, res) => {
  try {
    const userId = req.user?.id || null;
    const sessionId = req.headers['x-session-id'] || null;
    const product = ProductService.getProductDetails(req.params.slug, userId, sessionId);
    res.json(product);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

router.post('/:id/watch', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.id);
    const result = ProductService.addPriceWatch(req.user.id, productId);
    res.json(result);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

export default router;
