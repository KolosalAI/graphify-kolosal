import { Router } from 'express';
import { CategoryService } from '../services/CategoryService.js';

const router = Router();

router.get('/', (req, res) => {
  try {
    const categories = CategoryService.getAllCategories();
    res.json(categories);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
