import { Router } from 'express';
import { CartService } from '../services/CartService.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

router.get('/', authenticate, (req, res) => {
  try {
    const cart = CartService.getCart(req.user.id);
    res.json(cart);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

router.post('/sync', authenticate, (req, res) => {
  try {
    const cart = CartService.syncCart(req.user.id, req.body.items);
    res.json(cart);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

router.put('/:productId', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const { quantity = 1 } = req.body;
    const cart = CartService.addOrUpdateItem(req.user.id, productId, quantity);
    res.json(cart);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

router.delete('/:productId', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const cart = CartService.removeItem(req.user.id, productId);
    res.json(cart);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

router.delete('/', authenticate, (req, res) => {
  try {
    const result = CartService.clearCart(req.user.id);
    res.json([]);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
