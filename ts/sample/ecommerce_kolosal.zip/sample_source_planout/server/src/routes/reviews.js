import { Router } from 'express';
import { ReviewService } from '../services/ReviewService.js';
import { authenticate, optionalAuth } from '../middleware/auth.js';

const router = Router();

// GET reviews for a product
router.get('/:productId', optionalAuth, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const { sort = 'newest' } = req.query;
    const userId = req.user ? req.user.id : null;
    
    const result = ReviewService.getProductReviews(productId, sort, userId);
    
    // Get user's own review if logged in
    const userReview = userId ? ReviewService.getUserReview(productId, userId) : null;
    
    res.json({ ...result, userReview });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// POST a review
router.post('/:productId', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const { rating, title, body } = req.body;
    
    const result = ReviewService.createReview({
      productId,
      userId: req.user.id,
      rating,
      title,
      body
    });
    
    res.status(201).json(result);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// PUT update own review
router.put('/:productId', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const { rating, title, body } = req.body;
    
    const result = ReviewService.updateReview({
      productId,
      userId: req.user.id,
      rating,
      title,
      body
    });
    
    res.json(result);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// DELETE own review
router.delete('/:productId', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const result = ReviewService.deleteReview(productId, req.user.id);
    res.json(result);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// POST /:productId/:reviewId/helpful — mark review helpful/unhelpful
router.post('/:productId/:reviewId/helpful', authenticate, (req, res) => {
  try {
    const productId = parseInt(req.params.productId);
    const reviewId = parseInt(req.params.reviewId);
    const { helpful = true } = req.body;
    
    const result = ReviewService.voteReviewHelpful(productId, reviewId, req.user.id, helpful);
    res.json(result);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

export default router;

