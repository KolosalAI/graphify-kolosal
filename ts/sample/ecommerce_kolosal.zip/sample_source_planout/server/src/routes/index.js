import { Router } from 'express';

import productRoutes        from './products.js';
import categoryRoutes       from './categories.js';
import cartRoutes           from './cart.js';
import bannerRoutes         from './banners.js';
import flashSaleRoutes      from './flash-sales.js';
import dealRoutes           from './deals.js';
import variantRoutes        from './variants.js';
import specRoutes           from './specs.js';
import reviewRoutes         from './reviews.js';
import recommendationRoutes from './recommendations.js';

const router = Router();

router.use('/products',         productRoutes);
router.use('/categories',       categoryRoutes);
router.use('/cart',             cartRoutes);
router.use('/banners',          bannerRoutes);
router.use('/flash-sales',      flashSaleRoutes);
router.use('/deals',            dealRoutes);
router.use('/variants',         variantRoutes);
router.use('/specs',            specRoutes);
router.use('/reviews',          reviewRoutes);
router.use('/recommendations',  recommendationRoutes);

export default router;
