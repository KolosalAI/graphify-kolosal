import { Router } from 'express';
import { VariantService } from '../services/VariantService.js';
import { authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// GET /api/variants/:productId — get all variants for a product
router.get('/:productId', (req, res) => {
  try {
    const variants = VariantService.getProductVariants(req.params.productId);
    const grouped = {};
    for (const v of variants) {
      if (!grouped[v.group_name]) grouped[v.group_name] = [];
      grouped[v.group_name].push(v);
    }
    res.json({ variants, grouped });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// POST /api/variants/:productId — add variant (admin)
router.post('/:productId', authenticate, requireAdmin, (req, res) => {
  try {
    const variant = VariantService.createVariant(req.params.productId, req.body);
    res.status(201).json(variant);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// PUT /api/variants/:productId/:id — update variant (admin)
router.put('/:productId/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(VariantService.updateVariant(req.params.productId, req.params.id, req.body));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// DELETE /api/variants/:productId/:id — delete variant (admin)
router.delete('/:productId/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(VariantService.deleteVariant(req.params.productId, req.params.id));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
