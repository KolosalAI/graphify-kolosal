import { Router } from 'express';
import { DealService } from '../services/DealService.js';
import { authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// GET /api/deals — active deals of the day
router.get('/', (_req, res) => {
  try {
    res.json(DealService.getActiveDeals());
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// GET /api/deals/admin — all deals (admin)
router.get('/admin', authenticate, requireAdmin, (_req, res) => {
  try {
    res.json(DealService.getAllDeals());
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// POST /api/deals (admin)
router.post('/', authenticate, requireAdmin, (req, res) => {
  try {
    const deal = DealService.createDeal(req.body);
    res.status(201).json(deal);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// PUT /api/deals/:id (admin)
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(DealService.updateDeal(req.params.id, req.body));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// DELETE /api/deals/:id (admin)
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(DealService.deleteDeal(req.params.id));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
