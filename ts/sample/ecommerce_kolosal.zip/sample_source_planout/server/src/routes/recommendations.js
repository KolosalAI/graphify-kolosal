import { Router } from 'express';
import { RecommendationService } from '../services/RecommendationService.js';

const router = Router();

// GET /api/recommendations/also-bought/:productId
router.get('/also-bought/:productId', (req, res) => {
  try {
    const products = RecommendationService.getAlsoBought(parseInt(req.params.productId));
    res.json(products);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// GET /api/recommendations/also-viewed/:productId
router.get('/also-viewed/:productId', (req, res) => {
  try {
    const products = RecommendationService.getAlsoViewed(parseInt(req.params.productId));
    res.json(products);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
