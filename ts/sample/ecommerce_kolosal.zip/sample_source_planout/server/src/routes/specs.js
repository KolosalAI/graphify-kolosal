import { Router } from 'express';
import { SpecService } from '../services/SpecService.js';
import { authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// GET /api/specs/:productId
router.get('/:productId', (req, res) => {
  try {
    const specs = SpecService.getProductSpecs(req.params.productId);
    res.json(specs);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// POST /api/specs/:productId (admin)
router.post('/:productId', authenticate, requireAdmin, (req, res) => {
  try {
    const spec = SpecService.createSpec(req.params.productId, req.body);
    res.status(201).json(spec);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// PUT /api/specs/:productId/:id (admin)
router.put('/:productId/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(SpecService.updateSpec(req.params.productId, req.params.id, req.body));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// DELETE /api/specs/:productId/:id (admin)
router.delete('/:productId/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(SpecService.deleteSpec(req.params.productId, req.params.id));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
