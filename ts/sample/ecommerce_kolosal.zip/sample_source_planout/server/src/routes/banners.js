import { Router } from 'express';
import { BannerService } from '../services/BannerService.js';
import { authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// Public: list active banners for homepage carousel
router.get('/', (_req, res) => {
  try {
    res.json(BannerService.getActiveBanners());
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: list all banners (including inactive)
router.get('/admin', authenticate, requireAdmin, (_req, res) => {
  try {
    res.json(BannerService.getAllBanners());
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: create banner
router.post('/', authenticate, requireAdmin, (req, res) => {
  try {
    const banner = BannerService.createBanner(req.body);
    res.status(201).json(banner);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Admin: update banner
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(BannerService.updateBanner(parseInt(req.params.id), req.body));
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Admin: toggle active
router.patch('/:id/toggle', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(BannerService.toggleBanner(parseInt(req.params.id)));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: delete banner
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(BannerService.deleteBanner(parseInt(req.params.id)));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
