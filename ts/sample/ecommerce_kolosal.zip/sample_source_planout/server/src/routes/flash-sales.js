import { Router } from 'express';
import { FlashSaleService } from '../services/FlashSaleService.js';
import { authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// Public: get currently active flash sale with items
router.get('/active', (_req, res) => {
  try {
    const sale = FlashSaleService.getActiveSaleWithItems();
    res.json(sale);
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: list all flash sales
router.get('/', authenticate, requireAdmin, (_req, res) => {
  try {
    res.json(FlashSaleService.getAllFlashSales());
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: get a single flash sale with items
router.get('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(FlashSaleService.getSaleWithItems(parseInt(req.params.id)));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: create flash sale
router.post('/', authenticate, requireAdmin, (req, res) => {
  try {
    const sale = FlashSaleService.createSale(req.body);
    res.status(201).json(sale);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Admin: update flash sale
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    const sale = FlashSaleService.updateSale(parseInt(req.params.id), req.body);
    res.json(sale);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Admin: toggle active
router.patch('/:id/toggle', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(FlashSaleService.toggleSale(parseInt(req.params.id)));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: delete flash sale
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  try {
    FlashSaleService.deleteSale(parseInt(req.params.id));
    res.json({ message: 'Flash sale deleted' });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Admin: add item to flash sale
router.post('/:id/items', authenticate, requireAdmin, (req, res) => {
  try {
    const item = FlashSaleService.addItem(parseInt(req.params.id), req.body);
    res.status(201).json(item);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Admin: update flash sale item
router.put('/:id/items/:itemId', authenticate, requireAdmin, (req, res) => {
  try {
    const item = FlashSaleService.updateItem(parseInt(req.params.id), parseInt(req.params.itemId), req.body);
    res.json(item);
  } catch (err) {
    res.status(err.status || 400).json({ error: err.message });
  }
});

// Admin: remove item from flash sale
router.delete('/:id/items/:itemId', authenticate, requireAdmin, (req, res) => {
  try {
    res.json(FlashSaleService.removeItem(parseInt(req.params.id), parseInt(req.params.itemId)));
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

export default router;
