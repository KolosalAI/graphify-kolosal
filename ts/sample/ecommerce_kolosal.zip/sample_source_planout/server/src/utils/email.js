import nodemailer from 'nodemailer';

// Configure transporter — uses env vars or falls back to ethereal (test) account
let transporter = null;

async function getTransporter() {
  if (transporter) return transporter;

  if (process.env.SMTP_HOST) {
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  } else {
    // Use Ethereal test account (emails go to https://ethereal.email — not actually delivered)
    const testAccount = await nodemailer.createTestAccount();
    transporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: { user: testAccount.user, pass: testAccount.pass },
    });
    console.log('Email: using Ethereal test account:', testAccount.user);
  }
  return transporter;
}

const FROM = process.env.EMAIL_FROM || 'ShopKolosal <noreply@shopkolosal.com>';

export async function sendOrderConfirmation(order, items, userEmail) {
  try {
    const t = await getTransporter();
    const itemRows = items.map(i =>
      `<tr><td style="padding:6px">${i.product_name}</td><td style="text-align:center;padding:6px">${i.quantity}</td><td style="text-align:right;padding:6px">$${(i.price * i.quantity).toFixed(2)}</td></tr>`
    ).join('');

    const info = await t.sendMail({
      from: FROM,
      to: userEmail,
      subject: `Order Confirmation #${order.id} — ShopKolosal`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#FF9900;padding:20px;text-align:center">
            <h1 style="color:#fff;margin:0">ShopKolosal</h1>
          </div>
          <div style="padding:24px">
            <h2>Thank you for your order!</h2>
            <p>Hi ${order.customer_name},</p>
            <p>Your order <strong>#${order.id}</strong> has been placed successfully.</p>
            <table style="width:100%;border-collapse:collapse;margin:16px 0">
              <thead><tr style="background:#f3f4f6"><th style="padding:8px;text-align:left">Item</th><th>Qty</th><th>Price</th></tr></thead>
              <tbody>${itemRows}</tbody>
            </table>
            <p><strong>Total: $${Number(order.total).toFixed(2)}</strong></p>
            ${order.estimated_delivery ? `<p>Estimated delivery: <strong>${order.estimated_delivery}</strong></p>` : ''}
            <p style="color:#666;font-size:0.9em">Track your order at <a href="http://localhost:5173/orders/${order.id}">My Orders</a>.</p>
          </div>
        </div>`,
    });
    console.log('Order confirmation email sent, preview:', nodemailer.getTestMessageUrl(info));
    return info;
  } catch (err) {
    console.error('Email send error:', err.message);
  }
}

export async function sendShippedEmail(order, userEmail) {
  try {
    const t = await getTransporter();
    const info = await t.sendMail({
      from: FROM,
      to: userEmail,
      subject: `Your order #${order.id} has shipped! — ShopKolosal`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#FF9900;padding:20px;text-align:center">
            <h1 style="color:#fff;margin:0">ShopKolosal</h1>
          </div>
          <div style="padding:24px">
            <h2>Your order is on the way! 🚚</h2>
            <p>Hi ${order.customer_name}, your order <strong>#${order.id}</strong> has been shipped.</p>
            ${order.estimated_delivery ? `<p>Estimated delivery: <strong>${order.estimated_delivery}</strong></p>` : ''}
            <p><a href="http://localhost:5173/orders/${order.id}" style="background:#FF9900;color:#fff;padding:10px 20px;border-radius:4px;text-decoration:none">Track Order</a></p>
          </div>
        </div>`,
    });
    console.log('Shipped email sent, preview:', nodemailer.getTestMessageUrl(info));
    return info;
  } catch (err) {
    console.error('Email send error:', err.message);
  }
}

export async function sendDeliveredEmail(order, userEmail) {
  try {
    const t = await getTransporter();
    const info = await t.sendMail({
      from: FROM,
      to: userEmail,
      subject: `Order #${order.id} delivered! — ShopKolosal`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#FF9900;padding:20px;text-align:center">
            <h1 style="color:#fff;margin:0">ShopKolosal</h1>
          </div>
          <div style="padding:24px">
            <h2>Your order has been delivered! 📦</h2>
            <p>Hi ${order.customer_name}, we hope you enjoy your purchase!</p>
            <p>Order <strong>#${order.id}</strong> was delivered. Don't forget to leave a review!</p>
            <p><a href="http://localhost:5173/orders/${order.id}" style="background:#FF9900;color:#fff;padding:10px 20px;border-radius:4px;text-decoration:none">View Order & Review</a></p>
          </div>
        </div>`,
    });
    console.log('Delivered email sent, preview:', nodemailer.getTestMessageUrl(info));
    return info;
  } catch (err) {
    console.error('Email send error:', err.message);
  }
}

export async function sendReturnUpdateEmail(returnReq, userEmail) {
  try {
    const t = await getTransporter();
    const statusText = returnReq.status === 'approved'
      ? 'Your return request has been approved! A refund will be processed shortly.'
      : returnReq.status === 'rejected'
        ? 'Unfortunately, your return request has been rejected. Please contact support for more information.'
        : `Your return request status has been updated to: ${returnReq.status}`;

    const info = await t.sendMail({
      from: FROM,
      to: userEmail,
      subject: `Return Request Update — ShopKolosal`,
      html: `
        <div style="font-family:sans-serif;max-width:600px;margin:0 auto">
          <div style="background:#FF9900;padding:20px;text-align:center">
            <h1 style="color:#fff;margin:0">ShopKolosal</h1>
          </div>
          <div style="padding:24px">
            <h2>Return Request Update</h2>
            <p>${statusText}</p>
            <p>Return ID: <strong>#${returnReq.id}</strong></p>
          </div>
        </div>`,
    });
    console.log('Return update email sent, preview:', nodemailer.getTestMessageUrl(info));
    return info;
  } catch (err) {
    console.error('Email send error:', err.message);
  }
}
